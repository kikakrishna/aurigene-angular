export const environment = {
  production: true,
  // apiUrl: 'https://masterlifeglobal.com/masterapi/api',
  // apiUrl: 'http://164.52.216.127:8111/api',   //main api
  // apiUrl: 'http://164.52.216.127:8555/api', //tesing api (active:refresh token)  
  //apiUrl: 'http://164.52.216.127:6678/api',

  // latlontech
  // apiUrl: 'https://aurigene.latlontech.com/telehealthapi/api',

  // Client QA
  // apiUrl: 'https://aimlqa.aurigene.com/telehealthapi/api',/

  
  //  apiUrl: 'http://aiml.aurigene.com:7789/api/',
  //apiUrl: 'http://192.168.6.156:7789/api'
  //  Client Prod 2
   apiUrl: 'https://aiml.aurigene.com/example/api'
};

