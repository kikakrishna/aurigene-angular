import { error } from 'protractor';
import { AuthenticationService } from '../_Services/authentication.service';

export function appInitializer(authenticationService: AuthenticationService) {
    return () => new Promise(resolve => {        
        let a = JSON.parse(sessionStorage.getItem("userinfo"))
        console.log(a)
        if (a != null && a != "" && a != undefined) {
            // attempt to refresh token on app start up to auto authenticate
            authenticationService.refreshToken()
                .subscribe()
                .add(resolve);
        } else {
            // null if there is no user
            return resolve(null);
        }


    });
}