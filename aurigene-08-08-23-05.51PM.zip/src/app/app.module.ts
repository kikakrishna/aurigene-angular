import { BrowserModule } from '@angular/platform-browser';
import { APP_INITIALIZER, CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { HttpClientModule, HttpClient, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ContainerComponent } from './_Components/Layout/container/container.component';
import { ToastModule } from 'ng-uikit-pro-standard';
import { JwtInterceptor } from './_Helpers/jwt.interceptor';
import { ErrorInterceptor } from './_Helpers/error.interceptor';
import { AuthGuard } from './_Gaurds/auth.guard';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxSpinnerModule } from "ngx-spinner";
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { appInitializer } from './_Helpers/app.initializer';
import { AuthenticationService } from './_Services/authentication.service';
import { AdminheaderModule } from './_Components/Layout/adminheader/adminheader.module';
import { FooterModule } from './_Components/Layout/footer/footer.module';
// import { FilteredreportModule } from './_Components/Pages/favourite-result/favourite-result.module';
// import { FavouriteresultModule } from './_Components/Pages/favourite-result/favourite-result.module';
import { BrowserUtils } from '@azure/msal-browser';
import { WebapiService, Todo } from './_Services/webapi.service';
import { IPublicClientApplication, PublicClientApplication, InteractionType } from '@azure/msal-browser';
import {
  MsalGuard, MsalInterceptor, MsalBroadcastService, MsalInterceptorConfiguration, MsalModule, MsalService,
  MSAL_GUARD_CONFIG, MSAL_INSTANCE, MSAL_INTERCEPTOR_CONFIG, MsalGuardConfiguration, MsalRedirectComponent, ProtectedResourceScopes
} from '@azure/msal-angular';
import { msalConfig, loginRequest, protectedResources } from './auth-config';
import { MyfavouritePopupComponent } from './_Components/Pages/myfavourite-popup/myfavourite-popup.component';
import { FavouriteResultComponent } from './_Components/Pages/favourite-result/favourite-result.component';
// import { BarchartComponent } from './_Components/Pages/barchart/barchart.component';
import { BarchartModule } from './_Components/Pages/barchart/barchart.module';
import { MulitireportsComponent } from './_Components/Pages/mulitireports/mulitireports.component';
import { ConfirmdeletePopupComponent } from './_Components/Pages/confirmdelete-popup/confirmdelete-popup.component';
import { InteractiveFavouritesComponent } from './_Components/Pages/interactive-favourites/interactive-favourites.component';
import { InteractiveFavouritesModule } from './_Components/Pages/interactive-favourites/interactive-favourites.module';
import { SavefavouriteintractiveComponent } from './_Components/Pages/savefavouriteintractive/savefavouriteintractive.component';
import { ViewfavouriteinteractiveComponent } from './_Components/Pages/viewfavouriteinteractive/viewfavouriteinteractive.component';
import { ViewfavouriteinteractiveModule } from './_Components/Pages/viewfavouriteinteractive/viewfavouriteinteractive.module';
import { AlertpopupComponent } from './_Components/Pages/alertpopup/alertpopup.component';


const isIE = window.navigator.userAgent.indexOf('MSIE ') > -1 || window.navigator.userAgent.indexOf('Trident/') > -1;
const isIframe = window !== window.parent && !window.opener;



/**
 * Here we pass the configuration parameters to create an MSAL instance.
 * For more info, visit: https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/lib/msal-angular/docs/v2-docs/configuration.md
 */
export function MSALInstanceFactory(): IPublicClientApplication {
  return new PublicClientApplication(msalConfig);
}

/**
 * MSAL Angular will automatically retrieve tokens for resources
 * added to protectedResourceMap. For more info, visit:
 * https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/lib/msal-angular/docs/v2-docs/initialization.md#get-tokens-for-web-api-calls
 */
export function MSALInterceptorConfigFactory(): MsalInterceptorConfiguration {
  const protectedResourceMap = new Map<string, Array<string | ProtectedResourceScopes> | null>();

  protectedResourceMap.set(protectedResources.todoListApi.endpoint, [
    {
      httpMethod: 'GET',
      scopes: [...protectedResources.todoListApi.scopes.read]
    },
    {
      httpMethod: 'POST',
      scopes: [...protectedResources.todoListApi.scopes.write]
    },
    {
      httpMethod: 'PUT',
      scopes: [...protectedResources.todoListApi.scopes.write]
    },
    {
      httpMethod: 'DELETE',
      scopes: [...protectedResources.todoListApi.scopes.write]
    }
  ]);

  return {
    interactionType: InteractionType.Popup,
    protectedResourceMap,
  };
}

/**
 * Set your default interaction type for MSALGuard here. If you have any
 * additional scopes you want the user to consent upon login, add them here as well.
 */
export function MSALGuardConfigFactory(): MsalGuardConfiguration {
  return {
    interactionType: InteractionType.Redirect,
    authRequest: loginRequest
  };
}


@NgModule({
  declarations: [
    AppComponent,
    ContainerComponent,
    ConfirmdeletePopupComponent,
    // ViewfavouriteinteractiveComponent,
    // SavefavouriteintractiveComponent,
    // InteractiveFavouritesComponent,



  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    NgxSpinnerModule,
    MatSnackBarModule,
    AdminheaderModule,
    FooterModule,
    MsalModule,
    ToastModule.forRoot({ timeOut: 2000, enableHtml: true }),
    RouterModule.forRoot([
      {
        path: 'login',
        loadChildren: () => import('./_Components/Auth/login/login.module').then(m => m.LoginModule)
      },
      {
        path: '',
        loadChildren: () => import('./_Components/Auth/login/login.module').then(m => m.LoginModule)
      },
      {
        path: 'profile',
        component: ContainerComponent,
        loadChildren: () => import('./_Components/Pages/profile/profile.module').then(m => m.ProfileModule),
        canActivate: [MsalGuard]
      },
      {
        path: 'code',
        component: ContainerComponent,
        loadChildren: () => import('./_Components/Pages/home/home.module').then(m => m.HomeModule),
        canActivate: [MsalGuard]
      },
      {
        path: 'solubilityrun',
        component: ContainerComponent,
        loadChildren: () => import('./_Components/Pages/solubilityrun/solubilityrun.modules').then(m => m.SolubilityrunModule)
        , canActivate: [MsalGuard]
      },
      {
        path: 'solubilityrun/:id',
        component: ContainerComponent,
        loadChildren: () => import('./_Components/Pages/solubilityrun/solubilityrun.modules').then(m => m.SolubilityrunModule)
        , canActivate: [MsalGuard]
      },

      {
        path: 'statistictools',
        component: ContainerComponent,
        loadChildren: () => import('./_Components/Pages/statistictools/statistictools.module').then(m => m.StatistictoolsModule),
        canActivate: [MsalGuard]
      },
      {
        path: 'joblist',
        component: ContainerComponent,
        loadChildren: () => import('./_Components/Pages/joblist/joblist.module').then(m => m.JoblistModule),
        canActivate: [MsalGuard]
      },
      {
        path: 'comparisonchart',
        component: ContainerComponent,
        loadChildren: () => import('./_Components/Pages/comparison-chart/comparison-chart.module').then(m => m.ComparisonChartModule)
        , canActivate: [MsalGuard]
      },
      {
        path: 'solubilityruntype',
        component: ContainerComponent,
        loadChildren: () => import('./_Components/Pages/solubility-runtype/solubility-runtype.module').then(m => m.SolubilityRuntypeModule)
        , canActivate: [MsalGuard]
      },
      {
        path: 'solubilityruntype?wasm=1',
        component: ContainerComponent,
        loadChildren: () => import('./_Components/Pages/solubility-runtype/solubility-runtype.module').then(m => m.SolubilityRuntypeModule)
        , canActivate: [MsalGuard]
      },
      {
        path: 'filteredbyproject&compound',
        component: ContainerComponent,
        loadChildren: () => import('./_Components/Pages/filteredreport/filteredreport.module').then(m => m.FilteredreportModule)
        , canActivate: [MsalGuard]
      },
      {
        path: 'filteredbyproject&compound/:id',
        component: ContainerComponent,
        loadChildren: () => import('./_Components/Pages/filteredreport/filteredreport.module').then(m => m.FilteredreportModule)
        , canActivate: [MsalGuard]
      },
      {
        path: 'filterbyjobname',
        component: ContainerComponent,
        loadChildren: () => import('./_Components/Pages/filterby-jobname/filterby-jobname.module').then(m => m.FilterbyJobnameModule)
        , canActivate: [MsalGuard]
      },
      {
        path: 'filterbyjobname/:id',
        component: ContainerComponent,
        loadChildren: () => import('./_Components/Pages/filterby-jobname/filterby-jobname.module').then(m => m.FilterbyJobnameModule)
        , canActivate: [MsalGuard]
      },
      {
        path: 'filterbystructure',
        component: ContainerComponent,
        loadChildren: () => import('./_Components/Pages/filterby-structure/filterby-structure.module').then(m => m.FilterbyStructureModule)
        , canActivate: [MsalGuard]
      },
      {
        path: 'filterbystructure?wasm=1',
        component: ContainerComponent,
        loadChildren: () => import('./_Components/Pages/filterby-structure/filterby-structure.module').then(m => m.FilterbyStructureModule)
        , canActivate: [MsalGuard]
      },
      // {
      //   path: 'filterbystructure/:id',
      //   component: ContainerComponent,
      //   loadChildren: () => import('./_Components/Pages/filterby-structure/filterby-structure.module').then(m => m.FilterbyStructureModule)
      //   , canActivate: [MsalGuard]
      // },
      {
        path: 'myfavourite',
        component: ContainerComponent,
        loadChildren: () => import('./_Components/Pages/my-favourite/my-favourite.modules').then(m => m.MyFavouriteModule)
        , canActivate: [MsalGuard]
      },
      {
        path: 'solubilityrunlocus/:id',
        component: ContainerComponent,
        loadChildren: () => import('./_Components/Pages/solubilityrunlocus/solubilityrunlocus.modules').then(m => m.SolubilityrunlocusModule)
        , canActivate: [MsalGuard]
      },
      {
        path: 'favouriteresult',
        component: ContainerComponent,
        loadChildren: () => import('./_Components/Pages/favourite-result/favourite-result.module').then(m => m.FavouriteresultModule)
        , canActivate: [MsalGuard]
      },
      {
        path: 'multireports',
        component: ContainerComponent,
        loadChildren: () => import('./_Components/Pages/mulitireports/mulitireports.module').then(m => m.MulitireportsModule)
        , canActivate: [MsalGuard]
      },
      {
        path: 'barchart',
        component: ContainerComponent,
        loadChildren: () => import('./_Components/Pages/barchart/barchart.module').then(m => m.BarchartModule)
        , canActivate: [MsalGuard]
      },
      {
        path: 'interactivefavourites',
        component: ContainerComponent,
        loadChildren: () => import('./_Components/Pages/interactive-favourites/interactive-favourites.module').then(m => m.InteractiveFavouritesModule)
        , canActivate: [MsalGuard]
      },
      {
        path: 'interactivefavourites/:id',
        component: ContainerComponent,
        loadChildren: () => import('./_Components/Pages/interactive-favourites/interactive-favourites.module').then(m => m.InteractiveFavouritesModule)
        , canActivate: [MsalGuard]
      },
      {
        path: 'viewinteractivefavourite',
        component: ContainerComponent,
        loadChildren: () => import('./_Components/Pages/viewfavouriteinteractive/viewfavouriteinteractive.module').then(m => m.ViewfavouriteinteractiveModule)
        , canActivate: [MsalGuard]
      },
      {
        path: 'viewinteractivefavourite/:id',
        component: ContainerComponent,
        loadChildren: () => import('./_Components/Pages/viewfavouriteinteractive/viewfavouriteinteractive.module').then(m => m.ViewfavouriteinteractiveModule)
        , canActivate: [MsalGuard]
      },
    ],
    
      {
        anchorScrolling: 'enabled', useHash: false, scrollPositionRestoration: 'enabled', initialNavigation: !isIframe ? 'enabled' : 'disabled'
      }),
    BrowserAnimationsModule,
    MsalModule.forRoot(new PublicClientApplication({
      // Azure AD
      auth: {
        // clientId: '059880bb-8f18-4544-bc44-13da00f0dbd4', //client ID
        // authority: 'https://login.microsoftonline.com/8789cd3a-74b6-41ae-8992-8be37e5f6bd1', // Tenant ID
        // Client
        clientId: '68bc57e2-8db2-460a-949e-662decf6c001', //client ID
        authority: 'https://login.microsoftonline.com/581d7d77-8051-4f10-95ac-b1aeff53d129', // Tenant ID
        redirectUri: 'http://localhost:4200',
      },
      cache: {
        cacheLocation: 'localStorage',
        storeAuthStateInCookie: isIE,
      }
    }), {
      interactionType: InteractionType.Redirect,
      authRequest: { 
        // scopes: ['api://e0faf002-14b0-4201-9182-a25df4730e4b/access_as_user'] // user.read
        // client
        scopes: ['api://6a7a0e7f-6a9a-45fe-aa3b-59d806925638/access_as_user']  // Backend app1
        // scopes: ['api://24db8ba4-e61e-48d6-9ec6-bd3d48d7562e/access_as_user']  // Backend app2
      }
    }, {
      interactionType: InteractionType.Redirect, // MSAL Interceptor Configuration
      protectedResourceMap: new Map([
        ['Enter_the_Graph_Endpoint_Here/v1.0/me', ['user.read']]
      ])
    })
  ],
  entryComponents: [MyfavouritePopupComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],

  // auth: {
  //        clientId: '9067c884-9fa6-414f-9aa4-a565b1cb46be', // This is the ONLY mandatory field that you need to supply.
  //        authority: 'https://fabrikamb2c.b2clogin.com/fabrikamb2c.onmicrosoft.com/b2c_1_susi_reset_v2', // Defaults to "https://login.microsoftonline.com/common"
  //        redirectUri: '/', // Points to window.location.origin. You must register this URI on Azure portal/App Registration.
  //      },

  providers: [
    // {
    //   provide: APP_INITIALIZER,
    //   useFactory: appInitializer,
    //   multi: true,
    //   deps: [AuthenticationService],
    // },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: MsalInterceptor,
      multi: true
    },

    {
      provide: MSAL_INSTANCE,
      useFactory: MSALInstanceFactory
    },
    {
      provide: MSAL_GUARD_CONFIG,
      useFactory: MSALGuardConfigFactory
    },
    {
      provide: MSAL_INTERCEPTOR_CONFIG,
      useFactory: MSALInterceptorConfigFactory
    },
    MsalService,
    MsalBroadcastService,
    WebapiService,
    MsalGuard, // MsalGuard added as provider here
    { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
  ],
  bootstrap: [AppComponent, MsalRedirectComponent]
})
export class AppModule {

  // appInitializer(){
  //   return () => new Promise(resolve => {
  //         // attempt to refresh token on app start up to auto authenticate
  //         this.authenticationService.refreshToken()
  //             .subscribe()
  //             .add(resolve);
  //     });
  // }
}
