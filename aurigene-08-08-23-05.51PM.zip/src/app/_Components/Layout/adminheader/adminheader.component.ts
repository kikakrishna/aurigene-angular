import { Component, OnInit, OnDestroy, Inject } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AuthenticationService } from 'src/app/_Services/authentication.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastService } from 'ng-uikit-pro-standard';

import { MsalService, MsalBroadcastService, MSAL_GUARD_CONFIG, MsalGuardConfiguration } from '@azure/msal-angular';
import { InteractionStatus, RedirectRequest } from '@azure/msal-browser';
import { Subject } from 'rxjs';
import { filter, takeUntil } from 'rxjs/operators';

import { FormControl, FormGroup, NgForm, FormBuilder, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { SolubilityService } from 'src/app/_Services/solubility.service';
import * as moment from 'moment';



@Component({
  selector: 'app-adminheader',
  templateUrl: './adminheader.component.html',
  styleUrls: ['./adminheader.component.css']
})
export class AdminheaderComponent implements OnInit {

  menusection: boolean = false;
  userinfo;
  username;
  usernamesession;
  modelid: any;
  modelname: any;
  mobilename: any = []
  showmodel: boolean = false;
  modellist: boolean = true;
  constructor(@Inject(MSAL_GUARD_CONFIG) private msalGuardConfig: MsalGuardConfiguration,
    private broadcastService: MsalBroadcastService, private authService: MsalService,
    public authenticationService: AuthenticationService, public dialog: MatDialog, public router: Router,
    private toastrService: ToastService, private _solubilityservice: SolubilityService,
    public _activatedRoute: ActivatedRoute,
  ) {
    this.modelid = localStorage.getItem('modelid');
    this.modelname = localStorage.getItem('modelname');
  }

  ngOnInit(): void {

    console.log(this.router.url);

    this._activatedRoute.paramMap.subscribe(params => {
      console.log(params);

      // if (params?.get('id')) {
      //   this.servid = params?.get('id');
      // }
    })
 
    if (this.router.url == "/joblist") {
      this.modellist = false
    } else {
      this.modellist = true

    }
    if (this.router.url == "/multireports" || this.router.url == "/interactivefavourites" || this.router.url == "/viewinteractivefavourite") {
      this.showmodel = false
    } else {
      this.showmodel = true
    }

    console.log(this.modelid);
    this.modelid = localStorage.getItem('modelid');
    this.modelname = localStorage.getItem('modelname');

    this._solubilityservice.getmobile()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.error) {
          this.mobilename = res.responseMessage
          console.log(this.mobilename);
          if (this.modelid == null) {
            console.log("nulll");
            localStorage.setItem('modelid', this.mobilename[0].modelid);
            localStorage.setItem('modelname', this.mobilename[0].modelname);
          }
        } else {
        }
      },
        err => {
        });


    this.modelid = localStorage.getItem('modelid');
    this.modelname = localStorage.getItem('modelname');

    this.getUserDetails();

    if (localStorage.getItem('Loggedin-user')) {
      this.usernamesession = localStorage.getItem('Loggedin-user');
    }

  }

  getUserDetails(): void {
    this._solubilityservice.getuserdetails()
      .pipe(first())
      .subscribe((res: any) => {
        console.log('logged user response: ', res)
        if (res.responseMessage) {
          this.username = res.responseMessage[0].firstname;
          localStorage.setItem('Loggedin-user', res.responseMessage[0].firstname);


          //localStorage.removeItem('token');  
          console.log('user', res.responseMessage.firstname, res.responseMessage.userguid, res.responseMessage.email)
        }
      }
      )
  }

  /*logout() {
    this.authenticationService.logout();
    // this.authenticationService.currentUserSubject.next(null);
    // sessionStorage.clear();
    // this.router.navigate(['/login']);
  }*/

  logout() { // Add log out function here
    localStorage.removeItem('Loggedin-user');
    this.authService.logoutRedirect({
      postLogoutRedirectUri: 'https://localhost:4200'
    });
  }

  updatePassword() {
    // const dialogRef = this.dialog.open(UpdatepasswordComponent, {
    //   width: '330px',
    //   panelClass: 'updatepassword-dialog',
    //   autoFocus: false,
    // });
    // dialogRef.afterClosed().subscribe((result) => {
    //   if (result) {
    //     console.log(result)

    //   }
    // },

    // );
  }

  openmenu() {
    this.menusection = !this.menusection;
  }

  closemenu() {
    // console.log(ele);
    // localStorage.setItem('modelid', ele.modelid);
    // localStorage.setItem('modelname', ele.modelname);
    this.menusection = false;
    // this.router.navigate(['/joblist']);
  }
  closemenueve(ele) {
    console.log(ele);
    localStorage.setItem('modelid', ele.modelid);
    localStorage.setItem('modelname', ele.modelname);
    this.menusection = false;
    this.router.navigate(['/joblist']);
  }

  updateFees() {
    // const dialogRef = this.dialog.open(AdminUpdatefeeComponent, {
    //   width: '330px',
    //   panelClass: 'updatepassword-dialog',
    //   autoFocus: false,
    // });
    // dialogRef.afterClosed().subscribe((result) => {
    //   if (result) {
    //     console.log(result)

    //   }
    // },

    // );
  }

  // public getPageUrl(pageNumber: number): Observable<string> {
  //   return this.route.url.pipe(
  //     map((segments: UrlSegment[]) => {
  //       return {
  //         params: segments, queryParams: { startIndex: pageNumber };
  //       })
  //   );
  // }

}
