// import { Component, OnInit } from '@angular/core';
import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { FormControl, FormGroup, NgForm, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { FormGroupDirective } from '@angular/forms';
import { first } from 'rxjs/operators';
import { ToastService } from 'ng-uikit-pro-standard';
import { SolubilityService } from 'src/app/_Services/solubility.service';
import { ChartConfiguration, ChartOptions, ChartType, ChartData } from "chart.js";
import { SelectionModel } from '@angular/cdk/collections';
import * as moment from 'moment';
import { MatDialog } from '@angular/material/dialog';
// import DataLabelsPlugin from 'chartjs-plugin-datalabels';
import { MatOption } from "@angular/material/core";
import { MatSelect } from "@angular/material/select";

@Component({
  selector: 'app-barchart',
  templateUrl: './barchart.component.html',
  styleUrls: ['./barchart.component.css']
})
export class BarchartComponent implements OnInit {

  displayedColumns: string[] = ['smile', 'logsvalue', 'version'];
  // datasource = ELEMENT_DATA;
  @ViewChild('joblistpaginator', { read: MatPaginator }) joblistpaginator: MatPaginator;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild('filteredreportpaginator', { read: MatPaginator }) filteredreportpaginator: MatPaginator;

  public dataSource: any = new MatTableDataSource([]);
  job_id: any;
  addressmodel: any;
  loading: boolean;
  req: any;
  comparisonform: FormGroup;
  myForm: FormGroup;
  Selectedcompoundid: any;
  btnAction: boolean;
  testitatus: any;
  jobname: any;
  createdtime: any;
  searchinput: any;
  listdata: boolean;
  filterData: boolean;
  applyfilterData: boolean = false;
  projectid: any;
  projectcompound: any;
  projectselector: any = [];
  projectcode: any;
  selectedCompound: any
  mystartDate: any;
  maxDate = new Date();
  selectedstartdate: any;
  myEndDate: any;
  dysdate: any;
  dyedate: any;
  filtertypeid: any;
  sendobject: any;
  getsmilelist: any;
  downloadname: any;
  selectedenddate: any;

  getchart: Boolean;
  data: any = [];
  tableView: boolean = false;


  // public lineChartLabels = ['2000', '2001', '2002', '2003', '2004', '2005'];
  public lineChartLabels = ['S1', 'S2', 'S3', 'S4', 'S5'];
  // public barChartLabels = ['S1', 'S2', 'S3', 'S4', 'S5', 'S6', 'S7', 'S8', 'S9', 'S10', 'S11', 'S12', 'S13', 'S14', 'S15'];
  public barChartLabels = [];

  public lineChartType = 'line';
  public lineChartLegend = true;
  public lineChartOptions = {
    elements: {
      line: {
        tension: 0.0
      }
    }
  }
  public barChartType = 'bar';
  public lineChartData = [
    // { data: [2, 2.5, 2, 2.2, 2, 2.5], label: 'Series A', borderColor: '#20c997', pointBackgroundColor: '#fff', pointBorderColor: '#20c997', fill: 'transparent' },
    // { data: [1.5, 2, 1.4, 2, 1.5, 2], label: 'Series B', borderColor: '#17a2b8', pointBackgroundColor: '#fff', pointBorderColor: '#17a2b8', fill: 'transparent' }


    { data: [1, 2, 3, 4, 5], label: 'A1', borderColor: '#17a2b8', pointBackgroundColor: '#fff', pointBorderColor: '#17a2b8', fill: 'transparent' },
    { data: [0, 0, 0, 4, 6], label: 'A2', borderColor: '#f0dc07', pointBackgroundColor: '#fff', pointBorderColor: '#17a2b8', fill: 'transparent' },
    //{ data: [1,2], label: 'C2=CC=CC=C2', borderColor: '#0f0f0a', pointBackgroundColor: '#fff', pointBorderColor: '#0f0f0', fill: 'transparent' },
    //{ data: [2.4,2.9 ], label: 'C2=CC=', borderColor: '#b81667', pointBackgroundColor: '#fff', pointBorderColor: '#17a2b8', fill: 'transparent' },
    // { data: [ 0.2, 0.4, 0.6, 0.8, ], label: 'algorithm 4"', borderColor: '#b81667', pointBackgroundColor: '#fff', pointBorderColor: '#17a2b8', fill: 'transparent' },

  ];


  job: any = [-1.8, -1.8, -2.2, -2.4, -3.2, -3.8, -4.2, 0, -3.3, 0, 0, -2.7, -1.8, -2.9, -4.0];

  public barChartLegend = true;
  public barChartPlugins = [];
  public barChartData = []
  // [

  //   // { data: this.job, label: this.data[0].version },
  //   { data: [0, -3.8, -3.2, -2.1, -1.2, -0.8, -0.5, -4.2, 0, -2, -1.8, 0, -4.0, -3.8, -2.5], label: 'Version 2' },
  //   // { data: [-1.8, -1.8, -2.2, -2.4, -3.2, -3.8, -4.2, 0, -3.3, 0, 0, -2.7, -1.8, -2.9, -4.0], label: 'Version 3' },
  //   // { data: [-1.8, -1.8, -2.2, -2.4, -3.2, -3.8, -4.2, 0, -3.3, 0, 0, -2.7, -1.8, -2.9, -4.0], label: 'Version 4' },
  //   // { data: [-1.8, -1.8, -2.2, -2.4, -3.2, -3.8, -4.2, 0, -3.3, 0, 0, -2.7, -1.8, -2.9, -4.0], label: 'Version 5' },
  //   // { data: [-1.8, -1.8, -2.2, -2.4, -3.2, -3.8, -4.2, 0, -3.3, 0, 0, -2.7, -1.8, -2.9, -4.0], label: 'Version 6' },


  // ];

  public barChartOptions = {
    responsive: true,
  };
  modelid: string;
  modelname: string;








  constructor(
    private _formBuilder: FormBuilder,
    public toastrService: ToastService,
    private _solubilityservice: SolubilityService,
    private router: Router,

  ) {
    this.modelid = localStorage.getItem('modelid');
    this.modelname = localStorage.getItem('modelname');
   }
  ngOnInit(): void {
    // this.loading = true;
    this.getchart = false;

    var chartdata = [];
    var smileLabel = [];


    console.log('datavalue==============>' + JSON.stringify(this.barChartData))


    // Form validation
    this.comparisonform = this._formBuilder.group({
      compound: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9 ]*$')]],
      startdate: ['', [Validators.required]],
      enddate: ['', [Validators.required]],

    });


    this.myForm = this._formBuilder.group({
      // jobname: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9 ]*$')]],
      project: ['', []],
      compound: ['', []],
      startdate: ['',],
      enddate: ['',],

    });


    // get Filtered project dropdown  
    this._solubilityservice.getFilteredproject(this.modelid)
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res?.responseMessage)
        this.projectcode = res?.data;
      },
        err => {
        });

    this.dateenabled();
    this.datevalidation();

  }


  datevalidation() {
    if (this.myForm.value.startdate == "" || this.myForm.value.startdate == null || this.myForm.value.startdate == undefined) {
      this.myForm.controls.enddate.disable();
      return;
    }
  }

  getsmilefilter(formData: any, formDirective: FormGroupDirective) {
    // this.inputparam = ""
    this.tableView = false;

    if (this.myForm.value.startdate && (this.myForm.value.enddate == null || this.myForm.value.enddate == "" || this.myForm.value.enddate == undefined)) {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please select end date', options);
      this.loading = false;
      return;
    }
    // clear chart
    this.getchart = false
    this.barChartData = []
    this.barChartLabels = []

    if (this.projectid == "") {
      this.Selectedcompoundid = []
      this.projectcompound = []
      this.myForm.controls.compound.reset();
    }
    let sDate = "";
    let eDate = "";
    console.log('users---> ', this.myForm.value)
    if (this.myForm.value.startdate != '' && this.myForm.value.enddate != '') {

      sDate = moment(this.myForm.value.startdate).format('YYYY-MM-DD');
      eDate = moment(this.myForm.value.enddate).format('YYYY-MM-DD');
      this.dysdate = moment(this.myForm.value.startdate).format('YYYY-MM-DD');
      this.dyedate = moment(this.myForm.value.enddate).format('YYYY-MM-DD');
    }
    if (this.myForm.value.startdate == '' || this.myForm.value.startdate == null && this.myForm.value.enddate == '' || this.myForm.value.enddate == null) {

      var currentDate = moment(new Date());
      var futureMonth = moment(currentDate).add(1, 'M');
      var futureMonthEnd = moment(futureMonth).endOf('month');
      const datde = new Date();
      let dydate = new Date(datde.getFullYear(), datde.getMonth() - 1, datde.getDate())
      sDate = moment(dydate).format('YYYY-MM-DD');
      if (currentDate.date() != futureMonth.date() && futureMonth.isSame(futureMonthEnd.format('YYYY-MM-DD'))) {
        futureMonth = futureMonth.add(1, 'd');
      }
      eDate = moment(currentDate).format('YYYY-MM-DD');
      this.dysdate = sDate;
      this.dyedate = eDate;
    }

    this.loading = true;

    if ((this.projectid == undefined || this.projectid == '' || this.projectid == null) && (this.Selectedcompoundid == undefined || this.Selectedcompoundid == '' || this.Selectedcompoundid == null)) {

      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please select project', options);
      this.loading = false;

    } else if (this.projectid && (this.Selectedcompoundid == undefined || this.Selectedcompoundid == '' || this.Selectedcompoundid == null)) {
      const formobject = {
        projectid: this.projectid,
        startdate: this.dysdate,
        enddate: this.dyedate,
        modelid : this.modelid
        // typeid: this.filtertypeid
      }
      this.sendobject = formobject
      this._solubilityservice.getchartproject(this.sendobject,this.modelid)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.error) {
            this.getsmilelist = res?.data;
            this.loading = false;
            this.getchart = true;
            console.log(res?.data.length)
            if (this.getsmilelist.length == 0) {
              this.getchart = false;
              this.getchart = false;
              this.barChartData = []
              this.barChartLabels = []
            }
            if (res?.responseMessage.length > 0) {
              this.dataSource = new MatTableDataSource(res?.responseMessage)
            }

            var chartdata;
            this.barChartLabels = []
            this.barChartData = []
            console.log('pro&comp-----------------------------' + JSON.stringify(this.barChartLabels))
            console.log('pro&comp-----------------------------' + JSON.stringify(this.barChartData))

            for (var i = 0; i < this.getsmilelist.length; i++) {
              chartdata = [];
              console.log("i-------" + i)

              console.log("element-------smile" + this.getsmilelist[i].smiledetails.length)
              for (var j = 0; j < this.getsmilelist[i].smiledetails.length; j++) {
                console.log("element-------smile" + this.getsmilelist[i].smiledetails[j].smile)

                if (this.barChartLabels.length > 0) {

                  if (!this.barChartLabels.includes(this.getsmilelist[i].smiledetails[j].smile)) {
                    this.barChartLabels.push(this.getsmilelist[i].smiledetails[j].smile);
                  }
                } else {
                  this.barChartLabels.push(this.getsmilelist[i].smiledetails[j].smile);
                }
                chartdata.push(this.getsmilelist[i].smiledetails[j].logsvalue)
              }
              var subdata = {
                data: chartdata,
                label: this.getsmilelist[i].version,
                borderColor: '#17a2b8',
              }
              this.barChartData.push(subdata)
            }
          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            // const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            // this.toastrService.warning('', err?.error, options);
          });
    } else {
      this.loading = true;
      const formobject = {
        projectid: this.projectid,
        compoundcode: this.Selectedcompoundid,
        startdate: this.dysdate,
        enddate: this.dyedate,
        // typeid: this.filtertypeid
      }
      this.sendobject = formobject
      this._solubilityservice.getchartprojectcomp(this.sendobject,this.modelid)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.error) {
            this.getsmilelist = res?.data;
            console.log(res?.data.length)
            this.dataSource = new MatTableDataSource(res?.responseMessage)
            console.log("ghstghsrthr" + this.getsmilelist)
            this.getchart = true
            if (this.getsmilelist.length == 0) {
              this.getchart = false
            }
            if (res?.responseMessage.length > 0) {
              // this.tableView = true;
              this.dataSource = new MatTableDataSource(res?.responseMessage)
            }
            var chartdata;
            this.barChartLabels = []
            this.barChartData = []
            this.loading = false;
            console.log('pro&comp-----------------------------' + JSON.stringify(this.barChartLabels))
            // console.log('pro&comp-----------------------------' + JSON.stringify(this.barChartData))
            for (var i = 0; i < this.getsmilelist.length; i++) {
              chartdata = [];
              console.log("i-------" + i)
              console.log("element-------smile" + this.getsmilelist[i].smiledetails.length)
              for (var j = 0; j < this.getsmilelist[i].smiledetails.length; j++) {
                console.log("element-------smile" + this.getsmilelist[i].smiledetails[j].smile)
                if (this.barChartLabels.length > 0) {

                  if (!this.barChartLabels.includes(this.getsmilelist[i].smiledetails[j].smile)) {
                    this.barChartLabels.push(this.getsmilelist[i].smiledetails[j].smile);
                  }
                } else {
                  this.barChartLabels.push(this.getsmilelist[i].smiledetails[j].smile);
                }
                chartdata.push(this.getsmilelist[i].smiledetails[j].logsvalue)
              }
              var subdata = {
                data: chartdata,
                label: this.getsmilelist[i].version,
                borderColor: '#17a2b8',
              }
              this.barChartData.push(subdata)
            }
          }
          else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);

          }
        },
          err => {
            this.loading = false;
            // const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            // this.toastrService.warning('', err?.error, options);
          });
    }

  }

  resetclk() {
    // this.loading = true;
    this.getchart = false;
    this.barChartData = []
    this.barChartLabels = []
    // this.downloadbtn = false;
    // this.savebtn = false;
    this.getsmilelist = []
    this.dataSource = new MatTableDataSource([])
    this.myForm.controls.startdate.reset();
    this.myForm.reset()
    this.projectid = []
    // this.Selectedcompoundid = []
    this.projectcompound = []
    this.dateenabled();
    this.datevalidation();
    this.tableView = false;
    this.projectcompoundStatus = false;
  }


  // get Filtered compound dropdown  
  projectcompoundStatus: boolean = false;
  selectedproject(event) {
    this.Selectedcompoundid = []
    // this.projectcompound = []
    this.myForm.controls.compound.reset();

    var CompoundList = event.value;
    this.projectid = CompoundList
    console.log('product', CompoundList);
    this._solubilityservice.getFilteredcompound(CompoundList, this.modelid)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.error) {
          this.projectcompound = res?.data;
          if(this.projectcompound.length > 0){
            this.projectcompoundStatus = true;
          }
          console.log(this.projectcompound);
        } else {

        }

      },
        err => {
        });
  }



  selectedcompound(event) {
  }

  selectedComp(event) {
    console.log(event.value)
    let selected = event.value.filter(item => item!= 0)
    this.Selectedcompoundid = selected
  }

  dateenabled() {
    if (this.myForm.value.startdate) {
      this.myForm.controls.enddate.reset();
      this.myForm.controls.enddate.enable();
      const sdate = this.myForm.value.startdate;
      this.myEndDate = sdate.toISOString();
    }
  }

  showtableView() {
    this.tableView = true;
  }

  @ViewChild('select') select: MatSelect;
  allSelected = false;
  toggleAllCompound(matSelect: MatSelect) {
    const isSelected: boolean = matSelect.options
      // The "Select All" item has the value 0
      .filter((item: MatOption) => item.value === 0)
      // Get the selected property (this tells us whether Select All is selected or not)
      .map((item: MatOption) => item.selected)[0];
    // Get the first element (there should only be 1 option with the value 0 in the select)

    if (isSelected) {
      matSelect.options.forEach((item: MatOption) => item.select());
    } else {
      matSelect.options.forEach((item: MatOption) => item.deselect());
    }
  }

  checkBoxClick() {
    // console.log(event.compoundcode)
    // console.log(this.select.options)
    // let newStatus = true;
    // this.select.options.forEach((item: MatOption) => {
    //   console.log(item.selected)
    //   if (!item.selected) {
    //     newStatus = false;
    //   }
    // });

    // this.allSelected = newStatus;  
    console.log(this.select.options)
    this.select.options.find(option => option.value === 0)?.deselect();
    console.log(this.projectcompound.length)
    console.log(this.select.options)
    if (this.select.options) {
      // let smile = this.select.options._results;
      // if(smile.length > this.projectcompound.length) {
      //   let ss = smile;
      //   console.log(ss.length)
      //   let remove = ss.shift()
      //   let selectOption;
      //   console.log(this.projectcompound.length)
      //   console.log(ss.length)
      //   if(this.projectcompound.length == ss.length) {
      //     ss.forEach(item => {
      //       console.log(item._selected)
      //       if(item._selected == false) {
      //         selectOption = false;
      //         return
      //       }
      //     })

      //     if(selectOption == false) {
      //       this.select.options.find(option => option.value === 0)?.deselect();
      //     }
      //     else {
      //       this.select.options.find(option => option.value === 0)?.select();
      //     }
      //   }
      // }
    }
  }
}
