import { RouterModule } from "@angular/router";
import { JoblistComponent } from "./joblist.component";
export const JoblistRoutes: RouterModule [] = [
    {
        path: '',
        component: JoblistComponent
    }
]