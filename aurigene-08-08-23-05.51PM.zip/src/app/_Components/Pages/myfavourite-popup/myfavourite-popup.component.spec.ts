import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MyfavouritePopupComponent } from './myfavourite-popup.component';

describe('MyfavouritePopupComponent', () => {
  let component: MyfavouritePopupComponent;
  let fixture: ComponentFixture<MyfavouritePopupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MyfavouritePopupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MyfavouritePopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
