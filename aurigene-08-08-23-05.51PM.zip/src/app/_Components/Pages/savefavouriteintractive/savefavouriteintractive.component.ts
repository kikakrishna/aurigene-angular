import { FormControl, FormGroup, NgForm, FormBuilder, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Component, Inject, OnInit, ViewChild, NgZone, } from '@angular/core';
import { ToastService } from 'ng-uikit-pro-standard';
import { SolubilityService } from 'src/app/_Services/solubility.service';
import { Router } from '@angular/router';
import { first } from 'rxjs/operators';
@Component({
  selector: 'app-savefavouriteintractive',
  templateUrl: './savefavouriteintractive.component.html',
  styleUrls: ['./savefavouriteintractive.component.css']
})
export class SavefavouriteintractiveComponent implements OnInit {
  myfavpopup: FormGroup;
  modelid: any;
  modelname: any;

  constructor(private _formBuilder: FormBuilder,
    public toastrService: ToastService,
    private _solubilityservice: SolubilityService,
    private router: Router,
    public matdialog: MatDialog,
    private _ngZone: NgZone,
    public dialogRef: MatDialogRef<SavefavouriteintractiveComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.modelid = localStorage.getItem('modelid');
    this.modelname = localStorage.getItem('modelname');
  }

  ngOnInit(): void {

    // console.log()
    console.log("data---------", this.data)
    // Form validation
    this.myfavpopup = this._formBuilder.group({
      reportname: ['', [Validators.required]],

    });
  }
  closemenu() {
    this.dialogRef.close();
  }

  savebtn() {
    // console.log("this.data.projectid=======" + this.data.projectid)
    if (this.myfavpopup.valid) {
      console.log(this.data.compoundcode)
      console.log(this.data.searchtypeId)

      if (this.myfavpopup?.value.reportname.trim() !== "") {
        var json = {
          projectid: this.data.projectid,
          compoundcode: this.data.compoundid.toString(),
          startdate: this.data.sdate,
          enddate: this.data.edate,
          reportname: this.myfavpopup?.value.reportname,
          algorithmid: this.data.versionid,
          modelid: this.data.experimentid,
        }

        this._solubilityservice.saveapiinteractive(json)
          .pipe(first())
          .subscribe((res: any) => {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.success('', res.responseMessage, options);
            this.dialogRef.close();

          },
            err => {
            });

      } else {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', 'Please enter valid report name', options);
      }

    } else {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please enter report name', options);

    }


  }
}
