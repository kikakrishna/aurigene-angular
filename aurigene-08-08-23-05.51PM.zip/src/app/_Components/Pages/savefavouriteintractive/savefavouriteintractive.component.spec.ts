import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SavefavouriteintractiveComponent } from './savefavouriteintractive.component';

describe('SavefavouriteintractiveComponent', () => {
  let component: SavefavouriteintractiveComponent;
  let fixture: ComponentFixture<SavefavouriteintractiveComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SavefavouriteintractiveComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SavefavouriteintractiveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
