import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SolubilityrunlocusComponent } from './solubilityrunlocus.component';

describe('SolubilityrunlocusComponent', () => {
  let component: SolubilityrunlocusComponent;
  let fixture: ComponentFixture<SolubilityrunlocusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SolubilityrunlocusComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SolubilityrunlocusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
