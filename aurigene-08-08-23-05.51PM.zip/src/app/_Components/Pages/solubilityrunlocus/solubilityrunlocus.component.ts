import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { ToastService } from 'ng-uikit-pro-standard';
import { FormBuilder, FormControl, FormGroup, Validators, FormGroupDirective } from '@angular/forms';
import { first } from 'rxjs/operators';
import { SolubilityService } from 'src/app/_Services/solubility.service';
import { MatDialog } from '@angular/material/dialog';
import * as moment from 'moment';
import { ActivatedRoute } from '@angular/router';
import { saveAs } from 'file-saver';
// export interface PeriodicElement {
//   logsvalue: number;
//   structure: string;
//   compoundcode: String;
//   batchnumber: String;
//   project: String;
//   createddate: string;
//   solubilitytype:string;
// }
// const ELEMENT_DATA: PeriodicElement[] = [
//    {structure:'cc-cc1-cc)-NO2=C12',compoundcode:'cc-cc1-cc',action:'', batchnumber:'TEST-BAT-098-BC2',project:'P-001',createddate:'Benzimidazole benzamide', logsvalue: -5.2 ,},

// ];

@Component({
  selector: 'app-solubilityrunlocus',
  templateUrl: './solubilityrunlocus.component.html',
  styleUrls: ['./solubilityrunlocus.component.css']
})
export class SolubilityrunlocusComponent implements OnInit {
  // 'createddate','batchnumber',
  // displayedColumns: string[] = ['smile','compoundcode','version','project','logsvalue','structure','solubilitytype', 'desired_number'];
  displayedColumns: string[] = ['desired_number', 'structure', 'compoundcode', 'batchnumber', 'project', 'version', 'logsvalue', 'solubilitytype'];
  // dataSource = ELEMENT_DATA;
  public dataSource: any = new MatTableDataSource([]);
  loading: boolean;
  data: any;
  logsvalue: any;
  tableArray: any = [];
  jobid: any;
  job_jobid: any;
  Apptid: any;
  addressmodel: any;
  jobname: any;
  // id: any;
  respo: any;
  solubilityrun: any;
  listarray: any;
  public id: string;
  locus: string;
  solubilityName: string;
  modelid: any;
  modelname: any;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  constructor(public toastrService: ToastService,
    private _formBuilder: FormBuilder,
    private _solubilityservice: SolubilityService,
    private router: Router,
    public dialog: MatDialog,
    private route: ActivatedRoute,) {

    this.modelid = localStorage.getItem('modelid');
    this.modelname = localStorage.getItem('modelname');
  }

  ngOnInit(): void {

    this.id = this.route.snapshot.paramMap.get('id');
    this.locus = history.state.locus;
    console.log(this.id)
    this.loading = true;

    // let payload = {

    //      "jobid": 149,
    // }
    this.locus = 'true';
    this._solubilityservice.tablelist(this.id, this.locus, this.modelid)

      .pipe(first())
      .subscribe((res: any) => {
        console.log(res?.data)
        if (!res.isError) {
          this.loading = false;
          let array = [];
          this.listarray =
            this.addressmodel = res?.responseMessage;
          this.jobname = res?.data
          if (this.modelname == "Solubility" && res?.data[0].algorithm_name == "V 1.0") {
            this.displayedColumns = ['desired_number', 'structure', 'compoundcode', 'batchnumber', 'project', 'version', 'logsvalue', 'solubilitytype']
          } else {
            this.displayedColumns = ['desired_number', 'structure', 'compoundcode', 'batchnumber', 'project', 'version', 'solubilitytype']

          }
          if (res?.data) {
            this.solubilityName = res?.data[0].smiles;
          }
          for (let item of res?.data) {
            let d = new Date(item?.createdtime);
            console.log("srfdrgrdggdsg" + JSON.stringify(item));
            item.formattedappointmentDate = moment(d).format('MMMM D, YYYY');
            if (item.logsvalue < -4.5) {
              item.low = true;
            } else if (item.logsvalue >= -3.7 && item.logsvalue <= -4.5) {
              item.medium = true;
            } else {
              item.high = true;
            }
            array.push(item);
          }

          this.dataSource = new MatTableDataSource(res?.data);
          setTimeout(() => {
            this.dataSource.paginator = this.paginator;
            this.paginator.firstPage()
          });
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }

  downloadSolubility() {
    this.loading = true;
    let locusJob = true;
    this._solubilityservice.downloadSolublity(this.id, locusJob, this.modelid)
      .pipe(first()).subscribe((res: any) => {
        if (!res.error) {
          this.loading = false;
          console.log(res)
          const data: Blob = new Blob([res], {
            type: 'text/csv'
          });
          saveAs(data, this.solubilityName + ".csv");
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }

      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }
  img: any;
  imgclk(element) {
    console.log(element)
    this.img = element
  }
}
