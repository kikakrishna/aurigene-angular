import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import {MatSelectModule} from '@angular/material/select';
import { ViewfavouriteinteractiveComponent } from './viewfavouriteinteractive.component';
import { ViewfavouriteinteractiveRoutes } from './viewfavouriteinteractive.routes';
import { MatPaginatorModule } from '@angular/material/paginator';

@NgModule({
  declarations: [ViewfavouriteinteractiveComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(ViewfavouriteinteractiveRoutes),
    MatCardModule,
    MatButtonModule,
    MatSelectModule,
    MatPaginatorModule,

  ]
})
export class ViewfavouriteinteractiveModule { }
