import { Component, OnInit,ViewChild } from '@angular/core';
import { ActivatedRoute } from "@angular/router";
import { SolubilityService } from 'src/app/_Services/solubility.service';
import { first } from 'rxjs/operators';
import { ToastService } from 'ng-uikit-pro-standard';
import { MatPaginator } from '@angular/material/paginator';

@Component({
  selector: 'app-viewfavouriteinteractive',
  templateUrl: './viewfavouriteinteractive.component.html',
  styleUrls: ['./viewfavouriteinteractive.component.css']
})
export class ViewfavouriteinteractiveComponent implements OnInit {

  typeid: any;
  data: any;
  globalvalue: any;
  loading: boolean;
  mainResponse: any;
  tempparray: any[];
  headerinfotempparray: any = [];
  exam: any = [];
  tableexperimentname: any = []
  tempparrayvalues: any = []
  nolist: boolean;
  pagelimit:any=2;
  pageoffset:any=1;
  public totalSize = 0;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  constructor(public _activatedRoute: ActivatedRoute,
    private _solubilityservice: SolubilityService,
    public toastrService: ToastService,

  ) { }

  ngOnInit(): void {
    console.log("routedfavinteract");

    this.data = history.state.inputparams;

    console.log(this.data);

    this.getreturnvalues()

  }
  inputparams
  tempparrayvaluedetaail: any = []

  getreturnvalues() {
    console.log(this.globalvalue);
    this.loading = true;
    this._solubilityservice.getinteractivereports(this.data.inputparams.projectid, this.data.inputparams.compoundcode, this.data.inputparams.startdate, this.data.inputparams.enddate, this.data.inputparams.modelid, this.data.inputparams.algorithmid,this.pagelimit,this.pageoffset)
      .pipe(first()).subscribe((res: any) => {
        if (!res.error) {
          this.loading = false;
          console.log(res)
          this.mainResponse = ''
          this.mainResponse = res.data
          console.log(this.mainResponse)
          var ex = []
          var ex1 = []
          this.tempparray = []
          this.headerinfotempparray = []
          this.tableexperimentname = []
          this.exam = []
          this.tempparrayvalues = []
          if (this.mainResponse.Modelsubheadinglist.length > 0) {
            this.nolist = false;

            // -----------------------------loop starting--------------------------------------------
            this.tempparrayvaluedetaail = res.data.jobdetails

            this.totalSize = res.data.count
            console.log(this.tempparrayvaluedetaail);

            // -------------------------------------------------------------
            for (let i of res.data.Modelsubheadinglist) {
              // for (let j of i.versionname) {
              var displayname = i.VersionDisplayname
              var arrt = {
                "title": i.Generate
              }
              ex1.push(arrt)
              if (i.VersionDisplayname == "Solubility-V 1.0") {
                var arrt = {
                  "title": i.Logsvalue
                }
                ex1.push(arrt)

              } else {
                var arrt = {
                  "title": null
                }
                ex1.push(arrt)

              }

              var arrt = {
                "title": i.Classification
              }
              ex1.push(arrt)

              // }

              var arra = {
                // "moleculename": 'water',
                "data": ex
              }
              this.tempparray.push(arra)

              ex = []
            }


            this.headerinfotempparray.push(ex1)
            this.exam = this.headerinfotempparray.flat()
            console.log(this.exam);

            for (let h of res.data.algorithmdetails[0].smilelist) {
              console.log(h.VersionDisplayname);
              this.tableexperimentname.push(h.VersionDisplayname)
            }

            for (let i of res.data.algorithmdetails) {
              console.log(i);

              for (let j of i.smilelist) {
                console.log(j.VersionDisplayname);

                if (j.Generate == null) {
                  ex.push("-")

                } else {
                  if (j.Generate == false) {
                    ex.push("false")
                  } else {
                    ex.push("true")
                  }


                }
                if (j.VersionDisplayname == "Solubility-V 1.0") {
                  if (j.Logsvalue == null) {
                    ex.push("-")

                  } else {
                    ex.push(j.Logsvalue)

                  }
                } else {
                  ex.push(null)

                }


                // if (j.Logsvalue == null) {
                //   ex.push("-")

                // } else {
                //   ex.push(j.Logsvalue)

                // }

                if (j.Classification == null) {
                  ex.push("-")

                } else {
                  ex.push(j.Classification)

                }

              }

              var arrayte = {
                "Structure": 'water',
                "data": ex
              }
              this.tempparrayvalues.push(arrayte)

              ex = []
            }

            console.log(ex);
            console.log(this.tempparrayvalues);

            for (let i in res.data.jobdetails) {

              this.tempparrayvalues[i].Structure = res.data.jobdetails[i].Structure
            }
            console.log(this.tempparrayvalues);

            // --------------------------------------end-----------------------------------------------
          } else {
            console.log("true");

            this.nolist = true
          }

        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }

      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }


  // conformclickgenerate(ele, index, mainindex, structureurl) {
  //   console.log("knbbbb", ele, index);
  //   console.log(structureurl);

  //   // var subindex = index / 3
  //   // console.log("subindex----------------------" + subindex);
  //   // console.log("mainindex===================" + mainindex);

  //   // console.log(this.mainResponse);
  //   // console.log(this.mainResponse.algorithmdetails[mainindex].smilelist[subindex]);
  //   // var mainjson = this.mainResponse.algorithmdetails[mainindex].smilelist[subindex]

  //   if (ele == "false") {

  //     const dialogRef = this.dialog.open(ConfirmdeletePopupComponent, {
  //       width: '28%',
  //       // data: this.sendobject
  //     });
  //     dialogRef.afterClosed().subscribe(result => {
  //       console.log(result);
  //       if (result.data == "yes") {
  //         console.log("generate");
  //         console.log("knbbbb", ele, index);
  //         var subindex = index / 3
  //         console.log("subindex----------------------" + subindex);
  //         console.log("mainindex===================" + mainindex);

  //         console.log(this.mainResponse);
  //         console.log(this.mainResponse.algorithmdetails[mainindex].smilelist[subindex]);
  //         var mainjson = this.mainResponse.algorithmdetails[mainindex].smilelist[subindex]
  //         console.log(mainjson);

  //         var Structure = []
  //         if (mainjson.islocus == true) {

  //           Structure = [
  //             {
  //               "smile": mainjson.Smile,
  //               "compoundCode": mainjson.compoundCode,
  //               "batchNo": mainjson.batchNo,
  //               "componentName": mainjson.componentName,
  //               "projectCode": this.mainprojectcode,
  //               "structureURL": structureurl,
  //             }
  //           ],

  //             console.log(Structure);

  //           let formobject = {
  //             "projectId": this.myForm.value.project,
  //             "Structure": Structure,
  //             "algorithm_id": mainjson.Version_id,
  //             "modelid": mainjson.Model_id,
  //           }
  //           console.log(formobject)
  //           this._solubilityservice.locusjob(formobject)
  //             .pipe(first())
  //             .subscribe((res: any) => {
  //               console.log(res)
  //               if (!res.error) {
  //                 this.loading = false
  //                 this.getreturnvalues()


  //                 const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //                 this.toastrService.success('', "Job Created Successfully", options);
  //               }
  //               else {
  //                 this.loading = false;
  //                 const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //                 this.toastrService.warning('', res.errorMessage, options);
  //               }
  //             },
  //               err => {
  //                 this.loading = false;
  //                 const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //                 this.toastrService.warning('', err?.error, options);
  //               });

  //         } else {
  //           console.log("createjob API");

  //           var wholejson = this.mainResponse.algorithmdetails[mainindex].smilelist[subindex]
  //           var temparra = []
  //           temparra.push(wholejson.Smile)
  //           var formobject = {
  //             "projectCode": this.mainprojectcode,
  //             "projectId": this.myForm.value.project,
  //             "smileslist": temparra,
  //             "algorithm_id": wholejson.Version_id,
  //             "modelid": wholejson.Model_id,
  //           }
  //           this.loading = true;

  //           this._solubilityservice.createsolubilitydata(formobject)
  //             .pipe(first())
  //             .subscribe((res: any) => {
  //               console.log(res)
  //               if (!res.error) {
  //                 this.loading = false;
  //                 console.log(res?.data);
  //                 this.getreturnvalues()

  //                 const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //                 this.toastrService.success('', res.responseMessage, options);
  //               }

  //               else {
  //                 this.loading = false;
  //                 const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //                 this.toastrService.warning('', res.errorMessage, options);
  //               }

  //             },
  //               err => {
  //                 this.loading = false;
  //                 const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //                 this.toastrService.warning('', err?.error, options);
  //               });
  //         }


  //       }
  //     });
  //   }
  // }
  getNext(event){
    console.log("aa");
    console.log(event);
    this.loading = true
    this.pagelimit =event.pageSize
    this.pageoffset=event.pageIndex +1
    // this.pageoffset=event.pageIndex
    // this.pageoffset=2
    // if(event.pageIndex - event.previousPageIndex == 1){
    //   console.log("++");
    //   console.log(event);
    //   this.pageoffset=event.pageIndex +1
    //   console.log(this.pageoffset);
    // }
    // else if (event.pageIndex - event.previousPageIndex == -1){
    //   console.log("--");
    //   console.log(event);
    //   this.pageoffset=event.pageIndex +1
    //   console.log(this.pageoffset);
    // }
    this.getreturnvalues()

  }
}
