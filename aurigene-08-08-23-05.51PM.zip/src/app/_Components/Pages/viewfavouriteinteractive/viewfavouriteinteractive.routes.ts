import { RouterModule } from "@angular/router";
import { ViewfavouriteinteractiveComponent } from "./viewfavouriteinteractive.component";
export const ViewfavouriteinteractiveRoutes: RouterModule [] = [
    {
        path: '',
        component: ViewfavouriteinteractiveComponent
    }
]