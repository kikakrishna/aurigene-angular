import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { FormControl, FormGroup, NgForm, FormBuilder, Validators } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { ActivatedRoute } from "@angular/router";
import { SelectionModel } from '@angular/cdk/collections';
import { FormGroupDirective } from '@angular/forms';
import { ToastService } from 'ng-uikit-pro-standard';
import { SolubilityService } from 'src/app/_Services/solubility.service';
import { Router } from '@angular/router';
import { MatPaginator } from '@angular/material/paginator';
import { MatDialog } from '@angular/material/dialog';
import { MyfavouritePopupComponent } from '../myfavourite-popup/myfavourite-popup.component';
import { first } from 'rxjs/operators';
import * as moment from 'moment';
import { saveAs } from 'file-saver';
import { MatOption } from "@angular/material/core";
import { MatSelect } from "@angular/material/select";
import { ConfirmdeletePopupComponent } from '../confirmdelete-popup/confirmdelete-popup.component';
import { SavefavouriteintractiveComponent } from '../savefavouriteintractive/savefavouriteintractive.component';


@Component({
  selector: 'app-mulitireports',
  templateUrl: './mulitireports.component.html',
  styleUrls: ['./mulitireports.component.css']
})
export class MulitireportsComponent implements OnInit {
  displayedColumns: string[] = ['desired_number', 'structure', 'compoundcode', 'batchnumber', 'project', 'version', 'logsvalue', 'classification'];
  // dataSource = ELEMENT_DATA;
  // 'jobname',
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild('filteredreportpaginator', { read: MatPaginator }) filteredreportpaginator: MatPaginator;
  public dataSource: any = new MatTableDataSource([]);
  selected = 'option1';
  myForm: FormGroup;
  myfavForm: FormGroup;
  maxDate = new Date();

  myHolidayDates;
  selectedDate: any;
  mystartDate: any;
  myEndDate: any;
  downloadname: any;
  timeFrame: any;

  current_date: any;
  loading: boolean;
  stlistdate: any;
  projectcode: any;
  projectcompound: any;

  selectedCompound: any
  dysdate: any;
  dyedate: any;
  projectid: any;
  pageSize: any;
  myfavourite: any;
  ssdate: any;
  eedate: any;
  filtertypeid: any;
  // selection = new SelectionModel<any>(true, []);
  getsmilelist: any;
  Selectedcompoundid: any;
  downloadbtn: boolean;
  savebtn: boolean;

  typeid: any;
  inputparam: any;
  sendobject: any;
  selectedstartdate: any;
  selectedenddate: any;
  arrayx: any = [];
  projectselector: any = [];
  modelid: string;
  modelname: string;
  mobilename: any = []
  algorithm: any;
  data: any;
  tempparray: any[];
  headerinfotempparray: any = [];
  exam: any = [];
  tableexperimentname: any = []
  selectorexp: any;
  selectorversion: any;
  versionsubheader: any = []
  subheader: any = []
  tempparrayvalues: any = []
  mainResponse: any;
  pagelimit: any = 2;
  pageoffset: any = 1;
  nolist: boolean = false
  public totalSize = 0;
  constructor(private _formBuilder: FormBuilder,
    public toastrService: ToastService,
    private _solubilityservice: SolubilityService,
    private router: Router,
    public dialog: MatDialog,
    public _activatedRoute: ActivatedRoute,
  ) {
    this.modelid = localStorage.getItem('modelid');
    this.modelname = localStorage.getItem('modelname');
  }
  tempjos: any
  ngOnInit(): void {
    // this.downloadbtn = false
    // this.savebtn = false

    console.log(this.tableexperimentname);

    this.projectselector = []
    this.arrayx = []
    // Form validation

    this.inputparam = history.state.inputparams;
    this._activatedRoute.paramMap.subscribe(params => {
      if (params?.get('typeid')) {
        this.typeid = params?.get('typeid');
      }
    })


    console.log("inputparams" + JSON.stringify(this.inputparam))
    console.log("typeid" + this.typeid)




    this.myForm = this._formBuilder.group({
      // jobname: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9 ]*$')]],
      project: ['', []],
      compound: ['', []],
      startdate: ['',],
      enddate: ['',],
      experiment: ['',],
      version: ['',],

    });
    // console.log(this.myForm.value.project,  this.myForm.value.experiment, this.myForm.value.version);


    // get Filtered project dropdown  
    // this._solubilityservice.getFilteredproject(this.modelid)
    //   .pipe(first())
    //   .subscribe((res: any) => {
    //     console.log(res?.responseMessage)
    //     this.projectcode = res?.data;
    //   },
    //     err => {
    //     });
    this._solubilityservice.getFilteredprojectformuilti()
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res?.responseMessage)
        this.projectcode = res?.data;
      },
        err => {
        });

    // get Search dropdown
    this._solubilityservice.getSearch()
      .pipe(first())
      .subscribe((res: any) => {
        this.myfavourite = res?.data;
        let filtertype = "Search by Project"
        const filteredtypearray = this.myfavourite.filter((obj) => {
          return obj.reporttype === filtertype;
        });


        setTimeout(() => {
          this.filtertypeid = filteredtypearray[0].typeid;
          console.log("this.filtertypeid-------->" + this.filtertypeid)

        }, 1000);

      },
        err => {
        });

    console.log("this.filtertypeid-------->" + this.filtertypeid)
    this.dateenabled();
    this.datevalidation();

    this.downloadbtn = false;
    this.savebtn = false;


    console.log("oninitrun")

    let sDate = "";
    let eDate = "";
    console.log('users---> ', this.myForm.value)

    if (this.myForm.value.startdate != '' && this.myForm.value.enddate != '') {
      sDate = moment(this.myForm.value.startdate).format('YYYY-MM-DD');
      eDate = moment(this.myForm.value.enddate).format('YYYY-MM-DD');
      this.dysdate = moment(this.myForm.value.startdate).format('YYYY-MM-DD');
      this.dyedate = moment(this.myForm.value.enddate).format('YYYY-MM-DD');
    }
    if (this.myForm.value.startdate == '' || this.myForm.value.enddate == '') {
      var currentDate = moment(new Date());
      var futureMonth = moment(currentDate).add(1, 'M');
      var futureMonthEnd = moment(futureMonth).endOf('month');
      const datde = new Date();
      let dydate = new Date(datde.getFullYear(), datde.getMonth() - 1, datde.getDate())
      sDate = moment(dydate).format('YYYY-MM-DD');
      if (currentDate.date() != futureMonth.date() && futureMonth.isSame(futureMonthEnd.format('YYYY-MM-DD'))) {
        futureMonth = futureMonth.add(1, 'd');
      }
      eDate = moment(currentDate).format('YYYY-MM-DD');
      this.dysdate = sDate;
      this.dyedate = eDate;
    }
    this.loading = true;
    if ((this.projectid == undefined || this.projectid == '' || this.projectid == null) && (this.Selectedcompoundid == undefined || this.Selectedcompoundid == '' || this.Selectedcompoundid == null)) {
      this._solubilityservice.getfilterReportWithoutProjectIdCompoundid(this.modelid, this.dysdate, this.dyedate)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.error) {
            this.getsmilelist = res?.data;
            // this.downloadname = res?.data[0].smile;
            console.log('hdjfvdhbf' + this.downloadname)
            this.dataSource = new MatTableDataSource(this.getsmilelist)
            // console.log("ghstghsrthr" + this.getsmilelist)
            if (this.dataSource.data.length == 0) {
              this.downloadbtn = false;
              this.savebtn = false;

            }
            this.loading = false;
            let array = [];
            for (let item of res?.data) {
              let d = new Date(item?.createdtime);
              // console.log("srfdrgrdggdsg" + JSON.stringify(item));
              item.formattedappointmentDate = moment(d).format('MMMM D, YYYY');
              if (item.logsvalue < -4.5) {
                item.low = true;
              } else if (item.logsvalue >= -3.7 && item.logsvalue <= -4.5) {
                item.medium = true;
              } else {
                item.high = true;
              }
              array.push(item);
            }
            setTimeout(() => {
              this.dataSource.paginator = this.filteredreportpaginator;
              this.filteredreportpaginator.firstPage()
            });
            // this.myForm.reset();
            // formDirective.resetForm();
          }
        },
          err => {
          });




    }


    this.getmodels()
    this.Getalgorithms()



    var ex = []
    var ex1 = []

    this.tempparray = []
    this.headerinfotempparray = []
    this.tableexperimentname = []





  }

  mainvalue: any = []
  valuearray: any = []
  click(ele) {
    console.log(ele);

  }
  getmodels() {
    this._solubilityservice.getmobile()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.error) {
          this.mobilename = res.responseMessage
          // this.projectcompound = res?.data;
          // if(this.projectcompound.length > 0){
          //   this.projectcompoundStatus = true;
          // }
          console.log(this.mobilename);
        } else {

        }
      },
        err => {
        });
  }

  Getalgorithms() {
    this._solubilityservice.GetAlgorithm(this.modelid)
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res?.responseMessage)
        this.algorithm = res?.responseMessage;
      },
        err => {
        });
  }
  // get Filtered compound dropdown  
  projectcompoundStatus: boolean = false;
  projectId: any;
  mainprojectcode: any;
  selectedproject(event) {
    console.log(event.value);

    this.projectId = event.value;
    this.mainprojectcode = event.value;

    console.log(this.mainprojectcode);

    if (event.value != undefined) {
      this.projectcode.map((data) => {
        if (data.projectid == this.projectId) {
          console.log(data.projectname);

          this.mainprojectcode = data.projectname;
        }
      })
    }
    console.log(this.projectcode);
    console.log(this.mainprojectcode);




    this.Selectedcompoundid = []
    this.myForm.controls.compound.reset();
    var CompoundList = event.value;
    this.projectid = CompoundList
    console.log('product', CompoundList);
    this._solubilityservice.getFilteredcompoundinteractive(CompoundList)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.error) {
          this.projectcompound = res?.data;
          if (this.projectcompound.length > 0) {
            this.projectcompoundStatus = true;
          }
          console.log(this.projectcompound);
        } else {

        }
      },
        err => {
        });
  }
  experimentid: any;
  version: any;
  globalvalue: any;
  tempparrayvaluedetaail: any = []
  arraystatic: any = [];
  getsmilefilter() {
    console.log(this.mainResponse);

    this.inputparam = ""
    if (this.myForm.value.project != "" && this.myForm.value.project != null) {

      if (this.myForm.value.experiment != "" && this.myForm.value.experiment != undefined) {

        if (this.myForm.value.version != "" && this.myForm.value.version != undefined) {



          if (this.myForm.value.startdate && (this.myForm.value.enddate == null || this.myForm.value.enddate == "" || this.myForm.value.enddate == undefined)) {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', 'Please select end date', options);
            this.loading = false;
            return;
          }


          this.downloadbtn = true;

          if (this.projectid == "") {
            this.Selectedcompoundid = []
            this.projectcompound = []
            this.myForm.controls.compound.reset();
          }
          let sDate = "";
          let eDate = "";
          console.log('users---> ', this.myForm.value)
          if (this.myForm.value.startdate != '' && this.myForm.value.enddate != '') {
            console.log("date");

            sDate = moment(this.myForm.value.startdate).format('YYYY-MM-DD');
            eDate = moment(this.myForm.value.enddate).format('YYYY-MM-DD');
            this.dysdate = moment(this.myForm.value.startdate).format('YYYY-MM-DD');
            this.dyedate = moment(this.myForm.value.enddate).format('YYYY-MM-DD');
          }
          if (this.myForm.value.startdate == '' || this.myForm.value.startdate == null && this.myForm.value.enddate == '' || this.myForm.value.enddate == null) {

            var currentDate = moment(new Date());
            var futureMonth = moment(currentDate).add(1, 'M');
            var futureMonthEnd = moment(futureMonth).endOf('month');
            const datde = new Date();
            let dydate = new Date(datde.getFullYear(), datde.getMonth() - 1, datde.getDate())
            sDate = moment(dydate).format('YYYY-MM-DD');
            if (currentDate.date() != futureMonth.date() && futureMonth.isSame(futureMonthEnd.format('YYYY-MM-DD'))) {
              futureMonth = futureMonth.add(1, 'd');
            }
            eDate = moment(currentDate).format('YYYY-MM-DD');
            this.dysdate = sDate;
            this.dyedate = eDate;
          }

          this.loading = true;

          console.log(this.dyedate);
          this.globalvalue = ""
          this.globalvalue = {
            projectid: this.myForm.value.project,
            compoundid: this.Selectedcompoundid,
            sdate: this.dysdate,
            edate: this.dyedate,
            experimentid: this.selectedtexpid,
            versionid: this.SelectedversionId
          }
          console.log(this.globalvalue);

          this._solubilityservice.getinteractivereports(this.myForm.value.project, this.Selectedcompoundid, this.dysdate, this.dyedate, this.selectedtexpid, this.SelectedversionId, this.pagelimit, this.pageoffset)
            .pipe(first()).subscribe((res: any) => {
              if (!res.error) {
                this.loading = false;
                this.savebtn = true;

                console.log(res)
                this.mainResponse = ''
                this.mainResponse = res.data
                console.log(this.mainResponse)
                var ex = []
                var ex1 = []
                this.tempparray = []
                this.headerinfotempparray = []
                this.tableexperimentname = []
                this.exam = []
                this.tempparrayvalues = []
                if (this.mainResponse.Modelsubheadinglist.length > 0) {
                  this.nolist = false;
                  this.savebtn = true;
                  var getvalue = []
                  // -----------------------------loop starting--------------------------------------------
                  this.tempparrayvaluedetaail = res.data.jobdetails
                  this.totalSize = res.data.count

                  console.log(this.tempparrayvaluedetaail);

                  // -------------------------------------------------------------
                  for (let i of res.data.Modelsubheadinglist) {
                    // for (let j of i.versionname) {
                    var displayname = i.VersionDisplayname
                    var arrt = {
                      "title": i.Generate
                    }
                    ex1.push(arrt)
                    if (i.VersionDisplayname == "Solubility-V 1.0") {
                      var arrt = {
                        "title": i.Logsvalue
                      }
                      ex1.push(arrt)

                    } else {
                      var arrt = {
                        "title": null
                      }
                      ex1.push(arrt)

                    }

                    var arrt = {
                      "title": i.Classification
                    }
                    ex1.push(arrt)

                    // }

                    var arra = {
                      // "moleculename": 'water',
                      "data": ex
                    }
                    this.tempparray.push(arra)

                    ex = []
                  }


                  this.headerinfotempparray.push(ex1)
                  this.exam = this.headerinfotempparray.flat()
                  console.log(this.exam);

                  var arraystat = [
                    {
                      "title": "Job name"
                    },
                    {
                      "title": "Desired number"
                    },
                    {
                      "title": "Created by"
                    },
                    {
                      "title": "Created date"
                    },
                    {
                      "title": "Project"
                    },
                    {
                      "title": "Compound code"
                    },
                    {
                      "title": "Batch number"
                    },
                  ]

                  // let arr3 = arraystat.map((item, i) => Object.assign({}, item, this.exam[i]));

                  console.log(this.exam);
                  // ex1.push(arrt)
                  Array.prototype.push.apply(arraystat, this.exam);

                  console.log(arraystat);
                  this.arraystatic = arraystat;

                  // this.setPagination(this.arraystatic);
                  for (let h of res.data.algorithmdetails[0].smilelist) {
                    console.log(h.VersionDisplayname);
                    this.tableexperimentname.push(h.VersionDisplayname)
                  }

                  for (let i of res.data.algorithmdetails) {
                    console.log(i);

                    for (let j of i.smilelist) {
                      console.log(j.VersionDisplayname);

                      if (j.Generate == null) {
                        ex.push("-")

                      } else {
                        if (j.Generate == false) {
                          ex.push("false")
                        } else {
                          ex.push("true")
                        }


                      }
                      if (j.VersionDisplayname == "Solubility-V 1.0") {
                        if (j.Logsvalue == null) {
                          ex.push("-")

                        } else {
                          ex.push(j.Logsvalue)

                        }
                      } else {
                        ex.push(null)

                      }


                      // if (j.Logsvalue == null) {
                      //   ex.push("-")

                      // } else {
                      //   ex.push(j.Logsvalue)

                      // }

                      if (j.Classification == null) {
                        ex.push("-")

                      } else {
                        ex.push(j.Classification)

                      }

                    }

                    var arrayte = {
                      "Structure": 'water',
                      "data": ex
                    }
                    this.tempparrayvalues.push(arrayte)

                    ex = []
                  }

                  console.log(ex);
                  console.log(this.tempparrayvalues);

                  for (let i in res.data.jobdetails) {

                    this.tempparrayvalues[i].Structure = res.data.jobdetails[i].Structure
                  }
                  console.log(this.tempparrayvalues);

                  // --------------------------------------end-----------------------------------------------
                } else {
                  console.log("true");
                  this.savebtn = false;

                  this.nolist = true
                }

              } else {
                this.savebtn = false;
                this.loading = false;
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', res.errorMessage, options);
              }

            },
              err => {
                this.loading = false;
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', err?.error, options);
              });
        } else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', 'Please select version', options);
        }
      } else {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', 'Please select experiement', options);
      }
    } else {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please select project', options);
    }



  }

  dateenabled() {
    if (this.myForm.value.startdate) {
      this.myForm.controls.enddate.reset();
      this.myForm.controls.enddate.enable();
      const sdate = this.myForm.value.startdate;
      this.myEndDate = sdate.toISOString();
      // this.downloadbtn = false;
      // this.savebtn = false;

    }

  }

  datevalidation() {
    if (this.myForm.value.startdate == "" || this.myForm.value.startdate == null || this.myForm.value.startdate == undefined) {
      this.myForm.controls.enddate.disable();
      return;
    }

  }

  selectedComp(event) {
    console.log(event.value)
    let selected = event.value.filter(item => item != 0)
    this.Selectedcompoundid = selected
  }

  selectedtexpid: any = [];
  selectedexp(event) {
    console.log(event.value)

    let selected = event.value.filter(item => item != 0)
    this.selectedtexpid = selected
    console.log(selected);

    this.myForm.controls.version.reset();
    setTimeout(() => {
      this._solubilityservice.getversions(this.selectedtexpid)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.error) {
            console.log(res?.responseMessage);


            setTimeout(() => {
              this.version = res?.responseMessage;

            }, 700);
          } else {

          }
        },
          err => {
          });

    }, 100);

  }
  SelectedversionId: any = [];
  selectedver(event) {
    console.log(event.value)
    // let temp = event.value.splice(0, 1)
    // console.log(temp);

    let selected = event.value.filter(item => item != 0)
    this.SelectedversionId = selected

  }
  resetclk() {
    // this.loading = true;
    this.version = []
    this.nolist = false;
    this.downloadbtn = false;
    this.savebtn = false;
    this.getsmilelist = []
    this.dataSource = new MatTableDataSource(this.getsmilelist)
    this.myForm.controls.startdate.reset();
    this.myForm.reset()
    this.projectid = []
    this.Selectedcompoundid = []
    this.projectcompound = []
    this.dateenabled();
    this.datevalidation();
    this.projectcompoundStatus = false;
    // -------------------------------------------------------------------------
    this.mainResponse = ''
    var ex = []
    var ex1 = []
    this.tempparray = []
    this.headerinfotempparray = []
    this.tableexperimentname = []
    this.exam = []
    this.tempparrayvalues = []
    console.log(this.myForm.value);
    console.log(this.projectid);
    this.pagelimit = 2;

    // if ((this.projectid == undefined || this.projectid == '' || this.projectid == null) && (this.Selectedcompoundid == undefined || this.Selectedcompoundid == '' || this.Selectedcompoundid == null)) {

    //   let sDate = "";
    //   let eDate = "";
    //   var currentDate = moment(new Date());
    //   var futureMonth = moment(currentDate).add(1, 'M');
    //   var futureMonthEnd = moment(futureMonth).endOf('month');
    //   const datde = new Date();
    //   let dydate = new Date(datde.getFullYear(), datde.getMonth() - 1, datde.getDate())
    //   sDate = moment(dydate).format('YYYY-MM-DD');
    //   if (currentDate.date() != futureMonth.date() && futureMonth.isSame(futureMonthEnd.format('YYYY-MM-DD'))) {
    //     futureMonth = futureMonth.add(1, 'd');
    //   }
    //   eDate = moment(currentDate).format('YYYY-MM-DD');
    //   this.dysdate = sDate;
    //   this.dyedate = eDate;
    //   this._solubilityservice.getfilterReportWithoutProjectIdCompoundid(this.modelid, this.dysdate, this.dyedate)
    //     .pipe(first())
    //     .subscribe((res: any) => {
    //       if (!res.error) {
    //         this.getsmilelist = res?.data;
    //         this.dataSource = new MatTableDataSource(this.getsmilelist)
    //         console.log("ghstghsrthr" + this.getsmilelist)
    //         this.loading = false;
    //         let array = [];
    //         for (let item of res?.data) {
    //           let d = new Date(item?.createdtime);
    //           // console.log("srfdrgrdggdsg" + JSON.stringify(item));
    //           item.formattedappointmentDate = moment(d).format('MMMM D, YYYY');
    //           if (item.logsvalue < -4.5) {
    //             item.low = true;
    //           } else if (item.logsvalue >= -3.7 && item.logsvalue <= -4.5) {
    //             item.medium = true;
    //           } else {
    //             item.high = true;
    //           }
    //           array.push(item);

    //         }

    //         setTimeout(() => {
    //           this.dataSource.paginator = this.filteredreportpaginator;
    //           this.filteredreportpaginator.firstPage()
    //           this.dataSource.paginator.pageSize = 0;
    //         });
    //         // this.myForm.reset();
    //         // formDirective.resetForm();
    //       }
    //     },
    //       err => {
    //       });

    // }

  }

  downloadReport() {


    if (this.sendobject.startdate && this.sendobject.enddate && this.sendobject.projectid == undefined) {


      this._solubilityservice.downloadWithoutProjectIdCompoundid(this.sendobject, this.modelid)
        .pipe(first()).subscribe((res: any) => {
          if (!res.error) {
            this.loading = false;
            console.log(res)
            const data: Blob = new Blob([res], {
              type: 'text/csv'
            });
            saveAs(data, this.downloadname + ".csv");
          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }

        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });
    }


    if (this.sendobject.projectid && this.sendobject.compoundcode == undefined) {

      this._solubilityservice.downloadWithProjectId(this.sendobject, this.modelid)
        .pipe(first()).subscribe((res: any) => {
          if (!res.error) {
            this.loading = false;
            console.log(res)
            const data: Blob = new Blob([res], {
              type: 'text/csv'
            });
            saveAs(data, this.downloadname + ".csv");
          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }

        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });
    }


    this.loading = true;

    if (this.sendobject.compoundcode) {
      this._solubilityservice.downloadProjandCompoundReport(this.sendobject, this.modelid)
        .pipe(first()).subscribe((res: any) => {
          if (!res.error) {
            this.loading = false;
            console.log(res)
            const data: Blob = new Blob([res], {
              type: 'text/csv'
            });
            saveAs(data, this.downloadname + ".csv");
          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }

        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });
    }
  }

  openDialog() {
    console.log(this.myForm.value)
    console.log(this.myForm.value.startdate)
    const dialogRef = this.dialog.open(SavefavouriteintractiveComponent, {
      width: '28%',
      data: this.globalvalue
    });
  }

  img: any;
  imgclk(element) {
    console.log(element)
    this.img = element
  }

  // allSelected = false;
  toggleAllCompound(matSelect: MatSelect) {
    const isSelected: boolean = matSelect.options
      // The "Select All" item has the value 0
      .filter((item: MatOption) => item.value === 0)
      // Get the selected property (this tells us whether Select All is selected or not)
      .map((item: MatOption) => item.selected)[0];
    // Get the first element (there should only be 1 option with the value 0 in the select)

    if (isSelected) {
      matSelect.options.forEach((item: MatOption) => item.select());
    } else {
      matSelect.options.forEach((item: MatOption) => item.deselect());
    }
  }

  toggleAllCompoundexperiment(matSelect: MatSelect) {
    const isSelected: boolean = matSelect.options
      // The "Select All" item has the value 0
      .filter((item: MatOption) => item.value === 0)
      // Get the selected property (this tells us whether Select All is selected or not)
      .map((item: MatOption) => item.selected)[0];
    // Get the first element (there should only be 1 option with the value 0 in the select)

    if (isSelected) {
      matSelect.options.forEach((item: MatOption) => item.select());
    } else {
      matSelect.options.forEach((item: MatOption) => item.deselect());
    }
  }

  toggleAllCompoundversion(matSelect: MatSelect) {
    const isSelected: boolean = matSelect.options
      // The "Select All" item has the value 0
      .filter((item: MatOption) => item.value === 0)
      // Get the selected property (this tells us whether Select All is selected or not)
      .map((item: MatOption) => item.selected)[0];
    // Get the first element (there should only be 1 option with the value 0 in the select)

    if (isSelected) {
      matSelect.options.forEach((item: MatOption) => item.select());
    } else {
      matSelect.options.forEach((item: MatOption) => item.deselect());
    }
  }


  checkBoxClick() {

    console.log(this.select.options)
    this.select.options.find(option => option.value === 0)?.deselect();
    // console.log(this.projectcompound.length)
    console.log(this.select.options)

  }


  checkBoxClickexp() {

    console.log(this.select.options)
    this.select.options.find(option => option.value === 0)?.deselect();
    // console.log(this.projectcompound.length)
    console.log(this.select.options)

  }


  checkBoxClickver() {

    console.log(this.select.options)
    this.select.options.find(option => option.value === 0)?.deselect();
    // console.log(this.projectcompound.length)
    console.log(this.select.options)

  }
  @ViewChild('select') select: MatSelect;
  @ViewChild('selectexp') selectexp: MatSelect;
  @ViewChild('selectver') selectver: MatSelect;

  conformclickgenerate(ele, index, mainindex, structureurl) {
    console.log("knbbbb", ele, index);
    console.log(structureurl);

    // var subindex = index / 3
    // console.log("subindex----------------------" + subindex);
    // console.log("mainindex===================" + mainindex);

    // console.log(this.mainResponse);
    // console.log(this.mainResponse.algorithmdetails[mainindex].smilelist[subindex]);
    // var mainjson = this.mainResponse.algorithmdetails[mainindex].smilelist[subindex]

    if (ele == "false") {

      const dialogRef = this.dialog.open(ConfirmdeletePopupComponent, {
        width: '28%',
        // data: this.sendobject
      });
      dialogRef.afterClosed().subscribe(result => {
        console.log(result);
        if (result.data == "yes") {
          console.log("generate");
          console.log("knbbbb", ele, index);
          var subindex = index / 3
          console.log("subindex----------------------" + subindex);
          console.log("mainindex===================" + mainindex);

          console.log(this.mainResponse);
          console.log(this.mainResponse.algorithmdetails[mainindex].smilelist[subindex]);
          var mainjson = this.mainResponse.algorithmdetails[mainindex].smilelist[subindex]
          console.log(mainjson);

          var Structure = []
          if (mainjson.islocus == true) {

            Structure = [
              {
                "smile": mainjson.Smile,
                "compoundCode": mainjson.compoundCode,
                "batchNo": mainjson.batchNo,
                "componentName": mainjson.componentName,
                "projectCode": this.mainprojectcode,
                "structureURL": structureurl,
              }
            ],

              console.log(Structure);

            let formobject = {
              "projectId": this.myForm.value.project,
              "Structure": Structure,
              "algorithm_id": mainjson.Version_id,
              "modelid": mainjson.Model_id,
            }
            console.log(formobject)
            this._solubilityservice.locusjobinteractive(formobject)
              .pipe(first())
              .subscribe((res: any) => {
                console.log(res)
                if (!res.error) {
                  this.loading = false
                  this.getreturnvalues()


                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.success('', "Job Created Successfully", options);
                }
                else {
                  this.loading = false;
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.warning('', res.errorMessage, options);
                }
              },
                err => {
                  this.loading = false;
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.warning('', err?.error, options);
                });

          } else {
            console.log("createjob API");

            var wholejson = this.mainResponse.algorithmdetails[mainindex].smilelist[subindex]
            var temparra = []
            temparra.push(wholejson.Smile)
            var formobject = {
              "projectCode": this.mainprojectcode,
              "projectId": this.myForm.value.project,
              "smileslist": temparra,
              "algorithm_id": wholejson.Version_id,
              "modelid": wholejson.Model_id,
            }
            this.loading = true;

            this._solubilityservice.createsolubilitydatainteractive(formobject)
              .pipe(first())
              .subscribe((res: any) => {
                console.log(res)
                if (!res.error) {
                  this.loading = false;
                  console.log(res?.data);
                  this.getreturnvalues()

                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.success('', res.responseMessage, options);
                }

                else {
                  this.loading = false;
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.warning('', res.errorMessage, options);
                }

              },
                err => {
                  this.loading = false;
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.warning('', err?.error, options);
                });
          }


        }
      });
    }
  }

  getreturnvalues() {
    // this.globalvalue = {
    //   projectid: this.myForm.value.project,
    //   compoundid: this.Selectedcompoundid,
    //   sdate: this.dysdate,
    //   edate: this.dyedate,
    //   experimentid: this.selectedtexpid,
    //   versionid: this.SelectedversionId
    // }
    console.log(this.globalvalue);
    this.loading = true;
    this._solubilityservice.getinteractivereports(this.globalvalue.projectid, this.globalvalue.compoundid, this.globalvalue.sdate, this.globalvalue.edate, this.globalvalue.experimentid, this.globalvalue.versionid, this.pagelimit, this.pageoffset)
      .pipe(first()).subscribe((res: any) => {
        if (!res.error) {
          this.loading = false;
          console.log(res)
          this.mainResponse = ''
          this.mainResponse = res.data
          console.log(this.mainResponse)
          var ex = []
          var ex1 = []
          this.tempparray = []
          this.headerinfotempparray = []
          this.tableexperimentname = []
          this.exam = []
          this.tempparrayvalues = []
          if (this.mainResponse.Modelsubheadinglist.length > 0) {
            this.nolist = false;
            this.savebtn = true;
            // -----------------------------loop starting--------------------------------------------
            this.tempparrayvaluedetaail = res.data.jobdetails


            console.log(this.tempparrayvaluedetaail);

            // -------------------------------------------------------------
            for (let i of res.data.Modelsubheadinglist) {
              // for (let j of i.versionname) {
              var displayname = i.VersionDisplayname
              var arrt = {
                "title": i.Generate
              }
              ex1.push(arrt)
              if (i.VersionDisplayname == "Solubility-V 1.0") {
                var arrt = {
                  "title": i.Logsvalue
                }
                ex1.push(arrt)

              } else {
                var arrt = {
                  "title": null
                }
                ex1.push(arrt)

              }

              var arrt = {
                "title": i.Classification
              }
              ex1.push(arrt)

              // }

              var arra = {
                // "moleculename": 'water',
                "data": ex
              }
              this.tempparray.push(arra)

              ex = []
            }


            this.headerinfotempparray.push(ex1)
            this.exam = this.headerinfotempparray.flat()
            console.log(this.exam);

            for (let h of res.data.algorithmdetails[0].smilelist) {
              console.log(h.VersionDisplayname);
              this.tableexperimentname.push(h.VersionDisplayname)
            }

            for (let i of res.data.algorithmdetails) {
              console.log(i);

              for (let j of i.smilelist) {
                console.log(j.VersionDisplayname);

                if (j.Generate == null) {
                  ex.push("-")

                } else {
                  if (j.Generate == false) {
                    ex.push("false")
                  } else {
                    ex.push("true")
                  }


                }
                if (j.VersionDisplayname == "Solubility-V 1.0") {
                  if (j.Logsvalue == null) {
                    ex.push("-")

                  } else {
                    ex.push(j.Logsvalue)

                  }
                } else {
                  ex.push(null)

                }


                // if (j.Logsvalue == null) {
                //   ex.push("-")

                // } else {
                //   ex.push(j.Logsvalue)

                // }

                if (j.Classification == null) {
                  ex.push("-")

                } else {
                  ex.push(j.Classification)

                }

              }

              var arrayte = {
                "Structure": 'water',
                "data": ex
              }
              this.tempparrayvalues.push(arrayte)

              ex = []
            }

            console.log(ex);
            console.log(this.tempparrayvalues);

            for (let i in res.data.jobdetails) {

              this.tempparrayvalues[i].Structure = res.data.jobdetails[i].Structure
            }
            console.log(this.tempparrayvalues);

            // --------------------------------------end-----------------------------------------------
          } else {
            console.log("true");
            this.savebtn = false;

            this.nolist = true
          }

        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }

      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }


  getNext(event) {
    console.log("aa");
    console.log(event);
    this.loading = true
    this.pagelimit = event.pageSize
    this.pageoffset = event.pageIndex + 1
    // this.pageoffset=event.pageIndex
    // this.pageoffset=2
    // if(event.pageIndex - event.previousPageIndex == 1){
    //   console.log("++");
    //   console.log(event);
    //   this.pageoffset=event.pageIndex +1
    //   console.log(this.pageoffset);
    // }
    // else if (event.pageIndex - event.previousPageIndex == -1){
    //   console.log("--");
    //   console.log(event);
    //   this.pageoffset=event.pageIndex +1
    //   console.log(this.pageoffset);
    // }
    this.getsmilefilter()

  }
}
