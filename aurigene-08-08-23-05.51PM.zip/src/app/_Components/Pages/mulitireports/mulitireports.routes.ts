import { RouterModule } from "@angular/router";
import { MulitireportsComponent } from "./mulitireports.component";
// import { JoblistComponent } from "./joblist.component";

export const MulitireportsRoutes: RouterModule[] = [
    {
        path: '',
        component: MulitireportsComponent
    }
]