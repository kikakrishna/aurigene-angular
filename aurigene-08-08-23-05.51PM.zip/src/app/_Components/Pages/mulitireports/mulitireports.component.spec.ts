import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MulitireportsComponent } from './mulitireports.component';

describe('MulitireportsComponent', () => {
  let component: MulitireportsComponent;
  let fixture: ComponentFixture<MulitireportsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MulitireportsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MulitireportsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
