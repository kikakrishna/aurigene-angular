import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StatistictoolsComponent } from './statistictools.component';

describe('StatistictoolsComponent', () => {
  let component: StatistictoolsComponent;
  let fixture: ComponentFixture<StatistictoolsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StatistictoolsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StatistictoolsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
