import { RouterModule } from "@angular/router";
import {FilterbyStructureComponent } from './filterby-structure.component';
export const FilterbyStructureRoutes: RouterModule [] = [
    {
        path: '',
        component: FilterbyStructureComponent
    }
]