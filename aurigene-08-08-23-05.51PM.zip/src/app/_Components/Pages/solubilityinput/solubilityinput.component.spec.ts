import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SolubilityinputComponent } from './solubilityinput.component';

describe('SolubilityinputComponent', () => {
  let component: SolubilityinputComponent;
  let fixture: ComponentFixture<SolubilityinputComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SolubilityinputComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SolubilityinputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
