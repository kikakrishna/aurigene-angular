import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InteractiveFavouritesComponent } from './interactive-favourites.component';

describe('InteractiveFavouritesComponent', () => {
  let component: InteractiveFavouritesComponent;
  let fixture: ComponentFixture<InteractiveFavouritesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InteractiveFavouritesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InteractiveFavouritesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
