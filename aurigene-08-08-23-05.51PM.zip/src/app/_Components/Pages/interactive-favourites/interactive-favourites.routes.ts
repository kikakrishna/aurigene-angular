import { RouterModule } from "@angular/router";
import { InteractiveFavouritesComponent } from "./interactive-favourites.component";

export const InteractiveFavouritesRoutes: RouterModule[] = [
    {
        path: '',
        component: InteractiveFavouritesComponent
    }
]