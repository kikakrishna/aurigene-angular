import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { ToastService } from 'ng-uikit-pro-standard';
import { FormBuilder, FormControl, FormGroup, Validators, FormGroupDirective } from '@angular/forms';
import { first } from 'rxjs/operators';
import { MatDialog } from '@angular/material/dialog';
import { SolubilityService } from 'src/app/_Services/solubility.service';
import * as moment from 'moment';
import { ActivatedRoute } from '@angular/router';
import { saveAs } from 'file-saver';

export interface PeriodicElement {
  reportname: string;
  createddate: string;
  Action: string;
}
const ELEMENT_DATA: PeriodicElement[] = [
  { reportname: "Name1", createddate: "November 25, 2022", Action: '' },
  { reportname: "Name2", createddate: "November 25, 2022", Action: '' },
  { reportname: "Name3", createddate: "November 25, 2022", Action: '' },
  { reportname: "Name4", createddate: "November 25, 2022", Action: '' },
  { reportname: "Name5", createddate: "November 25, 2022", Action: '' },

];
@Component({
  selector: 'app-interactive-favourites',
  templateUrl: './interactive-favourites.component.html',
  styleUrls: ['./interactive-favourites.component.css']
})
export class InteractiveFavouritesComponent implements OnInit {

  // displayedColumns: string[] = ['reportname', 'reporttype','createddate', 'Action'];
  displayedColumns: string[] = ['reportname', 'createddate', 'Action'];

  //dataSource = ELEMENT_DATA;
  addressmodel: any;
  public dataSource: any = new MatTableDataSource([]);
  @ViewChild('filteredreportpaginator', { read: MatPaginator }) filteredreportpaginator: MatPaginator;
  loading: boolean;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  myfavourite: any;
  filtertypeid: any;
  modelid: any;
  modelname: any;

  constructor(
    public toastrService: ToastService,
    private _formBuilder: FormBuilder,
    private _solubilityservice: SolubilityService,
    private router: Router,
    public dialog: MatDialog,
    private route: ActivatedRoute,
  ) {
    this.modelid = localStorage.getItem('modelid');
    this.modelname = localStorage.getItem('modelname');
  }



  ngOnInit(): void {
    this._solubilityservice.favouitelistinteractive()
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res?.data)
        if (!res.isError) {
          this.loading = false;
          let array = [];
          this.addressmodel = res?.data;
          for (let item of res?.data) {
            let d = new Date(item?.createddate);
            item.createddate = moment(d).format('MMMM D, YYYY');
            array.push(item);
          }
          setTimeout(() => {
            this.dataSource.paginator = this.filteredreportpaginator;
            this.filteredreportpaginator.firstPage()
          });
          this.dataSource = new MatTableDataSource(res?.data);
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });

  }



  executeclick(ele) {
    console.log("executeclick" + JSON.stringify(ele))
    this.router.navigate([`/viewinteractivefavourite`], { state: { inputparams: ele } });


    // if (ele.typeid == 7) {
    //   this.router.navigate([`/filteredbyproject&compound`], { state: { inputparams: ele.inputparams } });

    // }
    // if (ele.typeid == 8) {
    //   this.router.navigate([`/filterbyjobname/`], { state: { inputparams: ele.inputparams } });

    // }
    // if (ele.typeid == 9) {
    //   this.router.navigate([`/SearchbyStructure/`], { state: { inputparams: ele.inputparams } });

    // }
  }

}
