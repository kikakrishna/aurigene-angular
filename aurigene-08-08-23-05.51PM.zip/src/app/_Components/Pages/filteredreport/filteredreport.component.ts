import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { FormControl, FormGroup, NgForm, FormBuilder, Validators } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { ActivatedRoute } from "@angular/router";
import { SelectionModel } from '@angular/cdk/collections';
import { FormGroupDirective } from '@angular/forms';
import { ToastService } from 'ng-uikit-pro-standard';
import { SolubilityService } from 'src/app/_Services/solubility.service';
import { Router } from '@angular/router';
import { MatPaginator } from '@angular/material/paginator';
import { MatDialog } from '@angular/material/dialog';
import { MyfavouritePopupComponent } from '../myfavourite-popup/myfavourite-popup.component';
import { first } from 'rxjs/operators';
import * as moment from 'moment';
import { saveAs } from 'file-saver';
import { MatOption } from "@angular/material/core";
import { MatSelect } from "@angular/material/select";
export interface PeriodicElement {
  // no:string;
  smile: string;
  compoundcode: string;
  compoundname: string;
  batchnumber: string;
  project: string;
  logsvalue: string;
  jobname: string;
  classification: string;
  structure: string;
  version: string;

}

const ELEMENT_DATA: PeriodicElement[] = [
  { smile: 'cc-cc1-cc)', compoundcode: 'TG-AAA', compoundname: 'Benzimid', batchnumber: 'TEST', project: 'P-001', logsvalue: '-5.0', jobname: ' job name A', classification: 'high', structure: '-', version: 'Algorithm1' },
  { smile: 'cc-cc1-cc)', compoundcode: 'TG-BBB', compoundname: 'Benzimid', batchnumber: 'TEST', project: 'P-002', logsvalue: '-4.8', jobname: ' job name b', classification: 'low', structure: '-', version: 'Algorithm2' },
  { smile: 'cc-cc1-cc)', compoundcode: 'TG-CCC', compoundname: 'Benzimid', batchnumber: 'TEST', project: 'P-003', logsvalue: '-3.8', jobname: ' job name c', classification: 'medium', structure: '-', version: 'Algorithm2' },
  { smile: 'cc-cc1-cc)', compoundcode: 'TG-BBB', compoundname: 'Benzimid', batchnumber: 'TEST', project: 'P-002', logsvalue: '-4.8', jobname: ' job name b', classification: 'low', structure: '-', version: 'Algorithm2' },

];

@Component({
  selector: 'app-filteredreport',
  templateUrl: './filteredreport.component.html',
  styleUrls: ['./filteredreport.component.css']
})
export class FilteredreportComponent implements OnInit {
  displayedColumns: string[] = ['desired_number', 'structure',  'compoundcode','batchnumber', 'project',   'version','logsvalue','classification'   ];
  // dataSource = ELEMENT_DATA;
  // 'jobname',
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild('filteredreportpaginator', { read: MatPaginator }) filteredreportpaginator: MatPaginator;
  public dataSource: any = new MatTableDataSource([]);
  selected = 'option1';
  myForm: FormGroup;
  myfavForm: FormGroup;
  maxDate = new Date();

  myHolidayDates;
  selectedDate: any;
  mystartDate: any;
  myEndDate: any;
  downloadname: any;
  timeFrame: any;

  current_date: any;
  loading: boolean;
  stlistdate: any;
  projectcode: any;
  projectcompound: any;

  selectedCompound: any
  dysdate: any;
  dyedate: any;
  projectid: any;
  pageSize: any;
  myfavourite: any;
  ssdate: any;
  eedate: any;
  filtertypeid: any;
  // selection = new SelectionModel<any>(true, []);
  getsmilelist: any;
  Selectedcompoundid: any;
  downloadbtn: boolean;
  savebtn: boolean;

  typeid: any;
  inputparam: any;
  sendobject: any;
  selectedstartdate: any;
  selectedenddate: any;
  arrayx: any = [];
  projectselector: any = [];
  modelid: string;
  modelname: string;


  constructor(private _formBuilder: FormBuilder,
    public toastrService: ToastService,
    private _solubilityservice: SolubilityService,
    private router: Router,
    public dialog: MatDialog,
    public _activatedRoute: ActivatedRoute,
  ) { 
     this.modelid = localStorage.getItem('modelid');
    this.modelname = localStorage.getItem('modelname');
  }

  ngOnInit(): void {
    // this.downloadbtn = false
    // this.savebtn = false
    this.projectselector = []
    this.arrayx = []
    // Form validation


      
    this.inputparam = history.state.inputparams;
    this._activatedRoute.paramMap.subscribe(params => {
      if (params?.get('typeid')) {
        this.typeid = params?.get('typeid');
      }
    })


    console.log("inputparams" + JSON.stringify(this.inputparam))
    console.log("typeid" + this.typeid)




    this.myForm = this._formBuilder.group({
      // jobname: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9 ]*$')]],
      project: ['', []],
      compound: ['', []],
      startdate: ['',],
      enddate: ['',],

    });


    // get Filtered project dropdown  
    this._solubilityservice.getFilteredproject(this.modelid)
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res?.responseMessage)
        this.projectcode = res?.data;
      },
        err => {
        });

    // get Search dropdown
    this._solubilityservice.getSearch()
      .pipe(first())
      .subscribe((res: any) => {
        this.myfavourite = res?.data;
        let filtertype = "Search by Project"
        const filteredtypearray = this.myfavourite.filter((obj) => {
          return obj.reporttype === filtertype;
        });


        setTimeout(() => {
          this.filtertypeid = filteredtypearray[0].typeid;
          console.log("this.filtertypeid-------->" + this.filtertypeid)

        }, 1000);

      },
        err => {
        });

        console.log("this.filtertypeid-------->"+this.filtertypeid)
    this.dateenabled();
    this.datevalidation();

    this.downloadbtn = false;
    this.savebtn = false;


    console.log("oninitrun")

    let sDate = "";
    let eDate = "";
    console.log('users---> ', this.myForm.value)

    if (this.myForm.value.startdate != '' && this.myForm.value.enddate != '') {
      sDate = moment(this.myForm.value.startdate).format('YYYY-MM-DD');
      eDate = moment(this.myForm.value.enddate).format('YYYY-MM-DD');
      this.dysdate = moment(this.myForm.value.startdate).format('YYYY-MM-DD');
      this.dyedate = moment(this.myForm.value.enddate).format('YYYY-MM-DD');
    }
    if (this.myForm.value.startdate == '' || this.myForm.value.enddate == '') {
      var currentDate = moment(new Date());
      var futureMonth = moment(currentDate).add(1, 'M');
      var futureMonthEnd = moment(futureMonth).endOf('month');
      const datde = new Date();
      let dydate = new Date(datde.getFullYear(), datde.getMonth() - 1, datde.getDate())
      sDate = moment(dydate).format('YYYY-MM-DD');
      if (currentDate.date() != futureMonth.date() && futureMonth.isSame(futureMonthEnd.format('YYYY-MM-DD'))) {
        futureMonth = futureMonth.add(1, 'd');
      }
      eDate = moment(currentDate).format('YYYY-MM-DD');
      this.dysdate = sDate;
      this.dyedate = eDate;
    }
    this.loading = true;
    if ((this.projectid == undefined || this.projectid == '' || this.projectid == null) && (this.Selectedcompoundid == undefined || this.Selectedcompoundid == '' || this.Selectedcompoundid == null)) {
      this._solubilityservice.getfilterReportWithoutProjectIdCompoundid(this.modelid,this.dysdate, this.dyedate)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.error) {
            this.getsmilelist = res?.data;
            // this.downloadname = res?.data[0].smile;
            console.log('hdjfvdhbf' + this.downloadname)
            this.dataSource = new MatTableDataSource(this.getsmilelist)
            // console.log("ghstghsrthr" + this.getsmilelist)
            if (this.dataSource.data.length == 0) {
              this.downloadbtn = false;
              this.savebtn = false;

            }
            this.loading = false;
            let array = [];
            for (let item of res?.data) {
              let d = new Date(item?.createdtime);
              // console.log("srfdrgrdggdsg" + JSON.stringify(item));
              item.formattedappointmentDate = moment(d).format('MMMM D, YYYY');
              if (item.logsvalue < -4.5) {
                item.low = true;
              } else if (item.logsvalue >= -3.7 && item.logsvalue <= -4.5) {
                item.medium = true;
              } else {
                item.high = true;
              }
              array.push(item);
            }
            setTimeout(() => {
              this.dataSource.paginator = this.filteredreportpaginator;
              this.filteredreportpaginator.firstPage()
            });
            // this.myForm.reset();
            // formDirective.resetForm();
          }
        },
          err => {
          });




    }


  }

  // get Filtered compound dropdown  
  projectcompoundStatus: boolean = false;
  selectedproject(event) {
    this.Selectedcompoundid = []
    this.myForm.controls.compound.reset();
    var CompoundList = event.value;
    this.projectid = CompoundList
    console.log('product', CompoundList);
    this._solubilityservice.getFilteredcompound(CompoundList, this.modelid)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.error) {
          this.projectcompound = res?.data;
          if(this.projectcompound.length > 0){
            this.projectcompoundStatus = true;
          }
          console.log(this.projectcompound);
        } else {

        }
      },
        err => {
        });
  }

  getsmilefilter(formData: any, formDirective: FormGroupDirective) {
    this.inputparam = ""


    if (this.myForm.value.startdate && (this.myForm.value.enddate == null || this.myForm.value.enddate == "" || this.myForm.value.enddate == undefined)) {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please select end date', options);
      this.loading = false;
      return;
    }


    this.downloadbtn = true;
    this.savebtn = true;

    if (this.projectid == "") {
      this.Selectedcompoundid = []
      this.projectcompound = []
      this.myForm.controls.compound.reset();
    }
    let sDate = "";
    let eDate = "";
    console.log('users---> ', this.myForm.value)
    if (this.myForm.value.startdate != '' && this.myForm.value.enddate != '') {

      sDate = moment(this.myForm.value.startdate).format('YYYY-MM-DD');
      eDate = moment(this.myForm.value.enddate).format('YYYY-MM-DD');
      this.dysdate = moment(this.myForm.value.startdate).format('YYYY-MM-DD');
      this.dyedate = moment(this.myForm.value.enddate).format('YYYY-MM-DD');
    }
    if (this.myForm.value.startdate == '' || this.myForm.value.startdate == null && this.myForm.value.enddate == '' || this.myForm.value.enddate == null) {

      var currentDate = moment(new Date());
      var futureMonth = moment(currentDate).add(1, 'M');
      var futureMonthEnd = moment(futureMonth).endOf('month');
      const datde = new Date();
      let dydate = new Date(datde.getFullYear(), datde.getMonth() - 1, datde.getDate())
      sDate = moment(dydate).format('YYYY-MM-DD');
      if (currentDate.date() != futureMonth.date() && futureMonth.isSame(futureMonthEnd.format('YYYY-MM-DD'))) {
        futureMonth = futureMonth.add(1, 'd');
      }
      eDate = moment(currentDate).format('YYYY-MM-DD');
      this.dysdate = sDate;
      this.dyedate = eDate;
    }

    this.loading = true;

    if ((this.projectid == undefined || this.projectid == '' || this.projectid == null) && (this.Selectedcompoundid == undefined || this.Selectedcompoundid == '' || this.Selectedcompoundid == null)) {


      if (this.myForm.value.startdate == " " || this.myForm.value.startdate == null && this.myForm.value.enddate == '' || this.myForm.value.enddate == null) {
        this.downloadbtn = false;
        this.savebtn = false;

      }
      const formobject = {
        startdate: this.dysdate,
        enddate: this.dyedate,
        typeid: this.filtertypeid
      }
      this.sendobject = formobject
      this._solubilityservice.getfilterReportWithoutProjectIdCompoundid(this.modelid,this.dysdate, this.dyedate)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.error) {
            this.getsmilelist = res?.data;
            this.downloadname = "Project & Compound report";
            this.dataSource = new MatTableDataSource(this.getsmilelist)
            if (this.dataSource.data.length == 0) {
              this.downloadbtn = false;
              this.savebtn = false;

            }
            console.log("ghstghsrthr" + this.getsmilelist)
            this.loading = false;
            let array = [];
            for (let item of res?.data) {
              let d = new Date(item?.createdtime);
              // console.log("srfdrgrdggdsg" + JSON.stringify(item));
              item.formattedappointmentDate = moment(d).format('MMMM D, YYYY');
              if (item.logsvalue < -4.5) {
                item.low = true;
              } else if (item.logsvalue >= -3.7 && item.logsvalue <= -4.5) {
                item.medium = true;
              } else {
                item.high = true;
              }
              array.push(item);
            }
            setTimeout(() => {
              this.dataSource.paginator = this.filteredreportpaginator;
              this.filteredreportpaginator.firstPage()
            });
            // this.myForm.reset();
            // formDirective.resetForm();
          }
        },
          err => {
          });
      this.loading = true;
    } else if (this.projectid && (this.Selectedcompoundid == undefined || this.Selectedcompoundid == '' || this.Selectedcompoundid == null)) {
      const formobject = {
        projectid: this.projectid,
        startdate: this.dysdate,
        enddate: this.dyedate,
        typeid: this.filtertypeid
      }
      this.sendobject = formobject
      this._solubilityservice.getfilterReportWithProjectId(this.projectid, this.dysdate, this.dyedate,this.modelid)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.error) {
            this.getsmilelist = res?.data;

            this.dataSource = new MatTableDataSource(this.getsmilelist)
            if (this.dataSource.data.length == 0) {
              this.downloadbtn = false;
              this.savebtn = false;

            }
            // console.log("ghstghsrthr" + this.getsmilelist)
            this.loading = false;
            let array = [];
            for (let item of res?.data) {
              let d = new Date(item?.createdtime);
              // console.log("srfdrgrdggdsg" + JSON.stringify(item));
              item.formattedappointmentDate = moment(d).format('MMMM D, YYYY');
              if (item.logsvalue < -4.5) {
                item.low = true;
              } else if (item.logsvalue >= -3.7 && item.logsvalue <= -4.5) {
                item.medium = true;
              } else {
                item.high = true;
              }
              array.push(item);
            }
            setTimeout(() => {
              this.dataSource.paginator = this.filteredreportpaginator;
              this.filteredreportpaginator.firstPage()

            });
            this.downloadname = "project & Compound report";

          }

        },
          err => {
          });

    } else {
      this.loading = true;
      console.log(this.Selectedcompoundid)
      const formobject = {
        projectid: this.projectid,
        compoundcode: this.Selectedcompoundid,
        startdate: this.dysdate,
        enddate: this.dyedate,
        typeid: this.filtertypeid
      }
      this.sendobject = formobject
      this._solubilityservice.getfilterReport(this.projectid, this.Selectedcompoundid, this.dysdate, this.dyedate,this.modelid)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.error) {
            this.getsmilelist = res?.data;
            this.downloadname = "Project & Compound report";
            this.dataSource = new MatTableDataSource(this.getsmilelist)
            console.log("ghstghsrthr" + this.getsmilelist)
            this.loading = false;
            let array = [];
            if (this.dataSource.data.length == 0) {
              this.downloadbtn = false;
              this.savebtn = false;

            }
            for (let item of res?.data) {
              let d = new Date(item?.createdtime);
              // console.log("srfdrgrdggdsg" + JSON.stringify(item));
              item.formattedappointmentDate = moment(d).format('MMMM D, YYYY');
              if (item.logsvalue < -4.5) {
                item.low = true;
              } else if (item.logsvalue >= -3.7 && item.logsvalue <= -4.5) {
                item.medium = true;
              } else {
                item.high = true;
              }
              array.push(item);
            }
            setTimeout(() => {
              this.dataSource.paginator = this.filteredreportpaginator;
              this.filteredreportpaginator.firstPage()

            });
            // this.myForm.reset();
            // formDirective.resetForm();
          }
        },
          err => {
          });
    }

  }

  dateenabled() {
    if (this.myForm.value.startdate) {
      this.myForm.controls.enddate.reset();
      this.myForm.controls.enddate.enable();
      const sdate = this.myForm.value.startdate;
      this.myEndDate = sdate.toISOString();
      // this.downloadbtn = false;
      // this.savebtn = false;

    }

  }

  datevalidation() {
    if (this.myForm.value.startdate == "" || this.myForm.value.startdate == null || this.myForm.value.startdate == undefined) {
      this.myForm.controls.enddate.disable();
      return;
    }

  }

  selectedComp(event) {
    console.log(event.value)
    let selected = event.value.filter(item => item!= 0)
    this.Selectedcompoundid = selected
  }

  resetclk() {
    this.loading =true;
    this.downloadbtn = false;
    this.savebtn = false;
    this.getsmilelist = []
    this.dataSource = new MatTableDataSource(this.getsmilelist)
    this.myForm.controls.startdate.reset();
    this.myForm.reset()
    this.projectid = []
    this.Selectedcompoundid = []
    this.projectcompound = []
    this.dateenabled();
    this.datevalidation();
    this.projectcompoundStatus = false;

    if ((this.projectid == undefined || this.projectid == '' || this.projectid == null) && (this.Selectedcompoundid == undefined || this.Selectedcompoundid == '' || this.Selectedcompoundid == null)) {

      let sDate = "";
      let eDate = "";
      var currentDate = moment(new Date());
      var futureMonth = moment(currentDate).add(1, 'M');
      var futureMonthEnd = moment(futureMonth).endOf('month');
      const datde = new Date();
      let dydate = new Date(datde.getFullYear(), datde.getMonth() - 1, datde.getDate())
      sDate = moment(dydate).format('YYYY-MM-DD');
      if (currentDate.date() != futureMonth.date() && futureMonth.isSame(futureMonthEnd.format('YYYY-MM-DD'))) {
        futureMonth = futureMonth.add(1, 'd');
      }
      eDate = moment(currentDate).format('YYYY-MM-DD');
      this.dysdate = sDate;
      this.dyedate = eDate;
      this._solubilityservice.getfilterReportWithoutProjectIdCompoundid(this.modelid,this.dysdate, this.dyedate)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.error) {
            this.getsmilelist = res?.data;
            this.dataSource = new MatTableDataSource(this.getsmilelist)
            console.log("ghstghsrthr" + this.getsmilelist)
            this.loading = false;
            let array = [];
            for (let item of res?.data) { 
              let d = new Date(item?.createdtime);
              // console.log("srfdrgrdggdsg" + JSON.stringify(item));
              item.formattedappointmentDate = moment(d).format('MMMM D, YYYY');
              if (item.logsvalue < -4.5) {
                item.low = true;
              } else if (item.logsvalue >= -3.7 && item.logsvalue <= -4.5) {
                item.medium = true;
              } else {
                item.high = true;
              }
              array.push(item);

            }

            setTimeout(() => {
              this.dataSource.paginator = this.filteredreportpaginator;
              this.filteredreportpaginator.firstPage()
              this.dataSource.paginator.pageSize = 0;
            });
            // this.myForm.reset();
            // formDirective.resetForm();
          }
        },
          err => {
          });

    }

  }

  downloadReport() {


    if (this.sendobject.startdate && this.sendobject.enddate && this.sendobject.projectid == undefined) {


      this._solubilityservice.downloadWithoutProjectIdCompoundid(this.sendobject,this.modelid)
        .pipe(first()).subscribe((res: any) => {
          if (!res.error) {
            this.loading = false;
            console.log(res)
            const data: Blob = new Blob([res], {
              type: 'text/csv'
            });
            saveAs(data, this.downloadname + ".csv");
          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }

        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });
    }


    if (this.sendobject.projectid && this.sendobject.compoundcode == undefined) {

      this._solubilityservice.downloadWithProjectId(this.sendobject,this.modelid)
        .pipe(first()).subscribe((res: any) => {
          if (!res.error) {
            this.loading = false;
            console.log(res)
            const data: Blob = new Blob([res], {
              type: 'text/csv'
            });
            saveAs(data, this.downloadname + ".csv");
          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }

        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });
    }


    this.loading = true;

    if (this.sendobject.compoundcode) {
      this._solubilityservice.downloadProjandCompoundReport(this.sendobject,this.modelid)
        .pipe(first()).subscribe((res: any) => {
          if (!res.error) {
            this.loading = false;
            console.log(res)
            const data: Blob = new Blob([res], {
              type: 'text/csv'
            });
            saveAs(data, this.downloadname + ".csv");
          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }

        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });
    }
  }

  openDialog() {
    console.log(this.myForm.value)
    console.log(this.myForm.value.startdate)
    const dialogRef = this.dialog.open(MyfavouritePopupComponent, {
      width: '28%',
      data: this.sendobject
    });
  }

  img:any;
  imgclk(element){
    console.log(element)
    this.img = element
  }

  // allSelected = false;
  toggleAllCompound(matSelect: MatSelect) {
    const isSelected: boolean = matSelect.options
    // The "Select All" item has the value 0
    .filter((item: MatOption) => item.value === 0)
    // Get the selected property (this tells us whether Select All is selected or not)
    .map((item: MatOption) => item.selected)[0];
  // Get the first element (there should only be 1 option with the value 0 in the select)

  if (isSelected) {
    matSelect.options.forEach((item: MatOption) => item.select());
  } else {
    matSelect.options.forEach((item: MatOption) => item.deselect());
  }
  }

  checkBoxClick() {
    // console.log(event.compoundcode)
    // console.log(this.select.options)
    // let newStatus = true;
    // this.select.options.forEach((item: MatOption) => {
    //   console.log(item.selected)
    //   if (!item.selected) {
    //     newStatus = false;
    //   }
    // });

    // this.allSelected = newStatus;  
    console.log(this.select.options)
    this.select.options.find(option => option.value === 0)?.deselect();
    console.log(this.projectcompound.length)
    console.log(this.select.options)
    if(this.select.options) {
    // let smile = this.select.options._results;
    // if(smile.length > this.projectcompound.length) {
    //   let ss = smile;
    //   console.log(ss.length)
    //   let remove = ss.shift()
    //   let selectOption;
    //   console.log(this.projectcompound.length)
    //   console.log(ss.length)
    //   if(this.projectcompound.length == ss.length) {
    //     ss.forEach(item => {
    //       console.log(item._selected)
    //       if(item._selected == false) {
    //         selectOption = false;
    //         return
    //       }
    //     })

    //     if(selectOption == false) {
    //       this.select.options.find(option => option.value === 0)?.deselect();
    //     }
    //     else {
    //       this.select.options.find(option => option.value === 0)?.select();
    //     }
    //   }
    // }
  }
    
    // console.log(this.projectcompound.length)
    // console.log(ss.length)
    
  }

  @ViewChild('select') select: MatSelect;
  // allSelected = true;
  // foods: any[] = [
  //   { value: 'steak-0', viewValue: 'Steak' },
  //   { value: 'pizza-1', viewValue: 'Pizza' },
  //   { value: 'tacos-2', viewValue: 'Tacos' },
  // ];
  // toggleAllSelection() {
  //   console.log(this.allSelected);
  //   if (this.allSelected) {
  //     this.select.options.forEach((item: MatOption) => item.select());
  //   } else {
  //     this.select.options.forEach((item: MatOption) => item.deselect());
  //   }
  // }
  // optionClick() {
  //   let newStatus = true;
  //   console.log(this.select.options);
  //   this.select.options.forEach((item: MatOption) => {
  //     if (!item.selected) {
  //       newStatus = false;
  //     }
  //   });
  //   this.allSelected = newStatus;
  // }
  
}
