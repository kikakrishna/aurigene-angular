import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { WebapiService,Todo } from 'src/app/_Services/webapi.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
    todo?: Todo;
    todos: Todo[] = [];

    displayedColumns = ['status', 'description', 'edit', 'remove'];

    constructor(
      private service: WebapiService,
      private http: HttpClient
      ) { }

    ngOnInit(): void {
        this.getTodos();
    }

    getTodos(): void {
        this.service.getTodos()
            .subscribe((todos: Todo[]) => {
                console.log('api response', todos);
                this.todos = todos;
            });
       }

  /*constructor(
    private http: HttpClient
  ) { }

  ngOnInit() {
    this.getProfile();
  }
*/
 /* getProfile() {
    this.http.get(GRAPH_ENDPOINT)
      .subscribe(profile => {
        this.profile = profile;
      });
  }*/
}