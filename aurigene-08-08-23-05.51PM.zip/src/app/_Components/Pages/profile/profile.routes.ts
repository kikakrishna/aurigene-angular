import { RouterModule } from "@angular/router";
import { ProfileComponent } from "./profile.component";
export const ProfileRoutes: RouterModule [] = [
    {
        path: '',
        component: ProfileComponent
    }
]