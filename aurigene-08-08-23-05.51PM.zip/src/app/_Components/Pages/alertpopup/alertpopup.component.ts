import { FormControl, FormGroup, NgForm, FormBuilder, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Component, Inject, OnInit, ViewChild, NgZone, } from '@angular/core';
import { ToastService } from 'ng-uikit-pro-standard';
import { SolubilityService } from 'src/app/_Services/solubility.service';
import { Router } from '@angular/router';
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-alertpopup',
  templateUrl: './alertpopup.component.html',
  styleUrls: ['./alertpopup.component.css']
})
export class AlertpopupComponent implements OnInit {

  myfavpopup: FormGroup;
  modelid: any;
  modelname: any;
  getRejectedsmiles: any;
  getDiffprojectsmiles: any;
  constructor(private _formBuilder: FormBuilder,
    public toastrService: ToastService,
    private _solubilityservice: SolubilityService,
    private router: Router,
    public matdialog: MatDialog,
    private _ngZone: NgZone,
    public dialogRef: MatDialogRef<AlertpopupComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.modelid = localStorage.getItem('modelid');
    this.modelname = localStorage.getItem('modelname');
  }

  ngOnInit(): void {

    // console.log()
    console.log("data---------", this.data)
    // Form validation
    var x = this.data.Rejectedsmiles
    var y = this.data.Diffprojectsmiles

    console.log(x);
    console.log(y);

    this.getRejectedsmiles = x.toString()
    this.getDiffprojectsmiles = y.toString()
    console.log(this.getRejectedsmiles);
    console.log(this.getDiffprojectsmiles);
    this.myfavpopup = this._formBuilder.group({
      reportname: ['', [Validators.required]],

    });
  }
  closemenu() {
    this.dialogRef.close({data: "yes"});
  }

  savebtn() {
    // console.log("this.data.projectid=======" + this.data.projectid)
    this.dialogRef.close({data: "yes"});
  }
}
