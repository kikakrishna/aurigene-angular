import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FavouriteResultComponent } from './favourite-result.component';

describe('FavouriteResultComponent', () => {
  let component: FavouriteResultComponent;
  let fixture: ComponentFixture<FavouriteResultComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FavouriteResultComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FavouriteResultComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
