import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';

export interface PeriodicElement {
  no: string;
  structure: string;
  compoundcode: string;
  compoundname: string;
  batchnumber: string;
  project: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  { no: '1', structure: 'cc-cc1-cc)-no2=c12', compoundcode: 'TG-AAA-7001', compoundname: 'Benzimidazolenenzamide', batchnumber: 'TEST-BAT-O98', project: 'P-001' },
  { no: '2', structure: 'cc-cc1-cc)-no2=c12', compoundcode: 'TG-AAA-7001', compoundname: 'Benzimidazolenenzamide', batchnumber: 'TEST-BAT-O98', project: 'P-001' },
  { no: '3', structure: 'cc-cc1-cc)-no2=c12', compoundcode: 'TG-AAA-7003', compoundname: 'Benzimidazolenenzamide', batchnumber: 'TEST-BAT-O98', project: 'P-001' }
];
@Component({
  selector: 'app-solubility-runtype',
  templateUrl: './solubility-runtype.component.html',
  styleUrls: ['./solubility-runtype.component.css']
})


export class SolubilityRuntypeComponent implements OnInit {
  displayedColumns: string[] = ['no', 'structure', 'compoundcode', 'compoundname', 'batchnumber', 'project'];
  dataSource = ELEMENT_DATA;
  pastescreen: boolean = true;
  uploadscreen: boolean = false;
  title = 'angular-material-file-upload-app';
  @ViewChild('UploadFileInput') uploadFileInput: ElementRef;
  myfilename = 'Select File';
  page1: boolean = true;
  page2: boolean = false;
  page3: boolean = false;

  constructor() { }

  ngOnInit(): void {
  }
  fileChangeEvent(fileInput: any) {

    if (fileInput.target.files && fileInput.target.files[0]) {
      this.myfilename = '';
      Array.from(fileInput.target.files).forEach((file: File) => {
        console.log(file);
        this.myfilename += file.name + ',';
      });
      const reader = new FileReader();
      reader.onload = (e: any) => {
        const image = new Image();
        image.src = e.target.result;
        image.onload = rs => {
          // Return Base64 Data URL
          const imgBase64Path = e.target.result;
        };
      };
      reader.readAsDataURL(fileInput.target.files[0]);

      // Reset File Input to Selct Same file again
      this.uploadFileInput.nativeElement.value = "";
    } else {
      this.myfilename = 'Select File';
    }
  }
  Copy
  pasteclick() {
    this.pastescreen = true;
    this.uploadscreen = false;
  }
  uploadclick() {
    this.pastescreen = false;
    this.uploadscreen = true;
  }
  pageone() {
    this.page1 = true;
    this.page2 = false;
    this.page3 = false;
  }
  pagetwo() {
    this.page1 = false;
    this.page2 = true;
    this.page3 = false;
  }
  pagethree(){
  this.page1 = false;
  this.page2 = false;
  this.page3 = true;
  }
}
