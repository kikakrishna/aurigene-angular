import { RouterModule } from "@angular/router";
import { SolubilityRuntypeComponent } from "./solubility-runtype.component";
export const SolubilityRuntypeRoutes: RouterModule [] = [
    {
        path: '',
        component: SolubilityRuntypeComponent
    }
]