
import { SolubilityRuntypeComponent } from './solubility-runtype.component';
import { SolubilityRuntypeRoutes } from './solubility-runtype.routes';
import {MatSelectModule} from '@angular/material/select';

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatDividerModule } from '@angular/material/divider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatDialogModule } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatStepperModule } from '@angular/material/stepper';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatSliderModule }  from '@angular/material/slider';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatRadioModule } from '@angular/material/radio';
import { MatTableModule } from '@angular/material/table';
import { MatToolbarModule } from '@angular/material/toolbar';
import { SolubilityLocusapplicationComponent } from '../solubility-locusapplication/solubility-locusapplication.component';
import { SolubilityinputComponent } from '../solubilityinput/solubilityinput.component';
import { SolubilityDrawingComponent } from '../solubility-drawing/solubility-drawing.component';
import { SolubilityDrawingPopupComponent } from '../solubility-drawing-popup/solubility-drawing-popup.component'; 
import { AlertpopupComponent } from '../alertpopup/alertpopup.component';
//  import { SolubilityLocusapplicationModule } from '../solubility-Locusapplication/solubility-Locusapplication.module';

@NgModule({
  declarations: [SolubilityDrawingPopupComponent,SolubilityRuntypeComponent,SolubilityLocusapplicationComponent,SolubilityinputComponent,SolubilityDrawingComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(SolubilityRuntypeRoutes),
    MatCardModule,
    MatButtonModule,
    MatSelectModule,
    MatFormFieldModule,
    MatRadioModule,
    FormsModule, 
    ReactiveFormsModule, 
    MatDividerModule,
    FormsModule,
    ReactiveFormsModule,
    MatPaginatorModule,
    MatInputModule,
    MatSlideToggleModule,
    MatDialogModule,
    MatIconModule,
    MatStepperModule,
    MatExpansionModule,
    MatSidenavModule,
    MatSliderModule,
    MatCheckboxModule,
    MatToolbarModule,
    MatTableModule
  ],
  entryComponents: [
    AlertpopupComponent,

  ],
})
export class SolubilityRuntypeModule { }
