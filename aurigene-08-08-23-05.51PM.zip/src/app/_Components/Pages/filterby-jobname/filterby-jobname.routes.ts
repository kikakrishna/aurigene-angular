import { RouterModule } from "@angular/router";
import {FilterbyJobnameComponent } from './filterby-jobname.component';
export const FilterbyJobnameRoutes: RouterModule [] = [
    {
        path: '',
        component: FilterbyJobnameComponent
    }
]