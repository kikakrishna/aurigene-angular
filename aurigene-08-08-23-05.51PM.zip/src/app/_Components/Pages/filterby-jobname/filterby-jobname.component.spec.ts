import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FilterbyJobnameComponent } from './filterby-jobname.component';

describe('FilterbyJobnameComponent', () => {
  let component: FilterbyJobnameComponent;
  let fixture: ComponentFixture<FilterbyJobnameComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FilterbyJobnameComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FilterbyJobnameComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
