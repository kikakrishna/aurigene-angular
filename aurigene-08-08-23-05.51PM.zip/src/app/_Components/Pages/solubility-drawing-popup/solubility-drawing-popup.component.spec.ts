import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SolubilityDrawingPopupComponent } from './solubility-drawing-popup.component';

describe('SolubilityDrawingPopupComponent', () => {
  let component: SolubilityDrawingPopupComponent;
  let fixture: ComponentFixture<SolubilityDrawingPopupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SolubilityDrawingPopupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SolubilityDrawingPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
