import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
@Component({
  selector: 'app-solubility-drawing-popup',
  templateUrl: './solubility-drawing-popup.component.html',
  styleUrls: ['./solubility-drawing-popup.component.css']
})
export class SolubilityDrawingPopupComponent implements OnInit {

  constructor(  private dialogRef: MatDialogRef<SolubilityDrawingPopupComponent>,
    @Inject(MAT_DIALOG_DATA) public dataval: any) { 
    }

  ngOnInit(): void {
  }

}
