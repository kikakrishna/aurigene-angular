import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmdeletePopupComponent } from './confirmdelete-popup.component';

describe('ConfirmdeletePopupComponent', () => {
  let component: ConfirmdeletePopupComponent;
  let fixture: ComponentFixture<ConfirmdeletePopupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConfirmdeletePopupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmdeletePopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
