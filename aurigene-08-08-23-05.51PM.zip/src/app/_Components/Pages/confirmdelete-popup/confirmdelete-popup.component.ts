import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-confirmdelete-popup',
  templateUrl: './confirmdelete-popup.component.html',
  styleUrls: ['./confirmdelete-popup.component.css']
})
export class ConfirmdeletePopupComponent implements OnInit {


  addfamilyGroup: FormGroup;
  constructor(public _formBuilder: FormBuilder,
    public dialogRef: MatDialogRef<ConfirmdeletePopupComponent>,) { }

  ngOnInit(): void {
    // this.addfamilyGroup = this._formBuilder.group({
    //   FullName: [''],
    //   Relationship: [''],
    //   PatientID: [''],
    //   Age: [''],
    //   MobileNo: [''],
    //   Email: [''],
    // });

  }
  submit() {
    // console.log(this.addfamilyGroup.value)
    this.dialogRef.close({ data: "yes" });

  }

  onNoClick(): void {
    // this.dialogRef.close();
    this.dialogRef.close({ data: "no" });

  }


}
