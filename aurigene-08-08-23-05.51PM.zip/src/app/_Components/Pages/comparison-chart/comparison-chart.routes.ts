import { RouterModule } from "@angular/router";
import { ComparisonChartComponent } from "./comparison-chart.component";
export const ComparisonChartRoutes: RouterModule [] = [
    {
        path: '',
        component: ComparisonChartComponent
    }
]