import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { Password } from '../_Models/password';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  public CategorySource = new BehaviorSubject("");
  public $selectedCategory = this.CategorySource.asObservable();


  constructor(private http: HttpClient, private router: Router) { 
  }

  adminInstitutelist() {
    return this.http.get(`${environment.apiUrl}/admincontroller/getInstituteAdminList`).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  Admingetprogramforinstitute(pguid) {    
    // http://localhost:8002/api/admincontroller/getprogramforinstitute  -get
    // return this.http.get(`${environment.apiUrl}/admincontroller/getprogramforinstitute`).
    return this.http.get(`${environment.apiUrl}/admincontroller/getprogramforinstitute?instituteguid=`+pguid).    
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  AddadminInstitute(postdata) {
    return this.http.post(`${environment.apiUrl}/admincontroller/Instituteadmin`, postdata).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  UpdateadminInstitute(postdata) {
    return this.http.put(`${environment.apiUrl}/admincontroller/updateinstitute`, postdata).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  updateadminInstituteStatus(postdata) {
    return this.http.put(`${environment.apiUrl}/admincontroller/updateinstitutestatus`, postdata).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  adminStudentlistSearch(search,pageIndex, pageSize) {    
    return this.http.get(`${environment.apiUrl}/student/searchstudent?search=${search}&pagelimit=${pageSize}&pageoffset=${pageIndex}&ispagerequired=true`).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  adminStudentlistSearchNext(search,pageIndex, pageSize) {
    return this.http.get(`${environment.apiUrl}/student/searchstudent?search=${search}&pagelimit=${pageSize}&pageoffset=${pageIndex}&ispagerequired=false`).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  adminStudentlist(pageIndex, pageSize) {
    return this.http.get(`${environment.apiUrl}/admincontroller/getStudentListforadmin?pagelimit=${pageSize}&pageoffset=${pageIndex}&IsPageCountRequired=true`).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  adminStudentlist2(pageIndex, pageSize) {
    return this.http.get(`${environment.apiUrl}/admincontroller/getStudentListforadmin?pagelimit=${pageSize}&pageoffset=${pageIndex}&IsPageCountRequired=false`).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  adminStudentprofileDetails(userguid) {
    return this.http.get(`${environment.apiUrl}/admincontroller/getstudentprofileforadmin?studentguid=${userguid}&pagelimit=5&pageoffset=0&IsPageCountRequired=true`).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  adminStudentprofileDetailsNextpage(userguid,pageIndex,pageSize) {
    return this.http.get(`${environment.apiUrl}/admincontroller/getstudentprofileforadmin?studentguid=${userguid}&pagelimit=${pageSize}&pageoffset=${pageIndex}&IsPageCountRequired=false`).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  adminStudentProfile(userguid) {
    return this.http.get(`${environment.apiUrl}/admincontroller/studentprofile?userguid=` + userguid).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  adminUpdateAttemptandExpiry(payload) {
    return this.http.post(`${environment.apiUrl}/program/UpdateAttemptandExpiry`, payload).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  adminexamReview(id) {
    return this.http.get(`${environment.apiUrl}/program/getcompletedprogram?Id=` + id).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  adminprogramReview(id) {
    return this.http.get(`${environment.apiUrl}/topic/testreview?id=` + id).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  adminresetpasswordwithUserGuid(payload) {
    return this.http.put(`${environment.apiUrl}/admincontroller/adminreset`, payload)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  admiUserupdatestatus(payload) {
    return this.http.put(`${environment.apiUrl}/student/updatestatus`, payload)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  AddadminStudent(data) {
    return this.http.post(`${environment.apiUrl}/admincontroller/registerstudent`, data).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  adminUserslist() {
    return this.http.get(`${environment.apiUrl}/admincontroller/getAdminList`).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  updateadminUsersStatus(postdata) {
    return this.http.put(`${environment.apiUrl}/admincontroller/updateadminstatus`, postdata).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  AddadminUsers(postdata) {
    return this.http.post(`${environment.apiUrl}/admincontroller/createadmin`, postdata).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  UpdateadminUsers(postdata) {
    return this.http.put(`${environment.apiUrl}/admincontroller/updateadmin`, postdata).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  categorydropdown() {
    return this.http.get(`${environment.apiUrl}/dropdown/Category`).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  bannerlist() {
    // return this.http.get(`${environment.apiUrl}/keyprogram/getbannerlist`).
    return this.http.get(`${environment.apiUrl}/admincontroller/banner`).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  addbannerlist(add) {
    return this.http.post(`${environment.apiUrl}/admincontroller/banner`,add).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  deletebannerlist(id) {
    return this.http.put(`${environment.apiUrl}/admincontroller/deletebanner?banner_id=`+id,{}).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  typesdropdown() {
    return this.http.get(`${environment.apiUrl}/dropdown/ProgramLevel`).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  Admincategorydropdown() {
    return this.http.get(`${environment.apiUrl}/dropdown/Category`)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  Adminaddcategorydropdown(add) {
    return this.http.post(`${environment.apiUrl}/admincontroller/category`,add)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  Adminupdatecategorydropdown(update) {
    return this.http.put(`${environment.apiUrl}/admincontroller/updatecategory`,update)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  landingProgramCategory() {    
    return this.http.get(`${environment.apiUrl}/keyprogram/getcategorykeyprogram`)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  Adminprogramstypesdropdown() {
    return this.http.get(`${environment.apiUrl}/dropdown/ProgramLevel`)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  Adminprogramdetails(pguid) {
    return this.http.get(`${environment.apiUrl}/admincontroller/getprogramdetails?programguid=` + pguid)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  addadminprogram(postdata) {
    const payload = {
      title: postdata.title,
      categorytype: Number(postdata.category),
      // programtype: Number(postdata.type)
    }
    return this.http.post(`${environment.apiUrl}/admincontroller/program`, payload).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  adminprogramslist() {
    return this.http.get(`${environment.apiUrl}/admincontroller/program`).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  adminprogramsSearch(search) {
    return this.http.get(`${environment.apiUrl}/admincontroller/searchprogram?search=` + search).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  UpdateAdminprogramDetails(payload) {
    return this.http.put(`${environment.apiUrl}/admincontroller/program`, payload).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  AdminprogramDetailsaddtopics(payload) {
    return this.http.post(`${environment.apiUrl}/admincontroller/createtopic`, payload).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  AdminprogramDetailsupdatetopics(payload) {
    return this.http.put(`${environment.apiUrl}/admincontroller/updatetopic`, payload).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  AdminprogramDetailscreateDescription(payload) {
    return this.http.put(`${environment.apiUrl}/admincontroller/createdescription`, payload).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  AdmincreateDescriptionTopic(payload) {
    return this.http.post(`${environment.apiUrl}/admincontroller/createdescription`, payload).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  AdminupdateTopicDescription(payload) {
    return this.http.put(`${environment.apiUrl}/admincontroller/updatedescription `, payload).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  AdmingetSingleTopicDescription(id) {    
    return this.http.get(`${environment.apiUrl}/admincontroller/singletopicdescription?Id=`+id).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  changeofferuser(toglestate, ele) {
    console.log(ele)
    let statvalue = {};
    if (toglestate === 'free') {
      statvalue = {
        "programguid": ele.Programid,
        "paymenttype": 10
      };
    }
    else {
      statvalue = {
        "programguid": ele.Programid,
        "paymenttype": 9
      };
    }

    return this.http
      .put(
        `${environment.apiUrl}/admincontroller/changepaymenttype`, statvalue)
      .pipe(
        map((data: any) => {
          if (data) {
            return data;
          }
        }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  Adminchangeclass(data) {
    return this.http
      .put(`${environment.apiUrl}/admincontroller/changepaymenttype`, data)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  Adminchangestatus(data) {
    return this.http
      .put(`${environment.apiUrl}/admincontroller/changestatus`, data)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  adminDashboard() {
    return this.http.get(`${environment.apiUrl}/admincontroller/dashboardadmin`).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  adminPaymentDatesearch(startdate, enddate, pageIndex, pageSize) {
    return this.http.get(`${environment.apiUrl}/payment/getpayment?pagelimit=${pageSize}&pageoffset=${pageIndex}&IsPageCountRequired=true&startdate=` + startdate + `&endDate=` + enddate)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  adminPayment(startdate, enddate, pageIndex, pageSize) {
    return this.http.get(`${environment.apiUrl}/payment/getpayment?pagelimit=${pageSize}&pageoffset=${pageIndex}&IsPageCountRequired=true&startdate=` + startdate + `&endDate=` + enddate)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  adminPaymentlist(programstatus,resultstatus,startdate, enddate, pageIndex, pageSize) {    
    return this.http.get(`${environment.apiUrl}/admincontroller/programreport?programstatus=${programstatus}&programresult=${resultstatus}&pagelimit=${pageSize}&pageoffset=${pageIndex}&startdate=${startdate}&endDate=${enddate}&IsPageCountRequired=true`)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  adminPaymentlistNextpage(programstatus,resultstatus,startdate, enddate, pageIndex, pageSize) {    
    return this.http.get(`${environment.apiUrl}/admincontroller/programreport?programstatus=${programstatus}&programresult=${resultstatus}&pagelimit=${pageSize}&pageoffset=${pageIndex}&startdate=${startdate}&endDate=${enddate}&IsPageCountRequired=false`)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  adminPaymentNextpage(startdate, enddate, pageIndex, pageSize) {
    return this.http.get(`${environment.apiUrl}/payment/getpayment?pagelimit=${pageSize}&pageoffset=${pageIndex}&IsPageCountRequired=false&startdate=` + startdate + `&endDate=` + enddate)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  adminPaymentSearch(search,pageIndex, pageSize) {    
    return this.http.get(`${environment.apiUrl}/payment/searchpayment?search=${search}&pagelimit=${pageSize}&pageoffset=${pageIndex}&ispagerequired=true`)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  adminPaymentSearchNextpage(search,pageIndex, pageSize) {    
    return this.http.get(`${environment.apiUrl}/payment/searchpayment?search=${search}&pagelimit=${pageSize}&pageoffset=${pageIndex}&ispagerequired=false`)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  adminSearchprogramreport(search,pageIndex, pageSize) {       
    return this.http.get(`${environment.apiUrl}/admincontroller/searchprogramreport?search=${search}&pagelimit=${pageSize}&pageoffset=${pageIndex}&ispagerequired=true`)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  adminSearchprogramreportNextpage(search,pageIndex, pageSize) {       
    return this.http.get(`${environment.apiUrl}/admincontroller/searchprogramreport?search=${search}&pagelimit=${pageSize}&pageoffset=${pageIndex}&ispagerequired=false`)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  adminStudentRegreport(startdate, enddate, instituteguid, pageIndex, pageSize) {
    console.log(instituteguid)
    return this.http.get(`${environment.apiUrl}/admincontroller/studentreport?instituteguid=` + instituteguid + `&startdate=` + startdate + `&endDate=` + enddate + `&pagelimit=${pageSize}&pageoffset=${pageIndex}&IsPageCountRequired=true`)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  adminStudentRegSearch(search,pageIndex, pageSize) {        
    return this.http.get(`${environment.apiUrl}/report/searchreport?search=${search}&pagelimit=${pageSize}&pageoffset=${pageIndex}&ispagerequired=true`)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  adminStudentRegSearchNextpage(search,pageIndex, pageSize) {        
    return this.http.get(`${environment.apiUrl}/report/searchreport?search=${search}&pagelimit=${pageSize}&pageoffset=${pageIndex}&ispagerequired=false`)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  adminStudentRegreportNextpage(startdate, enddate, instituteguid, pageIndex, pageSize) {
    console.log(instituteguid)
    return this.http.get(`${environment.apiUrl}/admincontroller/studentreport?instituteguid=` + instituteguid + `&startdate=` + startdate + `&endDate=` + enddate + `&pagelimit=${pageSize}&pageoffset=${pageIndex}&IsPageCountRequired=false`)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  adminInstituteList() {
    return this.http.get(`${environment.apiUrl}/admincontroller/institutelist`)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  institteStudentlist() {
    return this.http.get(`${environment.apiUrl}/insadmincontroller/studentlist`).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  institutedropdownlist() {
    return this.http.get(`${environment.apiUrl}/admincontroller/institutelist`).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  AddInstituteStudent(data) {
    return this.http.post(`${environment.apiUrl}/insadmincontroller/registerstudent`, data).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  SearchTestimonial(data) {
    return this.http.get(`${environment.apiUrl}/admincontroller/searchtestimonial?search=`+data).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  adminprogramreportStatusdrpbtn() {    
    return this.http.get(`${environment.apiUrl}/dropdown/ProgramStatus`)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  adminprogramreportResultdrpbtn() {        
    return this.http.get(`${environment.apiUrl}/dropdown/ProgramResult`)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  CreateTestimonial(data) {
    return this.http.post(`${environment.apiUrl}/admincontroller/testimonial`, data).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  UpdateTestimonial(data) {
    return this.http.put(`${environment.apiUrl}/admincontroller/testimonial`, data).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  DeleteTestimonial(id) {
    console.log(id)
    return this.http.delete(`${environment.apiUrl}/admincontroller/testimonial?testimonialid=` + id)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  ListTestimonial(pageIndex, pageSize) {
    return this.http.get(`${environment.apiUrl}/testimonial?pagelimit=${pageSize}&pageoffset=${pageIndex}&IsPageCountRequired=true`).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  ListTestimonialnextPage(pageIndex, pageSize) {
    return this.http.get(`${environment.apiUrl}/testimonial?pagelimit=${pageSize}&pageoffset=${pageIndex}&IsPageCountRequired=false`).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  updatefee(data) {
    return this.http.put(`${environment.apiUrl}/admincontroller/registrationfee`, data)
      .pipe(
        map((data: any) => {
          if (data) {
            return data;
          }
        }),
        catchError(err => {
          return throwError(err);
        }),
      );
  }

  getfeeslist() {
    return this.http.get(`${environment.apiUrl}/fee`).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  changePassword(pwd: Password) {

    const old_password = pwd.oldpassword;
    const new_password = pwd.newpassword;
    const stat = {
      "oldpassword": old_password,
      "newpassword": new_password
    }
    return this.http.put(`${environment.apiUrl}/student/UpdatePassword`, stat)
      .pipe(
        map((data: any) => {
          if (data) {
            return data;
          }
        }),
        catchError(err => {
          return throwError(err);
        }),
      );
  }

  changeordersubmit(dat) {
    let orderdata = {
      "TopicList": dat
    }

    console.log(orderdata)

    return this.http.put(`${environment.apiUrl}/admincontroller/changeorder`, orderdata)
      .pipe(
        map((data: any) => {
          if (data) {
            return data;
          }
        }),
        catchError(err => {
          return throwError(err);
        }),
      );
  }

  createquestions(payload) {
    return this.http.post(`${environment.apiUrl}/admincontroller/uploadQuestion`, payload).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  updatequestions(payload) {    
    return this.http.put(`${environment.apiUrl}/admincontroller/updatequestion`, payload).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  changeshowstate(pid, toglestate) {
    let stat = {
      "programguid": pid,
      "keyprogram": toglestate
    }
    return this.http.put(`${environment.apiUrl}/admincontroller/updatekeyprogram`, stat).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  topicgetdescription(topid) {
    return this.http.get(`${environment.apiUrl}/admincontroller/topicdescription?topicguid=` + topid).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  getquestions(tpid) {
    return this.http.get(`${environment.apiUrl}/admincontroller/getquestions?topicguid=` + tpid).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  deletequestions(id, sguid) {
    console.log(id)
    return this.http.delete(`${environment.apiUrl}/admincontroller/removequestions?questionid=` + id + `&topicguid=` + sguid)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  deleteimg(id) {
    console.log(id)
    return this.http.delete(`${environment.apiUrl}/admincontroller/removeimage?questionid=` + id)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  dashboardkeyprograms() {
    // http://164.52.216.127:8555/api/keyprogram?pagelimit=10&pageoffset=0&ispagerequired=true&categorytype=0
    // return this.http.get(`${environment.apiUrl}/keyprogram`)
    return this.http.get(`${environment.apiUrl}/keyprogram?pagelimit=6&pageoffset=0&ispagerequired=true&categorytype=0`)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  getallkeyprograms(pageIndex, pageSize, cat) {
    // http://164.52.216.127:8555/api/keyprogram?pagelimit=10&pageoffset=0&ispagerequired=true&categorytype=0
    // return this.http.get(`${environment.apiUrl}/keyprogram`)
    return this.http.get(`${environment.apiUrl}/keyprogram?pagelimit=`+ pageSize +`&pageoffset=`+ pageIndex +`&ispagerequired=true&categorytype=` + cat)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  gettestimonial() {
    return this.http.get(`${environment.apiUrl}/testimonial?pagelimit=10&pageoffset=0&IsPageCountRequired=true`)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  changequestionordersubmit(dat, gid) {
    let orderdata = {
      "topicguid": gid,
      "questionlist": dat
    }

    console.log(orderdata)

    return this.http.post(`${environment.apiUrl}/admincontroller/changequestionorder`, orderdata)
      .pipe(
        map((data: any) => {
          if (data) {
            return data;
          }
        }),
        catchError(err => {
          return throwError(err);
        }),
      );
  }

  videouplaod(dat) {
    console.log(dat)

    return this.http.post(`${environment.apiUrl}/admincontroller/uploadvideo`, dat)
      .pipe(
        map((data: any) => {
          if (data) {
            return data;
          }
        }),
        catchError(err => {
          return throwError(err);
        }),
      );
  }

  getvideos(tpid) {
    return this.http.get(`${environment.apiUrl}/admincontroller/gettopicvideo?topicguid=` + tpid).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  deletevideo(id) {
    console.log(id)
    const slotvalue = {};
    return this.http.put(`${environment.apiUrl}/admincontroller/removevideo?topicguid=` + id, slotvalue).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  downloadCertificate(studentprogrammapid) {
    return this.http
      .get(`${environment.apiUrl}/pdf?studentprogrammapid=` + studentprogrammapid, { responseType: 'blob' })
      .pipe(
        map((data: any) => {
          if (data) {
            return data;
          }
        }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  changepubstate(pstat) {
    return this.http.post(`${environment.apiUrl}/admincontroller/publishprogram`, pstat).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  emailinitpay(pstat) {
    return this.http.post(`${environment.apiUrl}/payment/initiatepayment`, pstat).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  paymentsubmit(pstat) {
    return this.http.post(`${environment.apiUrl}/payment/createpayment`, pstat).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  getfee() {
    return this.http
      .get(`${environment.apiUrl}/payment/getfees`)
      .pipe(
        map((data: any) => {
          if (data) {
            return data;
          }
        }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }


  forgotmail(data) {

        let fordata = {
            "email":data.email
        }

        return this.http.post(`${environment.apiUrl}/forgetpassword`, fordata)
            .pipe(
                map((data: any) => {
                    if (data) {
                        return data;
                    }
                }),
                catchError(err => {
                    return throwError(err);
                })
            );
    }
    Programdeleteimage(data) {  
      const options = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json'
        }),
        body: data
      }  
      return this.http.delete(`${environment.apiUrl}/admincontroller/removeprogramimage`, options).
        pipe(map((data: any) => {
          if (data) {
            return data;
          }
        }),
          catchError((err) => {
            return throwError(err);
          })
        );
    }
    getprogramimage(data) {
      return this.http
        .get(`${environment.apiUrl}/admincontroller/getprogramimage?programguid=`+data)
        .pipe(
          map((data: any) => {
            if (data) {
              return data;
            }
          }),
          catchError((err) => {
            return throwError(err);
          })
        );
    }
    addprogramimage(data) {
      return this.http
        .post(`${environment.apiUrl}/admincontroller/uploadprogramimage`,data)
        .pipe(
          map((data: any) => {
            if (data) {
              return data;
            }
          }),
          catchError((err) => {
            return throwError(err);
          })
        );
    }

    addprogramvideo(data) {
      return this.http
        .post(`${environment.apiUrl}/admincontroller/uploadprogramvideo`,data)
        .pipe(
          map((data: any) => {
            if (data) {
              return data;
            }
          }),
          catchError((err) => {
            return throwError(err);
          })
        );
    }
    deleteprogramvideo(data) {  
      const options = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json'
        }),
        body: data
      }  
      return this.http.delete(`${environment.apiUrl}/admincontroller/removeprogramvideo`, options).
        pipe(map((data: any) => {
          if (data) {
            return data;
          }
        }),
          catchError((err) => {
            return throwError(err);
          })
        );
    }
    getprogramvideo(data) {
      return this.http
        .get(`${environment.apiUrl}/admincontroller/getprogramvideo?programguid=`+data)
        .pipe(
          map((data: any) => {
            if (data) {
              return data;
            }
          }),
          catchError((err) => {
            return throwError(err);
          })
        );
    }
    getprogramdescription(data) {
      return this.http
        .get(`${environment.apiUrl}/admincontroller/getprogramdescription?programguid=`+data)
        .pipe(
          map((data: any) => {
            if (data) {
              return data;
            }
          }),
          catchError((err) => {
            return throwError(err);
          })
        );
    }

    getTopicdescriptionlist(data) {
      // http://localhost:8002/api/admincontroller/topicdescription?topicguid=9e5e4453-38b7-4b84-a7dd-08903344dec3
      return this.http
        .get(`${environment.apiUrl}/admincontroller/topicdescription?topicguid=`+data)
        .pipe(
          map((data: any) => {
            if (data) {
              return data;
            }
          }),
          catchError((err) => {
            return throwError(err);
          })
        );
    }


    checkpublishstatus(pid) {
      return this.http
        .get(`${environment.apiUrl}/program/checkprogrampublishstatus?programguid=` + pid)
        .pipe(
          map((data: any) => {
            if (data) {
              return data;
            }
          }),
          catchError((err) => {
            return throwError(err);
          })
        );
    }

    adminProgramlistSearch(search,pageIndex, pageSize, category) {    
      return this.http.get(`${environment.apiUrl}/program/searchstudentprogramlist?search=${search}&pagelimit=${pageSize}&pageoffset=${pageIndex}&IsPageCountRequired=true&categorytype=${category}`).
        pipe(map((data: any) => {
          if (data) {
            return data;
          }
        }),
          catchError((err) => {
            return throwError(err);
          })
        );
    }

    landingBanner() {
      return this.http.get(`${environment.apiUrl}/keyprogram/getbannerlist`)
        .pipe(
          map((data: any) => {
            if(data) {
              return data;
            }
          }),
          catchError((err) => {
            return throwError(err);
          })
        )
    }
    
    uploadprogramDescription(data){
      return this.http.post(`${environment.apiUrl}/admincontroller/uploaddescription`, data)
        .pipe(
          map((data: any) => {
            if(data) {
              return data;
            }
          }),
          catchError((err) => {
            return throwError(err);
          })
        )
    }

    getstudentprogramDetails(id){
      return this.http.get(`${environment.apiUrl}/student/getprogramdetailsstudent?programguid=`+id)
        .pipe(
          map((data: any) => {
            if(data) {
              return data;
            }
          }),
          catchError((err) => {
            return throwError(err);
          })
        )
    }

 forcestop(data){
      return this.http.put(`${environment.apiUrl}/student/Updateforcestop`, data)
      .pipe(map((data: any) => {
        if(data) {
          return data
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      )
    }

  listadminfaq(pageIndex, pageSize) {
    return this.http.get(`${environment.apiUrl}/admincontroller/getfaqdetailsbyadmin`).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

   updatefaq(data) {
    return this.http.put(`${environment.apiUrl}/admincontroller/updatefaq`, data).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  createadminfaq(data) {
    return this.http.post(`${environment.apiUrl}/admincontroller/Createfaq`, data).
      pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

   deleteadminfaq(id) {
    return this.http.delete(`${environment.apiUrl}/admincontroller/deletefaq?faqid=`+id)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      )
    }

  // Publish adminFAQ
  publishadminfaq(payload) {
    const stat = {};
    return this.http.put(`${environment.apiUrl}/admincontroller/PublishFAQ`, payload)
      .pipe(
        map((data: any) => {
          if (data) {
            return data;
          }
        }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

   // Publish adminCategory
  publishadmincategory(payload) {
    const stat = {};
    return this.http.put(`${environment.apiUrl}/admincontroller/updatecategorystatus`, payload)
      .pipe(
        map((data: any) => {
          if (data) {
            return data;
          }
        }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  getadminCategories() {
    return this.http.get(`${environment.apiUrl}/admincontroller/Category`)
      .pipe(map((data:any) => {
        if(data){
          return data;
        }
      }),
      catchError((err) => {
        return throwError(err);
      })
    );
  }

  check() {
    return this.http.get(`http://164.52.216.127:6678/api/GetJoblist`)
      .pipe(map((data:any) => {
        if(data){
          return data;
        }
      }),
      catchError((err) => {
        return throwError(err);
      })
    );
  }

}

