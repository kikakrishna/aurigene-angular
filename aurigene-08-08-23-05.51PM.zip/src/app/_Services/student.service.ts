import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, throwError } from 'rxjs';
import { catchError, map, switchMap } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
// import { switchMap, map, tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  constructor(private http: HttpClient, private router: Router) { }

  mystudentListprograms() {    
    return this.http.get(`${environment.apiUrl}/student/myprograms`)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  studentListprograms() {
    return this.http.get(`${environment.apiUrl}/program/studentprogramlist?programlevel_id=1&pagelimit=50&pageoffset=0&IsPageCountRequired=false`)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  studentListprogramswithCategory(cateid) {
    return this.http.get(`${environment.apiUrl}/program/studentprogramlist?programlevel_id=1&pagelimit=50&pageoffset=0&IsPageCountRequired=false&categorytype=` + cateid)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  studentStartprogram(data) {
    return this.http.post(`${environment.apiUrl}/startprogram`, data)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  studentTopiclist(id) {
    return this.http.get(`${environment.apiUrl}/topic/gettopiclist?id=` + id)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  studentDescription(id) {
    return this.http.get(`${environment.apiUrl}/topic/getdescription?Id=` + id)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  studentIntializeTopictestid(id) {
    let payload = {
      Id: id
    }
    return this.http.post(`${environment.apiUrl}/topic/InitializeTopicTest`, payload)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  studentSubmittopictest(data) {
    return this.http.post(`${environment.apiUrl}/topic/submittopictest`, data)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  studentExamploadimage(url: string): Observable<string> {
    return this.http.get(url, { responseType: 'blob' })
      .pipe(
        switchMap(response => this.readFile(response))
      );
  }
  private readFile(blob: Blob): Observable<string> {
    return Observable.create(obs => {
      const reader = new FileReader();

      reader.onerror = err => obs.error(err);
      reader.onabort = err => obs.error(err);
      reader.onload = () => obs.next(reader.result);
      reader.onloadend = () => obs.complete();

      return reader.readAsDataURL(blob);
    });
  }

  studentGetvideobyId(id) {
    return this.http.get(`${environment.apiUrl}/topic/getvideo?Id=` + id)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  studentPlayvideobyName(name) {
    const headers = new HttpHeaders().set('Content-Type', 'text/plain; charset=utf-8');

    return this.http.get(`${environment.apiUrl}/video/playvideo?video=` + name, { headers, responseType: 'text' })
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  studentPlayvideobyNameios(name) {
    const headers = new HttpHeaders().set('Content-Type', 'text/plain; charset=utf-8');

    return this.http.get(`${environment.apiUrl}/videompeg/getmpeg?video=` + name, { headers, responseType: 'text' })
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  studentvideoSegment(segment) {
    return this.http.get(`${environment.apiUrl}/video/` + segment)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  getprofile() {
    return this.http
      .get(`${environment.apiUrl}/student/studentprofile`)
      .pipe(
        map((data: any) => {
          if (data) {
            return data;
          }
        }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  profileupdate(data) {
    return this.http.put(`${environment.apiUrl}/student/updatestudent`, data)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }


  // studentExamploadimage(url: string): Observable<string> {
  //   return this.http.get(url, { responseType: 'blob' })
  //     .pipe(
  //       switchMap(response => this.readFile(response))
  //     );
  // }
  private readFile2(blob: Blob): Observable<string> {
    return Observable.create(obs => {
      const reader = new FileReader();

      reader.onerror = err => obs.error(err);
      reader.onabort = err => obs.error(err);
      reader.onload = () => obs.next(reader.result);
      reader.onloadend = () => obs.complete();

      return reader.readAsDataURL(blob);
    });
  }
  // studentExamploadimage(data) {   
  //   return this.http.get(data)
  //   .pipe(map((data: any) => {
  //       if (data) {
  //         return data;
  //       }
  //     }),
  //       catchError((err) => {
  //         return throwError(err);
  //       })
  //     );
  // }
  // adminPaymentlistNextpage(programstatus,resultstatus,startdate, enddate, pageIndex, pageSize) {    

  studentPayment(startdate, enddate, pageIndex, pageSize) {
    return this.http.get(`${environment.apiUrl}/payment/getpaymentforstudent?pagelimit=${pageSize}&pageoffset=${pageIndex}&IsPageCountRequired=true&startdate=${startdate}&endDate=${enddate}`)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  studentPaymentNext(startdate, enddate, pageIndex, pageSize) {
    return this.http.get(`${environment.apiUrl}/payment/getpaymentforstudent?pagelimit=${pageSize}&pageoffset=${pageIndex}&IsPageCountRequired=false&startdate=${startdate}&endDate=${enddate}`)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  landingProgramdetails(pguid) {    
    return this.http.get(`${environment.apiUrl}/keyprogram/getkeyprogramdetails?programguid=`+pguid)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  landingPlayvideo(name) {
    // http://164.52.216.127:8555/api/keyprogram/PlayprogramVideo?video=vY7WN2IGlVc1zcR0yzPmr.mp4
    const headers = new HttpHeaders().set('Content-Type','text/plain; charset=utf-8');

    return this.http.get(`${environment.apiUrl}/keyprogram/PlayprogramVideo?video=` + name, { headers, responseType: 'text' })
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  getfaqlist() {
    return this.http.get(`${environment.apiUrl}/keyprogram/getfaqdetails`)
    .pipe(map((data: any) => {
      if(data) {
        return data;
      }
    }),
      catchError((err) => {
        return throwError(err);
      })  
    )
  }

  gettopicScore(topicId) {
    return this.http.get(`${environment.apiUrl}/topic/gettopicscorestatus?student_program_topicmap_id=`+ topicId)
    .pipe(map((data: any) => {
      if(data) {
        return data;
      }
    }),
      catchError((err) => {
        return throwError(err);
      })  
    )
  }
}
