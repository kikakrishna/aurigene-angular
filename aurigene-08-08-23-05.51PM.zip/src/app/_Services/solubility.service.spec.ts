import { TestBed } from '@angular/core/testing';

import { SolubilityService } from './solubility.service';

describe('SolubilityService', () => {
  let service: SolubilityService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SolubilityService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
