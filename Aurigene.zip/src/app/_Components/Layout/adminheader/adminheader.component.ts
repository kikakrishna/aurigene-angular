import { Component, OnInit, OnDestroy, Inject } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AuthenticationService } from 'src/app/_Services/authentication.service';
import { Router } from '@angular/router';
import { ToastService } from 'ng-uikit-pro-standard';

import { MsalService, MsalBroadcastService, MSAL_GUARD_CONFIG, MsalGuardConfiguration } from '@azure/msal-angular';
import { InteractionStatus, RedirectRequest } from '@azure/msal-browser';
import { Subject } from 'rxjs';
import { filter, takeUntil } from 'rxjs/operators';

import { FormControl, FormGroup, NgForm,FormBuilder, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { SolubilityService } from 'src/app/_Services/solubility.service';
import * as moment from 'moment';



@Component({
  selector: 'app-adminheader',
  templateUrl: './adminheader.component.html',
  styleUrls: ['./adminheader.component.css']
})
export class AdminheaderComponent implements OnInit {
  
  menusection: boolean = false;
  userinfo;
  username;
  usernamesession;

  constructor(@Inject(MSAL_GUARD_CONFIG) private msalGuardConfig: MsalGuardConfiguration,
   private broadcastService: MsalBroadcastService, private authService: MsalService,
   public authenticationService: AuthenticationService, public dialog: MatDialog, public router: Router,
    private toastrService: ToastService,private _solubilityservice: SolubilityService,
) { }

  ngOnInit(): void {
    this.getUserDetails();
    // this.userinfo = JSON.parse(sessionStorage.getItem("userinfo"))
    // console.log(this.userinfo)
    // alert()

    if(localStorage.getItem('Loggedin-user')){
       this.usernamesession = localStorage.getItem('Loggedin-user');
      //  this.getUserDetails();
    }

  }

  getUserDetails(): void {
      this._solubilityservice.getuserdetails() 
          .pipe(first())
          .subscribe((res: any) => {
           console.log('logged user response: ', res)
            if(res.responseMessage){
              this.username = res.responseMessage.firstname;
              localStorage.setItem('Loggedin-user',res.responseMessage.firstname);    
              //localStorage.removeItem('token');  
              console.log('user', res.responseMessage.firstname, res.responseMessage.userguid,res.responseMessage.email)
            }
          }
      )
  }

  /*logout() {
    this.authenticationService.logout();
    // this.authenticationService.currentUserSubject.next(null);
    // sessionStorage.clear();
    // this.router.navigate(['/login']);
  }*/

  logout() { // Add log out function here
    localStorage.removeItem('Loggedin-user');  
    this.authService.logoutRedirect({
     postLogoutRedirectUri: 'https://localhost:4200'
    });
  }

  updatePassword() {
    // const dialogRef = this.dialog.open(UpdatepasswordComponent, {
    //   width: '330px',
    //   panelClass: 'updatepassword-dialog',
    //   autoFocus: false,
    // });
    // dialogRef.afterClosed().subscribe((result) => {
    //   if (result) {
    //     console.log(result)

    //   }
    // },

    // );
  }

  openmenu() {
    this.menusection = !this.menusection;
  }

  closemenu() {
    this.menusection = false;
  }

  updateFees() {
    // const dialogRef = this.dialog.open(AdminUpdatefeeComponent, {
    //   width: '330px',
    //   panelClass: 'updatepassword-dialog',
    //   autoFocus: false,
    // });
    // dialogRef.afterClosed().subscribe((result) => {
    //   if (result) {
    //     console.log(result)

    //   }
    // },

    // );
  }

  

}
