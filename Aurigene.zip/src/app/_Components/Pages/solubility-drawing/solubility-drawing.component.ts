import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { SolubilityService } from 'src/app/_Services/solubility.service';
import { MatRadioChange } from '@angular/material/radio';
import { FormControl, FormGroup, NgForm, FormBuilder, Validators } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { SelectionModel } from '@angular/cdk/collections';
import { MatDialog } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { ToastService } from 'ng-uikit-pro-standard';
import { ActivatedRoute, Router } from '@angular/router';
import { first } from 'rxjs/operators';
import { FormGroupDirective } from '@angular/forms';
import { SolubilityDrawingPopupComponent } from '../solubility-drawing-popup/solubility-drawing-popup.component';

export interface PeriodicElement {
  // no:string;
  smile: string;
  // compoundcode: string;
  // compoundname: string;
  // batchnumber: string;
  // project: string;
}

declare global {
  interface Window { // ⚠️ notice that "Window" is capitalized here
    cdw: any;
    perks: any;
  }
}
@Component({
  selector: 'app-solubility-drawing',
  templateUrl: './solubility-drawing.component.html',
  styleUrls: ['./solubility-drawing.component.css']
})

export class SolubilityDrawingComponent implements OnInit {
  @ViewChild('iframe') iframe: ElementRef;
  formsolubilitydraw: FormGroup;
  displayedColumns: string[] = ['select', 'smile'];

  loading: boolean;
  drawingform: FormGroup;
  projectname: any;
  projectcode: any;
  projectcompound: any;
  projectId: any;
  projectCode: any;
  selectedCompound: any;
  algorithm: any;
  selection = new SelectionModel<any>(true, []);
  public dataSource: any = new MatTableDataSource([]);


  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.filteredData.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  toggleAllRows() {
    if (this.isAllSelected()) {
      this.selection.clear();
      return;
    }
    this.selection.select(...this.dataSource.data);
  }

  /** The label for the checkbox on the passed row */
  checkboxLabel(row?): string {
    if (!row) {
      return `${this.isAllSelected() ? 'deselect' : 'select'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${+ 1}`;
  }
  constructor(
    private _formBuilder: FormBuilder,
    public toastrService: ToastService,
    public dialog: MatDialog,
    private _solubilityservice: SolubilityService,
    private router: Router,
  ) { }

  ngOnInit(): void {

    this.Getalgorithms()

    this.loading = true;
    window.perks;

    this.drawingform = this._formBuilder.group({
      "project": ['', [Validators.required]],
      "Solubilityrun": ['', [Validators.required]]
    })

    var chemdrawjsAttached = function (chemdraw) {
      // do something
      // console.log('yes', chemdraw);
      window.cdw = chemdraw;
      var isBlank = window.cdw.isBlankStructure();
      // console.log(isBlank);
    };
    var chemdrawjsFailed = function (error) {
      alert(error);
    };

    this._solubilityservice.getproject()
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        this.projectcode = res?.data.ProjectList;
      },
        err => {
        });

    window.perkinelmer.ChemdrawWebManager.attach({
      id: 'chemdrawjs-container',
      callback: chemdrawjsAttached,
      errorCallback: chemdrawjsFailed,
      // licenseUrl: 'http://106.51.19.134:81/18.1.2/js/sample/ChemDraw-JS-License.xml'
      // licenseUrl : 'https://chemdrawqa.aurigene.com/20.0.0/js/sample/ChemDraw-JS-License.xml'
      licenseUrl : 'https://chemdraw.aurigene.com/20.0.0/js/sample/ChemDraw-JS-License.xml?wasm=1'
    });

    setTimeout(() => {
      this.loading = false;
    }, 1500)

  }

  selectedproject(event) {
    this.projectCode = event.value.projectCode;
    this.projectId = event.value.projectId;
    var CompoundList = event.value.projectId;
    console.log(event);

    if (event.value != undefined) {
      this.projectcode.map((data) => {
        if (data.projectId == this.projectId) {
          this.projectCode = data.projectCode;
        }
      })
    }

    this._solubilityservice.getcompound(CompoundList)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.error) {
          this.projectcompound = res?.data.CompoundList;
          var tempview = []
          this.projectcompound.map((item, i) => {
            tempview.push({
              componentID: item,
              isChecked: false,
              componentIndex: i
            })
          })
          this.projectcompound = tempview
          if (tempview.length == 0) {
            this.projectcompound = tempview;
          }
          console.log('cpmponddetails---' + this.projectcompound);
        } else {
          this.projectcompound = tempview;
        }
        this.selectedCompound = [];
      },
        err => {
        });
  }

  ngAfterViewInit() {
    // this.loading = false;
  }

  onLoad() {
    this.loading = false;
  }
  resetForm() {
    // this.drawingform.reset();
    window.cdw.clear();
  }

  getProperties() {
    console.log('formobject-----------', this.selection.selected);
    console.log('formobject-----------', this.selection.selected.length);

    console.log('project-----------', this.projectId);
    console.log('solubilityrun-----------', this.drawingform.value.Solubilityrun);

    
    if (this.selection.selected.length !== 0) {
      if (this.projectId !== "" && this.projectId !== undefined
        && this.drawingform.value.Solubilityrun !== "" && this.drawingform.value.Solubilityrun !== undefined) {
        console.log("fwefwerferfe4f");
        console.log('yessss', window.cdw);
        // let barArray = [{ item: 'one' }, { item: 'two' }];
        // let data = new FormData();

        console.log('formobject-----------', this.selection.selected);
        var smilemain = []
        var cdxmlmain = []
        var molmain = []
        var datamain = []

        for (const element of this.selection.selected) {
          console.log("element---------", element);

          smilemain.push(element.smile)
          cdxmlmain.push(element.cdxml)
          molmain.push(element.mol)
          datamain.push(element.data)

        }
        var xsmilemain = smilemain.toString()
        var xcdxmlmain = cdxmlmain.toString()
        var xmolmain = molmain.toString()
        var xdatamain = datamain.toString()

        console.log(xsmilemain.replace(/['"]+/g, ''));
        console.log(xcdxmlmain.replace(/['"]+/g, ''));
        console.log(xmolmain.replace(/['"]+/g, ''));
        console.log(xdatamain.replace(/['"]+/g, ''));

        const formdatafileupload = new FormData();
        formdatafileupload.append('smile', xsmilemain);
        formdatafileupload.append('cdxml', xcdxmlmain);
        formdatafileupload.append('mol', xmolmain);
        formdatafileupload.append('data', xdatamain);
        formdatafileupload.append('projectCode', this.projectCode);
        formdatafileupload.append('projectId', this.projectId);
        formdatafileupload.append('algorithm_id', this.drawingform.value.Solubilityrun);
        this.loading = true;
        this._solubilityservice.soluabilitydrawing(formdatafileupload)
          .pipe(first())
          .subscribe((res: any) => {
            this.loading = false;
            // console.log('draw res ', res);
            if (!res.error) {
              this.drawingform.reset();
              window.cdw.clear();
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.success('', res.responseMessage, options);
              res.data.map((details) => {
                // console.log(details.job_jobid);
                this.router.navigate([`/solubilityrun/${details.job_jobid}`]);
              })
            } else {
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.error('', res.errorMessage, options);
            }
          },
            err => {
              // console.log('error', err);
            });

      } else {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', "Please enter all fields", options);
      }
    } else {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', "Please select the smiles", options);
    }
  }



  getSmile() {
    //console.log('job input ', this.drawingform.value.jobname)
    let smileobjs;
    window.cdw.getSMILES(function (result) {
      var smiles = result;
      if (smiles != '') {
        smileobjs = smiles;
        // console.log('smiles....', smiles);
      } else {
        // console.log('Its empty');

      }

    });
    // console.log('smiles ', smileobjs);

    if (smileobjs != undefined) {
      const dialogRef = this.dialog.open(SolubilityDrawingPopupComponent, {
        panelClass: 'calendarwrapper',
        data: smileobjs

      });
      dialogRef.afterClosed().subscribe(result => {
        if (result) {
          if (!result.data.isError) {
          }
        }
      });

    }
  }

  myFunction() {
    // console.log('check');
  }
  func1() {
    // console.log('tests')
  }



  Getalgorithms() {
    this._solubilityservice.GetAlgorithm()
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res?.responseMessage)
        this.algorithm = res?.responseMessage;
      },
        err => {
        });
  }
  smilearraycopy: any[];


  //   console.log("addsmiles" + JSON.stringify(this.smilearraycopy));
  //   let smileobjs;
  //   var smilearray = []
  //   window.cdw.getSMILES(function (result) {
  //     var smileso = result;
  //     if (smileso != '') {

  //       smileobjs = smileso;
  //       console.log('smiles....', smileso);

  //       var sample = {
  //         "smile": smileso,
  //       }

  //       smilearray.push(sample);
  //       console.log('smilearray....', smilearray);
  //     } else {
  //       console.log('Its empty', smileso);

  //     }
  //   });

  //   if (this.smilearraycopy == undefined) {

  //     console.log("undef");

  //     this._solubilityservice.getsmileboolean(smileobjs)
  //       .pipe(first())
  //       .subscribe((res: any) => {
  //         setTimeout(() => {
  //           if (!res.error) {
  //             this.loading = false;
  //             this.smilearraycopy = [...smilearray]
  //             console.log("res");
  //             this.dataSource = new MatTableDataSource(this.smilearraycopy)

  //           } else {
  //             this.loading = false;
  //             const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //             this.toastrService.warning('', res?.errorMessage, options);
  //             console.log("!res");

  //           }
  //           console.log("addsmiles" + JSON.stringify(this.smilearraycopy));

  //         }, );

  //       },
  //         err => {
  //         });

  //   } else {
  //     console.log("not-undef");

  //     // const checkIfExist = this.smilearraycopy.findIndex(data => data.smile === smileobjs);

  //     // console.log('smilearray....', checkIfExist);

  //     // if (checkIfExist == -1) {
  //       //  Array.prototype.push.apply(this.smilearraycopy, smilearray);
  //       this._solubilityservice.getsmileboolean(smileobjs)
  //         .pipe(first())
  //         .subscribe((res: any) => {
  //           setTimeout(() => {
  //             if (!res.error) {
  //               this.loading = false;            
  //               this.smilearraycopy.push(...smilearray);
  //               console.log("res");
  //               this.dataSource = new MatTableDataSource(this.smilearraycopy)

  //             } else {
  //               this.loading = false;
  //               const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //               this.toastrService.warning('', res?.errorMessage, options);
  //               console.log("!res");

  //             }
  //             console.log("addsmiles" + JSON.stringify(this.smilearraycopy));

  //           }, );

  //         },
  //           err => {
  //           });
  //     // } 
  //     // else {
  //     //   const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //     //   this.toastrService.warning('', "smile already exist in table", options);
  //     // }


  //   }




  //   // console.log("addsmiles" + JSON.stringify(this.smilearraycopy));


  // }


  // Final func 
  addsmiles() {
    console.log("addsmiles" + JSON.stringify(this.smilearraycopy));
    let smileobjs;
    var smilearray = []

    let cdxmlobl;
    let molobj;
    let imgobj;



    var cdxml = window.cdw.getCDXML();
    cdxmlobl = cdxml;
    // console.log('cdxml..... ', cdxml);


    window.cdw.getMOL(function (mol, error) {
      if (!error) {
        // console.log('mol....', mol);
        molobj = mol;
      } else {
        // console.log('mol error', error);
      }
    });


    var img = window.cdw.getImgUrl();
    // console.log('imageutl..... ', img);
    imgobj = img;



    window.cdw.getSMILES(function (result) {
      var smileso = result;
      if (smileso != '') {

        smileobjs = smileso;
        console.log('smiles....', smileso);

        var sample = {
          "smile": smileso,
          "cdxml": cdxmlobl,
          "mol": molobj,
          "data": imgobj,
        }

        smilearray.push(sample);
        console.log('smilearray....', smilearray);
      } else {
        console.log('Its empty', smileso);

      }
    });

    if (this.smilearraycopy == undefined) {

      console.log("undef");

      this._solubilityservice.getsmileboolean(smileobjs)
        .pipe(first())
        .subscribe((res: any) => {
          setTimeout(() => {
            if (!res.error) {
              this.loading = false;
              this.smilearraycopy = [...smilearray]
              console.log("res");
              this.dataSource = new MatTableDataSource(this.smilearraycopy)

            } else {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res?.errorMessage, options);
              console.log("!res");

            }
            console.log("addsmiles" + JSON.stringify(this.smilearraycopy));

          },);

        },
          err => {
          });

    } else {
      console.log("not-undef");

      // const checkIfExist = this.smilearraycopy.findIndex(data => data.smile === smileobjs);

      // console.log('smilearray....', checkIfExist);

      // if (checkIfExist == -1) {
      //  Array.prototype.push.apply(this.smilearraycopy, smilearray);
      this._solubilityservice.getsmileboolean(smileobjs) 
        .pipe(first())
        .subscribe((res: any) => {
          setTimeout(() => {
            if (!res.error) {
              this.loading = false;
              this.smilearraycopy.push(...smilearray);
              console.log("res");
              this.dataSource = new MatTableDataSource(this.smilearraycopy)

            } else {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res?.errorMessage, options);
              console.log("!res");

            }
            console.log("addsmiles" + JSON.stringify(this.smilearraycopy));

          },);

        },
          err => {
          });
      // } 
      // else {
      //   const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      //   this.toastrService.warning('', "smile already exist in table", options);
      // }


    }
    // console.log("addsmiles" + JSON.stringify(this.smilearraycopy));

  }
}