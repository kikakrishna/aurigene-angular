import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SolubilityDrawingComponent } from './solubility-drawing.component';

describe('SolubilityDrawingComponent', () => {
  let component: SolubilityDrawingComponent;
  let fixture: ComponentFixture<SolubilityDrawingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SolubilityDrawingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SolubilityDrawingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
