
import { FormControl, FormGroup, NgForm, FormBuilder, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Component, Inject, OnInit, ViewChild, NgZone, } from '@angular/core';
import { ToastService } from 'ng-uikit-pro-standard';
import { SolubilityService } from 'src/app/_Services/solubility.service';
import { Router } from '@angular/router';
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-myfavourite-popup',
  templateUrl: './myfavourite-popup.component.html',
  styleUrls: ['./myfavourite-popup.component.css']
})
export class MyfavouritePopupComponent implements OnInit {
  myfavpopup: FormGroup;

  constructor(private _formBuilder: FormBuilder,
    public toastrService: ToastService,
    private _solubilityservice: SolubilityService,
    private router: Router,
    public matdialog: MatDialog,
    private _ngZone: NgZone,
    public dialogRef: MatDialogRef<MyfavouritePopupComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit(): void {

    // console.log()
    console.log("data---------", this.data)
    // Form validation
    this.myfavpopup = this._formBuilder.group({
      reportname: ['', [Validators.required]],

    });
  }
  closemenu() {
    this.dialogRef.close();
  }

  savebtn() {
    // console.log("this.data.projectid=======" + this.data.projectid)
    if (this.myfavpopup.valid) {
      console.log(this.data.compoundcode )
      console.log(this.data.searchtypeId )
      if (this.myfavpopup?.value.reportname.trim() !== "") {
        if(this.data.searchtypeId != "" && this.data.searchtypeId != null) {
            if(this.data.projectid && this.data.projectid.length != 0) {

              var formdatafileupload: FormData = new FormData();
              formdatafileupload.append('smile', this.data.smile);
              formdatafileupload.append('startdate', this.data.startdate);
              formdatafileupload.append('enddate', this.data.enddate);
              formdatafileupload.append('typeid', this.data.searchtypeId);
              formdatafileupload.append('reportname', this.myfavpopup.value.reportname);
              formdatafileupload.append('projectid', this.data.projectid);
              formdatafileupload.append('structure_typeid', this.data.structure_typeid);
            } else {
              var formdatafileupload: FormData = new FormData();
              formdatafileupload.append('smile', this.data.smile);
              formdatafileupload.append('startdate', this.data.startdate);
              formdatafileupload.append('enddate', this.data.enddate);
              formdatafileupload.append('typeid', this.data.searchtypeId);
              formdatafileupload.append('reportname', this.myfavpopup.value.reportname);
              formdatafileupload.append('structure_typeid', this.data.structure_typeid);
            }
        }
        else if (this.data.jobname) {
          console.log("jobname")

          var formdatafileupload: FormData = new FormData();
          formdatafileupload.append('jobname', this.data.jobname);
          formdatafileupload.append('startdate', this.data.startdate);
          formdatafileupload.append('enddate', this.data.enddate);
          formdatafileupload.append('typeid', this.data.typeid);
          formdatafileupload.append('reportname', this.myfavpopup.value.reportname);
          console.log("jobname=====" + formdatafileupload)
        } else if (this.data.projectid && this.data.compoundcode == undefined) {
          console.log("projectid")

          var formdatafileupload: FormData = new FormData();
          formdatafileupload.append('projectid', this.data.projectid);
          formdatafileupload.append('startdate', this.data.startdate);
          formdatafileupload.append('enddate', this.data.enddate);
          formdatafileupload.append('typeid', this.data.typeid);
          formdatafileupload.append('reportname', this.myfavpopup.value.reportname);


          console.log("projectid=========" + formdatafileupload)

        } else if (this.data.compoundcode) {
          console.log("projectid&compound")

          var formdatafileupload: FormData = new FormData();
          formdatafileupload.append('projectid', this.data.projectid);
          formdatafileupload.append('compoundcode', this.data.compoundcode);
          formdatafileupload.append('startdate', this.data.startdate);
          formdatafileupload.append('enddate', this.data.enddate);
          formdatafileupload.append('typeid', this.data.typeid);
          formdatafileupload.append('reportname', this.myfavpopup.value.reportname);


          console.log("projectid&compound=========" + formdatafileupload)

        }
        else if (this.data.smile && this.data.project == undefined) {
          console.log("onlysmile")

          var formdatafileupload: FormData = new FormData();
          formdatafileupload.append('smile', this.data.smile);
          formdatafileupload.append('startdate', this.data.startdate);
          formdatafileupload.append('enddate', this.data.enddate);
          formdatafileupload.append('typeid', this.data.typeid);
          formdatafileupload.append('reportname', this.myfavpopup.value.reportname);


          console.log("onlysmile====" + formdatafileupload)

        }
        else if (this.data.smile && this.data.project) {
          console.log("smile&project")

          var formdatafileupload: FormData = new FormData();
          formdatafileupload.append('smile', this.data.smile);
          formdatafileupload.append('startdate', this.data.startdate);
          formdatafileupload.append('enddate', this.data.enddate);
          formdatafileupload.append('typeid', this.data.typeid);
          formdatafileupload.append('reportname', this.myfavpopup.value.reportname);
          formdatafileupload.append('projectid', this.data.project);


          console.log("smile&project====" + formdatafileupload)

        }
        else if (this.data.startdate && this.data.enddate && this.data.projectid == undefined || this.data.jobname == undefined || this.data.smile == undefined) {
          console.log("startdate&enddate")

          var formdatafileupload: FormData = new FormData();
          formdatafileupload.append('startdate', this.data.startdate);
          formdatafileupload.append('enddate', this.data.enddate);
          formdatafileupload.append('typeid', this.data.typeid);
          formdatafileupload.append('reportname', this.myfavpopup.value.reportname);


          console.log("startdate&enddate====" + formdatafileupload)

        }
        // else if(this.data.searchtypeId != "" && this.data.searchtypeId != null) {
        //   if(this.data.project.length != 0) {
        //     var formdatafileupload: FormData = new FormData();
        //     formdatafileupload.append('smile', this.data.smile);
        //     formdatafileupload.append('startdate', this.data.startdate);
        //     formdatafileupload.append('enddate', this.data.enddate);
        //     formdatafileupload.append('typeid', this.data.searchtypeId);
        //     formdatafileupload.append('reportname', this.myfavpopup.value.reportname);
        //     formdatafileupload.append('projectid', this.data.project);
        //     formdatafileupload.append('structure_typeid', this.data.structure_typeid);
        //   } else {
        //     var formdatafileupload: FormData = new FormData();
        //     formdatafileupload.append('smile', this.data.smile);
        //     formdatafileupload.append('startdate', this.data.startdate);
        //     formdatafileupload.append('enddate', this.data.enddate);
        //     formdatafileupload.append('typeid', this.data.searchtypeId);
        //     formdatafileupload.append('reportname', this.myfavpopup.value.reportname);
        //     formdatafileupload.append('structure_typeid', this.data.structure_typeid);
        //   }
        // }

        this._solubilityservice.saveapi(formdatafileupload)
        .pipe(first())
        .subscribe((res: any) => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.success('', res.data, options);
          this.dialogRef.close();
  
        },
          err => {
          });

      } else {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', 'Please enter valid report name', options);
      }

    } else {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please enter report name', options);

    }

   
  }
}
