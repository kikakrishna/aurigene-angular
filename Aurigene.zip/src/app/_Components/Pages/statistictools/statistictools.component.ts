import { Component, OnInit,ViewChild,Input } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { FormControl, FormGroup, NgForm,FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { first } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { ToastService } from 'ng-uikit-pro-standard';
import { SolubilityService } from 'src/app/_Services/solubility.service';
import { ChartConfiguration, ChartOptions, ChartType } from "chart.js";
import * as moment from 'moment';

@Component({
  selector: 'app-statistictools',
  templateUrl: './statistictools.component.html',
  styleUrls: ['./statistictools.component.css']
})
export class StatistictoolsComponent implements OnInit {
  viewscreen1: boolean = false;
  viewscreen2: boolean = false;
  viewscreen3: boolean = false;
  viewscreen4: boolean = false;
  viewscreen5: boolean = false;
  viewscreen6: boolean = false;
  closecreen: boolean = false;
  
  displayedColumns = ['status', 'description', 'edit', 'remove'];

  constructor(
    private http: HttpClient,
    public toastrService: ToastService,
    private _solubilityservice: SolubilityService,
    private router: Router,
    ) { }

  ngOnInit(): void {
      //this.getUserDetails();
    }
/*
  getUserDetails(): void {
      this._solubilityservice.getuserdetails() 
          .pipe(first())
          .subscribe((res: any) => {
           console.log('logged user response: ', res)
            if(res.responseMessage){
              localStorage.setItem('Loggedin-user',res.responseMessage.firstname);    
              //localStorage.removeItem('token');  
             // console.log('user', res.responseMessage.firstname, res.responseMessage.userguid,res.responseMessage.email)
            }
          }
      )
  }*/

  viewclick1() {
    this.viewscreen1 = true;
    this.viewscreen2 = false;
    this.viewscreen3 = false;
    this.viewscreen4 = false;
    this.viewscreen5 = false;
    this.viewscreen6 = false;
    this.closecreen = true;
  }
  viewclick2() {
    this.viewscreen2 = true;
    this.viewscreen1 = false;
    this.viewscreen3 = false;
    this.viewscreen4 = false;
    this.viewscreen5 = false;
    this.viewscreen6 = false;
    this.closecreen = true;
  }
  viewclick3() {
    this.viewscreen3 = true;
    this.viewscreen1 = false;
    this.viewscreen2 = false;
    this.viewscreen4 = false;
    this.viewscreen5 = false;
    this.viewscreen6 = false;
    this.closecreen = true;
  }
  viewclick4() {
    this.viewscreen4 = true;
    this.viewscreen1 = false;
    this.viewscreen3 = false;
    this.viewscreen2 = false;
    this.viewscreen5 = false;
    this.viewscreen6 = false;
    this.closecreen = true;
  }
  viewclick5() {
    this.viewscreen5 = true;
    this.viewscreen1 = false;
    this.viewscreen3 = false;
    this.viewscreen4 = false;
    this.viewscreen2 = false;
    this.viewscreen6 = false;
    this.closecreen = true;
  }
  viewclick6() {
    this.viewscreen6 = true;
    this.viewscreen1 = false;
    this.viewscreen3 = false;
    this.viewscreen4 = false;
    this.viewscreen5 = false;
    this.viewscreen2 = false;
    this.closecreen = true;
  }
  closeclick() {
    this.closecreen = false;
  }
}
