import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SolubilityrunComponent } from './solubilityrun.component';

describe('SolubilityrunComponent', () => {
  let component: SolubilityrunComponent;
  let fixture: ComponentFixture<SolubilityrunComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SolubilityrunComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SolubilityrunComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
