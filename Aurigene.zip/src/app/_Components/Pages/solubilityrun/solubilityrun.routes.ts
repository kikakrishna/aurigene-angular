import { RouterModule } from "@angular/router";
import {SolubilityrunComponent } from "./solubilityrun.component";
export const SolubilityrunRoutes: RouterModule [] = [
    {
        path: '',
        component: SolubilityrunComponent
    }
]