import { RouterModule } from "@angular/router";
import {SolubilityrunlocusComponent } from "./solubilityrunlocus.component";
export const SolubilityrunlocusRoutes: RouterModule [] = [
    {
        path: '',
        component: SolubilityrunlocusComponent
    }
]