import { RouterModule } from "@angular/router";
// import { ComparisonChartComponent } from "./comparison-chart.component";

import { BarchartComponent } from "./barchart.component";


export const BarchartRoutes: RouterModule [] = [
    {
        path: '',
        component: BarchartComponent
    }
]