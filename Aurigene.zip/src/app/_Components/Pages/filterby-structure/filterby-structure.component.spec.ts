import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FilterbyStructureComponent } from './filterby-structure.component';

describe('FilterbyStructureComponent', () => {
  let component: FilterbyStructureComponent;
  let fixture: ComponentFixture<FilterbyStructureComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FilterbyStructureComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FilterbyStructureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
