import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { FormControl, FormGroup, NgForm, FormBuilder, Validators } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { SelectionModel } from '@angular/cdk/collections';
import { FormGroupDirective } from '@angular/forms';
import { ToastService } from 'ng-uikit-pro-standard';
import { SolubilityService } from 'src/app/_Services/solubility.service';
import { Router } from '@angular/router';
import { MatPaginator } from '@angular/material/paginator';
import { MatDialog } from '@angular/material/dialog';
import { MyfavouritePopupComponent } from '../myfavourite-popup/myfavourite-popup.component';
import { first } from 'rxjs/operators';
import { saveAs } from 'file-saver';

import * as moment from 'moment';
declare global {
  interface Window { // ⚠️ notice that "Window" is capitalized here
    cdw: any;
    perks: any;
  }
}
export interface PeriodicElement {
  // no:string;
  smile: string;
  compoundcode: string;
  compoundname: string;
  batchnumber: string;
  project: string;
  logsvalue: string;
  jobname: string;
  classification: string;
  structure: string;
  version: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  { smile: 'cc-cc1-cc)', compoundcode: 'TG-AAA', compoundname: 'Benzimid', batchnumber: 'TEST', project: 'P-001', logsvalue: '-5.0', jobname: ' job name A', classification: 'high', structure: '-', version: 'Algorithm1' },
  { smile: 'cc-cc1-cc)', compoundcode: 'TG-BBB', compoundname: 'Benzimid', batchnumber: 'TEST', project: 'P-002', logsvalue: '-4.8', jobname: ' job name b', classification: 'low', structure: '-', version: 'Algorithm2' },
  { smile: 'cc-cc1-cc)', compoundcode: 'TG-CCC', compoundname: 'Benzimid', batchnumber: 'TEST', project: 'P-003', logsvalue: '-3.8', jobname: ' job name c', classification: 'medium', structure: '-', version: 'Algorithm2' },
  { smile: 'cc-cc1-cc)', compoundcode: 'TG-BBB', compoundname: 'Benzimid', batchnumber: 'TEST', project: 'P-002', logsvalue: '-4.8', jobname: ' job name b', classification: 'low', structure: '-', version: 'Algorithm2' },

];

@Component({
  selector: 'app-filterby-structure',
  templateUrl: './filterby-structure.component.html',
  styleUrls: ['./filterby-structure.component.css']
})
export class FilterbyStructureComponent implements OnInit {
  // displayedColumns: string[] = ['smile', 'compoundcode', 'project', 'logsvalue', 'jobname', 'classification', 'structure', 'version', 'desired_number'];
  displayedColumns: string[] = ['desired_number', 'structure','compoundcode','batchnumber', 'project', 'version', 'logsvalue', 'classification'];
  //  dataSource = ELEMENT_DATA;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild('filteredreportpaginator', { read: MatPaginator }) filteredreportpaginator: MatPaginator;
  public dataSource: any = new MatTableDataSource([]);
  selected = 'option1';
  myForm: FormGroup;
  myfavForm: FormGroup;
  maxDate = new Date();;
  myHolidayDates
  selectedDate: any;
  mystartDate: any;
  myEndDate: any;
  timeFrame: any;
  current_date: any;
  loading: boolean;
  stlistdate: any;
  projectcode: any;
  projectcompound: any;
  savebtn: boolean;
  downloadbtn: boolean;
  selectedCompound: any
  dysdate: any;
  dyedate: any;
  projectid: any;
  myfavourite: any;
  structuretype: any;
  // typeidselect: any;
  typeidselect: any;
  // selection = new SelectionModel<any>(true, []);
  getsmilelist: any;
  Selectedcompoundid: any;
  typeid: any;
  sendobject: any;
  downloadname: any;
  projectselector: any = [];
  filtertypeid: any;

  constructor(private _formBuilder: FormBuilder,
    public toastrService: ToastService,
    private _solubilityservice: SolubilityService,
    private router: Router,
    public dialog: MatDialog,
  ) { }



  ngOnInit(): void {

    this.savebtn = false;
    this.downloadbtn = false;
    // Form validation
    this.myForm = this._formBuilder.group({
      // structure: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9 ]*$')]],
      structure: ['', []],
      startdate: ['',],
      enddate: ['',],
      structuretypeid: ['',],
      project: ['',],
    });

    window.perks;



    var chemdrawjsAttached = function (chemdraw) {
      // do something
      // console.log('yes', chemdraw);
      window.cdw = chemdraw;
      var isBlank = window.cdw.isBlankStructure();
      // console.log(isBlank);
    };
    var chemdrawjsFailed = function (error) {
      alert(error);
    };


    // get Search dropdown  
    // get Search dropdown  

    this._solubilityservice.getSearch()
      .pipe(first())
      .subscribe((res: any) => {
        this.myfavourite = res?.data;
        console.log(this.myfavourite)
        let filtertype = "Search by Structure"
        const filteredtypearray = this.myfavourite.filter((obj) => {
          return obj.reporttype == filtertype;
        });
        console.log("filteredtypearray-------->" + JSON.stringify(filteredtypearray))

        setTimeout(() => {
          this.filtertypeid = filteredtypearray[0].typeid;
          console.log("this.filtertypeid-------->" + this.filtertypeid)

        }, 1000);

        console.log(this.filtertypeid)
      },
        err => {
        });

    this._solubilityservice.getStructuretype()
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res?.responseMessage)
        this.structuretype = res?.data;
        this.myfavourite = res?.data;
        this.typeidselect = res?.data[0]?.structure_typeid
        this.typeid = res?.data[0]?.structure_typeid
      },
        err => {
        });


    // get Filtered project dropdown  
    this._solubilityservice.getFilteredproject()
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res?.responseMessage)
        this.projectcode = res?.data;
      },
        err => {
        });

    window.perkinelmer.ChemdrawWebManager.attach({
      id: 'chemdrawjs-container',
      callback: chemdrawjsAttached,
      errorCallback: chemdrawjsFailed,
      // licenseUrl: 'http://106.51.19.134:81/18.1.2/js/sample/ChemDraw-JS-License.xml'
      // licenseUrl: 'https://chemdrawqa.aurigene.com/20.0.0/js/sample/ChemDraw-JS-License.xml'
      licenseUrl: 'https://chemdraw.aurigene.com/20.0.0/js/sample/ChemDraw-JS-License.xml?wasm=1'
    });

    this.dateenabled();
    this.datevalidation();
    let sDate = "";
    let eDate = "";
    console.log('users---> ', this.myForm.value)
    if (this.myForm.value.startdate != '' && this.myForm.value.enddate != '') {
      sDate = moment(this.myForm.value.startdate).format('YYYY-MM-DD');
      eDate = moment(this.myForm.value.enddate).format('YYYY-MM-DD');
      this.dysdate = moment(this.myForm.value.startdate).format('YYYY-MM-DD');
      this.dyedate = moment(this.myForm.value.enddate).format('YYYY-MM-DD');
    }
    if (this.myForm.value.startdate == '' || this.myForm.value.enddate == '') {
      var currentDate = moment(new Date());
      var futureMonth = moment(currentDate).add(1, 'M');
      var futureMonthEnd = moment(futureMonth).endOf('month');
      const datde = new Date();
      let dydate = new Date(datde.getFullYear(), datde.getMonth() - 1, datde.getDate())
      sDate = moment(dydate).format('YYYY-MM-DD');
      if (currentDate.date() != futureMonth.date() && futureMonth.isSame(futureMonthEnd.format('YYYY-MM-DD'))) {
        futureMonth = futureMonth.add(1, 'd');
      }
      eDate = moment(currentDate).format('YYYY-MM-DD');
      this.dysdate = sDate;
      this.dyedate = eDate;
    }
    console.log(this.dysdate)
    console.log(this.dyedate)

    if ((this.myForm.value.structure == undefined || this.myForm.value.structure == '' || this.myForm.value.structure == null)) {
      console.log("getfilterWithoutStructure")
      this._solubilityservice.getfilterWithoutStructuredate(this.dysdate, this.dyedate)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.error) {
            this.getsmilelist = res?.data;
            this.dataSource = new MatTableDataSource(this.getsmilelist)
            this.loading = false;
            let array = [];
            for (let item of res?.data) {
              let d = new Date(item?.createdtime);
              item.formattedappointmentDate = moment(d).format('MMMM D, YYYY');
              if (item.logsvalue < -4.5) {
                item.low = true;
              } else if (item.logsvalue >= -3.7 && item.logsvalue <= -4.5) {
                item.medium = true;
              } else {
                item.high = true;
              }
              array.push(item);
            }
            setTimeout(() => {
              this.dataSource.paginator = this.filteredreportpaginator;
              this.filteredreportpaginator.firstPage()
            });
          }
        },
          err => {
          });
    }
  }

  selectedproject(ele) {

  }

  changeType(event) {
    console.log("event=======", event)
    console.log("eventvalue=======", event.value)
    this.typeid = event.value
  }

  getsmilefilter(formData: any, formDirective: FormGroupDirective) {
    console.log('yessss', window.cdw);
    let smileobjs;
    window.cdw.getSMILES(function (result) {
      var smileso = result;
      if (smileso != '') {
        smileobjs = smileso;
        console.log('smiles....', smileso);
      } else {
        console.log('Its empty', smileso);
      }
    });
    console.log('smileobjsvalue', smileobjs);
    console.log(this.myForm.value)

    if (this.myForm.value.startdate && (this.myForm.value.enddate == null || this.myForm.value.enddate == "" || this.myForm.value.enddate == undefined)) {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please select end date', options);
      this.loading = false;
      return;
    }
    
    if (smileobjs !== undefined) {
      console.log('not empty', smileobjs);

      // if (this.myForm.value.startdate == "" || this.myForm.value.startdate == null || this.myForm.value.startdate == undefined
      //   && this.myForm.value.enddate == "" || this.myForm.value.enddate == null || this.myForm.value.startdate == undefined) {
      //   const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      //   this.toastrService.warning('', 'Please select date', options);
      // } else {

        if (this.myForm.value.project == undefined || this.myForm.value.project == '') {
          console.log(' API');
          console.log("getfilterByStructure")
          // let sDate = moment(this.myForm.value.startdate).format('YYYY-MM-DD');
          // let eDate = moment(this.myForm.value.enddate).format('YYYY-MM-DD');
          let sDate = "";
          let eDate = "";
          console.log('users---> ', this.myForm.value)
          if (this.myForm.value.startdate != '' && this.myForm.value.enddate != '' && 
          this.myForm.value.startdate != null && this.myForm.value.enddate != null) {
            sDate = moment(this.myForm.value.startdate).format('YYYY-MM-DD');
            eDate = moment(this.myForm.value.enddate).format('YYYY-MM-DD');
            this.dysdate = moment(this.myForm.value.startdate).format('YYYY-MM-DD');
            this.dyedate = moment(this.myForm.value.enddate).format('YYYY-MM-DD');
          }
          if (this.myForm.value.startdate == '' || this.myForm.value.enddate == '' || 
          this.myForm.value.startdate == null || this.myForm.value.enddate == null) {
            // var currentDate = moment(new Date());
            // var futureMonth = moment(currentDate).add(1, 'M');
            // var futureMonthEnd = moment(futureMonth).endOf('month');
            // const datde = new Date();
            // let dydate = new Date(datde.getFullYear(), datde.getMonth() - 1, datde.getDate())
            // sDate = moment(dydate).format('YYYY-MM-DD');
            // if (currentDate.date() != futureMonth.date() && futureMonth.isSame(futureMonthEnd.format('YYYY-MM-DD'))) {
            //   futureMonth = futureMonth.add(1, 'd');
            // }
            // eDate = moment(currentDate).format('YYYY-MM-DD');
            // this.dysdate = sDate;
            // this.dyedate = eDate;
            this.defaultdate()

          }
          console.log(this.dysdate)
          console.log(this.dyedate)
          this.loading = true;
          this.savebtn = true;
          this.downloadbtn = true;
          const formobject = {
            smile: smileobjs,
            startdate: this.dysdate ,
            enddate: this.dyedate ,
            structure_typeid: this.typeid
          }
          this.sendobject = formobject
          this._solubilityservice.getfilterByStructure(this.sendobject)
            .pipe(first())
            .subscribe((res: any) => {
              if (!res.error) {
                this.getsmilelist = res?.data;
                this.dataSource = new MatTableDataSource(this.getsmilelist)
                if (this.dataSource.data.length == 0) {
                  this.downloadbtn = false;
                  this.savebtn = false;
                }
                this.loading = false;
                let array = [];
                for (let item of res?.data) {
                  let d = new Date(item?.createdtime);
                  item.formattedappointmentDate = moment(d).format('MMMM D, YYYY');
                  if (item.logsvalue < -4.5) {
                    item.low = true;
                  } else if (item.logsvalue >= -3.7 && item.logsvalue <= -4.5) {
                    item.medium = true;
                  } else {
                    item.high = true;
                  }
                  array.push(item);
                }
                setTimeout(() => {
                  this.dataSource.paginator = this.filteredreportpaginator;
                  this.filteredreportpaginator.firstPage()
                });
              }
              else {
                this.loading = false;
                // const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                // this.toastrService.warning('', res?.error, options);
              }
            },
              err => {
                this.loading = false;
                // const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                // this.toastrService.warning('', err?.error, options);
              });
        } else {
          console.log("structurewithproject-------------")
          let sDate = "";
          let eDate = "";
          console.log('users---> ', this.myForm.value)
      
          if (this.myForm.value.startdate != '' && this.myForm.value.enddate != '' && 
          this.myForm.value.startdate != null && this.myForm.value.enddate != null) {
            sDate = moment(this.myForm.value.startdate).format('YYYY-MM-DD');
            eDate = moment(this.myForm.value.enddate).format('YYYY-MM-DD');
            this.dysdate = moment(this.myForm.value.startdate).format('YYYY-MM-DD');
            this.dyedate = moment(this.myForm.value.enddate).format('YYYY-MM-DD');
          }
          if (this.myForm.value.startdate == '' || this.myForm.value.enddate == '' || this.myForm.value.startdate == null || this.myForm.value.enddate == null) {
            this.defaultdate()

          }
          console.log(this.dysdate)
          console.log(this.dyedate)

          this.loading = true;
          this.savebtn = true;
          this.downloadbtn = true;
          const formobject = {
            smile: smileobjs,
            startdate:  this.dysdate,
            enddate:  this.dyedate,
            structure_typeid: this.typeid,
            projectid: this.myForm.value.project,
          }
          this.sendobject = formobject
          this._solubilityservice.getfilterByStructurewithproject(formobject)
            .pipe(first())
            .subscribe((res: any) => {
              if (!res.error) {
                this.getsmilelist = res?.data;
                this.dataSource = new MatTableDataSource(this.getsmilelist)
                if (this.dataSource.data.length == 0) {
                  this.downloadbtn = false;
                  this.savebtn = false;
                }
                this.loading = false;
                let array = [];
                for (let item of res?.data) {
                  let d = new Date(item?.createdtime);

                  item.formattedappointmentDate = moment(d).format('MMMM D, YYYY');
                  if (item.logsvalue < -4.5) {
                    item.low = true;
                  } else if (item.logsvalue >= -3.7 && item.logsvalue <= -4.5) {
                    item.medium = true;
                  } else {
                    item.high = true;
                  }
                  array.push(item);
                }
                setTimeout(() => {
                  this.dataSource.paginator = this.filteredreportpaginator;
                  this.filteredreportpaginator.firstPage()

                });
              } else {
                this.loading = false;
                // const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                // this.toastrService.warning('', res?.error, options);
              }
            },
              err => {
                this.loading = false;
                // const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                // this.toastrService.warning('', err?.error, options);
              }); 
        }
    } else {
      console.log(' empty', smileobjs);

      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please draw structure', options);
    }
  }

  defaultdate() {
    let sDate = "";
    let eDate = "";
    var currentDate = moment(new Date());
    var futureMonth = moment(currentDate).add(1, 'M');
    var futureMonthEnd = moment(futureMonth).endOf('month');
    const datde = new Date();
    let dydate = new Date(datde.getFullYear(), datde.getMonth() - 1, datde.getDate())
    sDate = moment(dydate).format('YYYY-MM-DD');
    console.log(dydate)
    console.log(sDate)
    if (currentDate.date() != futureMonth.date() && futureMonth.isSame(futureMonthEnd.format('YYYY-MM-DD'))) {
      futureMonth = futureMonth.add(1, 'd');
    }
    eDate = moment(currentDate).format('YYYY-MM-DD');
    this.dysdate = sDate;
    this.dyedate = eDate;
  }

  downloadReport() {
    this.downloadname = "Structure report";
    if (this.sendobject.startdate && this.sendobject.enddate && this.sendobject.smile == undefined) {
      // startdate & enddate
      console.log("downloadonlydate")
      this._solubilityservice.downloadWithoutstructure(this.sendobject)
        .pipe(first()).subscribe((res: any) => {
          if (!res.error) {
            this.loading = false;
            console.log(res)
            const data: Blob = new Blob([res], {
              type: 'text/csv'
            });
            saveAs(data, this.downloadname + ".csv");
          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });
    }


    if (this.sendobject.smile && this.sendobject.projectid == undefined) {
      console.log("downloadstructurewithdate")
      // this.loading = true;
      // jobname& startdate & enddate
      this._solubilityservice.downloadWithstructure(this.sendobject)
        .pipe(first()).subscribe((res: any) => {
          if (!res.error) {
            this.loading = false;
            console.log(res)
            const data: Blob = new Blob([res], {
              type: 'text/csv'
            });
            saveAs(data, this.downloadname + ".csv");
          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });
    }

    if (this.sendobject.smile && this.sendobject.projectid) {
      this.downloadname = "structure report";
      console.log("downloadstructurewithpro")
      this._solubilityservice.downloadWithstructureprosmile(this.sendobject)
        .pipe(first()).subscribe((res: any) => {
          if (!res.error) {
            this.loading = false;
            console.log(res)
            const data: Blob = new Blob([res], {
              type: 'text/csv'
            });
            saveAs(data, this.downloadname + ".csv");
          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });
    }
  }

  datevalidation() {
    if (this.myForm.value.startdate == "" || this.myForm.value.startdate == null || this.myForm.value.startdate == undefined) {
      this.myForm.controls.enddate.disable();
      return;
    }
  }

  dateenabled() {
    if (this.myForm.value.startdate) {
      this.myForm.controls.enddate.reset();
      this.myForm.controls.enddate.enable();
      const sdate = this.myForm.value.startdate;
      this.myEndDate = sdate.toISOString();
    }
  }

  resetclk() {
    // this.myForm.controls.startdate.reset();
    this.myForm.reset()
    this.dateenabled();
    this.datevalidation();
    window.cdw.clear();
    this.defaultdate()
    // get Search dropdown  
    this._solubilityservice.getStructuretype()
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res?.responseMessage)
        this.structuretype = res?.data;
        this.myfavourite = res?.data;
        this.typeidselect = res?.data[0]?.structure_typeid
        this.typeid = res?.data[0]?.structure_typeid
      },
        err => {
        });
    this.downloadbtn = false;
    this.savebtn = false;

    // if ((this.myForm.value.structure == undefined || this.myForm.value.structure == '' || this.myForm.value.structure == null)) {
    console.log("getfilterWithoutStructure")
    this._solubilityservice.getfilterWithoutStructuredate(this.dysdate, this.dyedate)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.error) {
          this.getsmilelist = res?.data;
          this.dataSource = new MatTableDataSource(this.getsmilelist)
          this.loading = false;
          let array = [];
          for (let item of res?.data) {
            let d = new Date(item?.createdtime);
            item.formattedappointmentDate = moment(d).format('MMMM D, YYYY');
            if (item.logsvalue < -4.5) {
              item.low = true;
            } else if (item.logsvalue >= -3.7 && item.logsvalue <= -4.5) {
              item.medium = true;
            } else {
              item.high = true;
            }
            array.push(item);
          }

          // this.dataSource.paginator = this.filteredreportpaginator;
          // this.dataSource.paginator.pageSize=0;
          setTimeout(() => {
            this.dataSource.paginator = this.filteredreportpaginator;
            this.filteredreportpaginator.firstPage()
            this.dataSource.paginator.pageSize = 0;

          });
        }
      },
        err => {
        });

    // }

  }
  openDialog() {
    console.log(this.sendobject)
    let pageData = {
      ...this.sendobject,
      searchtypeId: this.filtertypeid
    }
    // console.log(pageData)
    const dialogRef = this.dialog.open(MyfavouritePopupComponent, {
      width: '28%',
      data: pageData
    });
  }
  img: any;
  imgclk(element) {
    console.log(element)
    this.img = element
  }
}
