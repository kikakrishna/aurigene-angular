import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { FormControl, FormGroup, NgForm, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { FormGroupDirective } from '@angular/forms';
import { first } from 'rxjs/operators';
import { ToastService } from 'ng-uikit-pro-standard';
import { SolubilityService } from 'src/app/_Services/solubility.service';
import { ChartConfiguration, ChartOptions, ChartType } from "chart.js";
import { SelectionModel } from '@angular/cdk/collections';
import * as moment from 'moment';
import { MatDialog } from '@angular/material/dialog';


@Component({
  selector: 'app-comparison-chart',
  templateUrl: './comparison-chart.component.html',
  styleUrls: ['./comparison-chart.component.css']
})
export class ComparisonChartComponent implements OnInit {
  displayedColumns: string[] = ['jobname', 'createdtime', 'Action'];
  // datasource = ELEMENT_DATA;
  @ViewChild('joblistpaginator', { read: MatPaginator }) joblistpaginator: MatPaginator;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  public dataSource: any = new MatTableDataSource([]);
  job_id: any;
  addressmodel: any;
  loading: boolean;
  req: any;
  comparisonform: FormGroup;
  btnAction: boolean;
  testitatus: any;
  jobname: any;
  createdtime: any;
  searchinput: any;
  listdata: boolean;
  filterData: boolean;
  applyfilterData: boolean = false;

  // public lineChartLabels = ['2000', '2001', '2002', '2003', '2004', '2005'];
  public lineChartLabels = ['S1', 'S2', 'S3', 'S4','S5' ];
  public lineChartType = 'line';
  public lineChartLegend = true;
  public lineChartOptions = {
    elements: {
      line: {
        tension: 0.0
      }
    }
  }

  public lineChartData = [
    // { data: [2, 2.5, 2, 2.2, 2, 2.5], label: 'Series A', borderColor: '#20c997', pointBackgroundColor: '#fff', pointBorderColor: '#20c997', fill: 'transparent' },
    // { data: [1.5, 2, 1.4, 2, 1.5, 2], label: 'Series B', borderColor: '#17a2b8', pointBackgroundColor: '#fff', pointBorderColor: '#17a2b8', fill: 'transparent' }
  

    { data: [1,2,3,4,5], label: 'A1', borderColor: '#17a2b8', pointBackgroundColor: '#fff', pointBorderColor: '#17a2b8', fill: 'transparent' },
    { data: [0,0,0,4,6], label: 'A2', borderColor: '#f0dc07', pointBackgroundColor: '#fff', pointBorderColor: '#17a2b8', fill: 'transparent' },
    //{ data: [1,2], label: 'C2=CC=CC=C2', borderColor: '#0f0f0a', pointBackgroundColor: '#fff', pointBorderColor: '#0f0f0', fill: 'transparent' },
    //{ data: [2.4,2.9 ], label: 'C2=CC=', borderColor: '#b81667', pointBackgroundColor: '#fff', pointBorderColor: '#17a2b8', fill: 'transparent' },
    // { data: [ 0.2, 0.4, 0.6, 0.8, ], label: 'algorithm 4"', borderColor: '#b81667', pointBackgroundColor: '#fff', pointBorderColor: '#17a2b8', fill: 'transparent' },

  ];

  constructor(
    private _formBuilder: FormBuilder,
    public toastrService: ToastService,
    private _solubilityservice: SolubilityService,
    private router: Router,
  ) { }

  ngOnInit(): void {
    this.loading = true;

    // Form validation
    this.comparisonform = this._formBuilder.group({
      compound: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9 ]*$')]],
      startdate: ['', [Validators.required]],
      enddate: ['', [Validators.required]],

    });

    this._solubilityservice.getjob()
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        if (!res.isError) {
          this.loading = false;
          let array = [];
          this.jobname = res?.data
          for (let item of res?.data) {
            let d = new Date(item?.createdtime);
            item.createdtime = moment(d).format('MMMM D, YYYY');
            array.push(item);
          }
          setTimeout(() => {
            this.dataSource.paginator = this.joblistpaginator;
          });
          this.dataSource = new MatTableDataSource(this.jobname);

        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }


  filterString;
  Fsearchstring: string;
  applyFilter2() {
    this.loading = true;
    const filterValue = this.searchinput;
    let searchstring = filterValue.trim()

    if (searchstring) {
      this.applyfilterData = true;
    } else
      this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.filteredData.length === 0) {
      this.filterData = true;
    } else {
      this.filterData = false;
    }
    this.Fsearchstring = searchstring;
    console.log("aaaa---" + searchstring)

    // var req={
    //   "search":searchstring
    // }

    this._solubilityservice.joblistfilter(this.Fsearchstring)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          console.log(res)
          let array = [];
          this.loading = false;
          for (let item of res?.data) {
            let d = new Date(item?.createdtime);
            item.createdtime = moment(d).format('MMMM D, YYYY');
            array.push(item);
          }
          this.dataSource = new MatTableDataSource(res?.data);
          if (this.dataSource.data.length === 0) {
            this.listdata = true;
          }
          else {
            this.listdata = false;
          }
          setTimeout(() => {
            this.dataSource.paginator = this.joblistpaginator;
          });
        }
        else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
          this.loading = false;
        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
          this.loading = false;
        });
  }
  runView(element) {
    console.log(element.isLocusjob)
    if (element.isLocusjob == false) {
      this.router.navigate(['/solubilityrun/' + element.job_id], { state: { locus: element.isLocusjob } })
    }
    else {
      this.router.navigate(['/solubilityrunlocus/' + element.job_id], { state: { locus: element.isLocusjob } })
    }
  }


  selectedcompound(event) {
  }



}      