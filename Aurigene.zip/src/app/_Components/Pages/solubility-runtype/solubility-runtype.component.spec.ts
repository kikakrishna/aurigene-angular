import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SolubilityRuntypeComponent } from './solubility-runtype.component';

describe('SolubilityRuntypeComponent', () => {
  let component: SolubilityRuntypeComponent;
  let fixture: ComponentFixture<SolubilityRuntypeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SolubilityRuntypeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SolubilityRuntypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
