import { RouterModule } from "@angular/router";
import {MyFavouriteComponent } from "./my-favourite.component"
export const MyFavouriteRoutes: RouterModule [] = [
    {
        path: '',
        component: MyFavouriteComponent
    }
]