import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { JoblistComponent } from './joblist.component';
import { JoblistRoutes } from './joblist.routes';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatTableModule } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule } from '@angular/material/paginator';
import { ChartsModule } from'ng2-charts'; 

@NgModule({
  declarations: [JoblistComponent ],
  imports: [
    CommonModule,
    RouterModule.forChild(JoblistRoutes),
    MatCardModule,
    MatButtonModule,
    MatTableModule,
    MatFormFieldModule,
    MatInputModule,
    FormsModule, 
    ReactiveFormsModule,
    MatPaginatorModule,
    ChartsModule
  ]
})
export class JoblistModule { }
