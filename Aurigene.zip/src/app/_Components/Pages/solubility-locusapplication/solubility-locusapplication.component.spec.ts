import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SolubilityLocusapplicationComponent } from './solubility-locusapplication.component';

describe('SolubilityLocusapplicationComponent', () => {
  let component: SolubilityLocusapplicationComponent;
  let fixture: ComponentFixture<SolubilityLocusapplicationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SolubilityLocusapplicationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SolubilityLocusapplicationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
