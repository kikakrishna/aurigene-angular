import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { FormControl, FormGroup, NgForm, FormBuilder, Validators } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { SelectionModel } from '@angular/cdk/collections';
import { FormGroupDirective } from '@angular/forms';
import { ToastService } from 'ng-uikit-pro-standard';
import { SolubilityService } from 'src/app/_Services/solubility.service';
import { Router } from '@angular/router';
import { MatPaginator } from '@angular/material/paginator';
import { first } from 'rxjs/operators';

export interface PeriodicElement {
  // no:string;
  smile: string;
  compoundcode: string;
  compoundname: string;
  batchnumber: string;
  project: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  { smile: 'cc-cc1-cc)-no2=c12', compoundcode: 'TG-AAA-7001', compoundname: 'Benzimidazolenenzamide', batchnumber: 'TEST-BAT-O98', project: 'P-001' },
  { smile: 'cc-cc1-cc)-no2=c12', compoundcode: 'TG-AAA-7001', compoundname: 'Benzimidazolenenzamide', batchnumber: 'TEST-BAT-O98', project: 'P-001' },
  { smile: 'cc-cc1-cc)-no2=c12', compoundcode: 'TG-AAA-7003', compoundname: 'Benzimidazolenenzamide', batchnumber: 'TEST-BAT-O98', project: 'P-001' }
];


@Component({
  selector: 'app-solubility-locusapplication',
  templateUrl: './solubility-locusapplication.component.html',
  styleUrls: ['./solubility-locusapplication.component.css']
})
export class SolubilityLocusapplicationComponent implements OnInit {
  displayedColumns: string[] = ['select','structure', 'smile', 'compoundcode', 'compoundname', 'batchnumber', 'project'];
  // dataSource = ELEMENT_DATA;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  public dataSource: any = new MatTableDataSource([]);
  btnAction: boolean;
  testitatus: any;
  imgfileRes: any;
  myForm: FormGroup;
  loading: boolean;
  projectname: any;
  projectcode: any;
  projectcompound: any;
  projectId: any;
  projectCode: any;
  selectedCompound: any;
  getsmilelist: any;
  selectedTableCompound: any = [];
  projectName: any;
  jobid: any;
  jobName: any;
  algorithm: any;
  resprojectId:any;

  selection = new SelectionModel<any>(true, []);
  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.filteredData.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  toggleAllRows() {
    if (this.isAllSelected()) {
      this.selection.clear();
      return;
    }
    this.selection.select(...this.dataSource.data);
  }

  /** The label for the checkbox on the passed row */
  checkboxLabel(row?): string {
    if (!row) {
      return `${this.isAllSelected() ? 'deselect' : 'select'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${+ 1}`;
  }


  constructor(private _formBuilder: FormBuilder,
    public toastrService: ToastService,
    private _solubilityservice: SolubilityService,
    private router: Router,
  ) { }

  ngOnInit(): void {

    // getproject dropdown  
    // this.loading = true;
    this._solubilityservice.getproject()
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res?.responseMessage)
        this.projectcode = res?.data.ProjectList;
      },
        err => {
        });

this.Getalgorithms()
    // Form validation
    this.myForm = this._formBuilder.group({
      // jobname: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9 ]*$')]],
      project: ['', [Validators.required]],
      compound: ['', [Validators.required]],
      Solubilityrun: ['', [Validators.required]],

    });

  }

  resetForm() {
    this.myForm.reset();
    // this.projectcode = [];
    this.projectcompound =[];

  }

  selectedproject(event) {
    this.projectId = event.value;
    var CompoundList = event.value;
    console.log('product', CompoundList);
    this._solubilityservice.getcompound(CompoundList)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.error) {
          this.projectcompound = res?.data.CompoundList;
          var tempview = []
          this.projectcompound.map((item, i) => {
            tempview.push({
              componentID: item,
              isChecked: false,
              componentIndex: i
            })
          })
          this.projectcompound = tempview
          if (tempview.length == 0) {
            this.projectcompound = tempview;
          }
          console.log('cpmponddetails---' + this.projectcompound);
        } else {
          this.projectcompound = tempview;
        }
        this.selectedCompound = []

        //  this.projectcompound = res?.data.CompoundList;
        // if(this.projectcompound.length > 0) {
        //   this.selectedCompound  = this.projectcompound;
        // }
        //  console.log('cpmponddetails---' + this.projectcompound);
      },
        err => {
        });
  }

  Getalgorithms(){
    this._solubilityservice.GetAlgorithm()
    .pipe(first())
    .subscribe((res: any) => {
      console.log(res?.responseMessage)
      this.algorithm = res?.responseMessage;
    },
      err => {
      });
  }
  
  checkBoxClick(event) {
    console.log(event)
    let temp;
    temp = this.projectcompound.map((pro) => {
      if (event.componentIndex === pro.componentIndex) {
        return { ...pro, isChecked: !pro.isChecked };
      }
      return pro;
    });
    console.log(temp)
    this.projectcompound = temp
    console.log(this.projectcompound)
    // console.log("viewarrayyyy----->" + JSON.stringify(this.projectcompound))
  }

  getsmilefilter(formData: any, formDirective: FormGroupDirective) {
    let filterarray = []
    this.selection.clear();
    console.log(this.myForm.valid)
    if(this.myForm.value.project != ''&& this.myForm.value.compound != '' && this.myForm.value.Solubilityrun != ''){
     // this.projectName = this.myForm.value.jobname
      console.log("projectcompound------------>2" + this.projectcompound)
      this.projectcompound.map((data) => {
        if (data.isChecked == true) {
          filterarray.push(data.componentID)
        }
      })
      console.log("arraychech-------->" + JSON.stringify(filterarray))
      this.loading = true;
      this._solubilityservice.getstructure(this.projectId, filterarray.toString())
        .pipe(first())
        .subscribe((res: any) => {
          this.resprojectId = res?.data.projectId;
          this.getsmilelist = res?.data.Structure;
          this.dataSource = new MatTableDataSource(this.getsmilelist)
          console.log("ghstghsrthr" + this.getsmilelist)
          this.loading = false;
          // this.myForm.reset();
          // formDirective.resetForm();
        },
          err => {
          });
    } else {
      this.loading = false;
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('','Enter all the Mandatory Fields', options); 
    }
  }


  

  submitSolubility() {
    this.loading = true;
    console.log(this.selection.selected)
    console.log(this.jobName)
   // this.projectName = this.jobName;
    //console.log(this.projectName)
    // if(this.projectName == '' || this.projectName == undefined) {
    //   this.loading = false;
    //   const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    //   this.toastrService.warning('','Please select the job name', options); 
    //   return
    // }
    if(this.selection.selected.length == 0){
      this.loading = false;
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('','Please select the smiles', options); 
      return
    }
    if(this.selection.selected.length > 0) {
      this.selection.selected.forEach(x => {
        // console.log(x.structure)
        this.selectedTableCompound.push(x.smile)
      })
      console.log(this.selectedTableCompound)
      let formobject = {
        "projectId": this.resprojectId,
        "Structure": this.selection.selected,
        "algorithm_id" : this.myForm.value.Solubilityrun
      }
      console.log(formobject)
      this._solubilityservice.locusjob(formobject)
        .pipe(first())
        .subscribe((res: any) => {
          console.log(res)
          if (!res.error) {
            // formDirective.resetForm();
            this.myForm.reset();
            console.log(res?.data[0]?.job_jobid);
            this.jobid = res?.data[0]?.job_jobid
            this.loading = false;
           // this.projectName = ''
            const options = { opacity: 1, timeOut: 6000, tapToDismiss: true };
            this.toastrService.success('', res.responseMessage, options);
            if(this.jobid) {
              this.router.navigate([`/solubilityrunlocus/${res.data[0]?.job_jobid}/`]);
            }
          }
          else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });
      } else {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('','Please select the smiles & job name', options); 
      }
  }

  img:any;
  imgclk(element){
    console.log(element)
    this.img = element
  }
}
