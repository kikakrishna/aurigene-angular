import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { FormControl, FormGroup, NgForm, FormBuilder, Validators } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { ActivatedRoute } from "@angular/router";
import { SelectionModel } from '@angular/cdk/collections';
import { FormGroupDirective } from '@angular/forms';
import { ToastService } from 'ng-uikit-pro-standard';
import { SolubilityService } from 'src/app/_Services/solubility.service';
import { Router } from '@angular/router';
import { MatPaginator } from '@angular/material/paginator';
import { MatDialog } from '@angular/material/dialog';
import { MyfavouritePopupComponent } from '../myfavourite-popup/myfavourite-popup.component';
import { first } from 'rxjs/operators';
import * as moment from 'moment';
import { saveAs } from 'file-saver';



export interface PeriodicElement {
  // no:string;
  smile: string;
  compoundcode: string;
  compoundname: string;
  batchnumber: string;
  project: string;
  logsvalue: string;
  jobname: string;
  classification: string;
  structure: string;
  version: string;

}

const ELEMENT_DATA: PeriodicElement[] = [
  { smile: 'cc-cc1-cc)', compoundcode: 'TG-AAA', compoundname: 'Benzimid', batchnumber: 'TEST', project: 'P-001', logsvalue: '-5.0', jobname: ' job name A', classification: 'high', structure: '-', version: 'Algorithm1' },
  { smile: 'cc-cc1-cc)', compoundcode: 'TG-BBB', compoundname: 'Benzimid', batchnumber: 'TEST', project: 'P-002', logsvalue: '-4.8', jobname: ' job name b', classification: 'low', structure: '-', version: 'Algorithm2' },
  { smile: 'cc-cc1-cc)', compoundcode: 'TG-CCC', compoundname: 'Benzimid', batchnumber: 'TEST', project: 'P-003', logsvalue: '-3.8', jobname: ' job name c', classification: 'medium', structure: '-', version: 'Algorithm2' },
  { smile: 'cc-cc1-cc)', compoundcode: 'TG-BBB', compoundname: 'Benzimid', batchnumber: 'TEST', project: 'P-002', logsvalue: '-4.8', jobname: ' job name b', classification: 'low', structure: '-', version: 'Algorithm2' },

];


@Component({
  selector: 'app-favourite-result',
  templateUrl: './favourite-result.component.html',
  styleUrls: ['./favourite-result.component.css']
})
export class FavouriteResultComponent implements OnInit {

  // displayedColumns: string[] = ['smile', 'compoundcode', 'project', 'logsvalue', 'jobname', 'classification', 'structure', 'version', 'desired_number'];
  displayedColumns: string[] = ['desired_number', 'structure','compoundcode','batchnumber', 'project', 'version','logsvalue', 'classification'];
  // dataSource = ELEMENT_DATA;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild('filteredreportpaginator', { read: MatPaginator }) filteredreportpaginator: MatPaginator;
  public dataSource: any = new MatTableDataSource([]);
  selected = 'option1';
  myForm: FormGroup;
  myfavForm: FormGroup;
  maxDate = new Date();

  myHolidayDates;
  selectedDate: any;
  mystartDate: any;
  myEndDate: any;
  downloadname: any;
  timeFrame: any;

  current_date: any;
  loading: boolean;
  stlistdate: any;
  projectcode: any;
  projectcompound: any;

  selectedCompound: any
  dysdate: any;
  dyedate: any;
  projectid: any;
  pageSize: any;
  myfavourite: any;
  ssdate: any;
  eedate: any;
  filtertypeid: any;
  // selection = new SelectionModel<any>(true, []);
  getsmilelist: any;
  Selectedcompoundid: any;
  downloadbtn: boolean;
  savebtn: boolean;

  typeid: any;
  data: any;
  sendobject: any;
  selectedstartdate: any;
  selectedenddate: any;
  arrayx: any = [];
  projectselector: any = [];

  constructor(private _formBuilder: FormBuilder,
    public toastrService: ToastService,
    private _solubilityservice: SolubilityService,
    private router: Router,
    public dialog: MatDialog,
    public _activatedRoute: ActivatedRoute,
  ) { }

  ngOnInit(): void {
    // this.downloadbtn = false
    // this.savebtn = false
    this.projectselector = []
    this.arrayx = []
    // Form validation

    this.data = history.state.inputparams;
    this._activatedRoute.paramMap.subscribe(params => {
      if (params?.get('typeid')) {
        this.typeid = params?.get('typeid');
      }
    })


    console.log("inputparams" + JSON.stringify(this.data.inputparams))
    console.log("typeid" + this.typeid)




    this.myForm = this._formBuilder.group({
      // jobname: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9 ]*$')]],
      project: ['', []],
      compound: ['', []],
      startdate: ['',],
      enddate: ['',],

    });


    // get Filtered project dropdown  
    // this._solubilityservice.getFilteredproject()
    //   .pipe(first())
    //   .subscribe((res: any) => {
    //     console.log(res?.responseMessage)
    //     this.projectcode = res?.data;
    //   },
    //     err => {
    //     });

    // get Search dropdown
    // this._solubilityservice.getSearch()
    //   .pipe(first())
    //   .subscribe((res: any) => {
    //     this.myfavourite = res?.data;
    //     let filtertype = "SearchbyProject"
    //     const filteredtypearray = this.myfavourite.filter((obj) => {
    //       return obj.reporttype === filtertype;
    //     });
    //     this.filtertypeid = filteredtypearray[0].typeid;
    //   },
    //     err => {
    //     });

    // this.dateenabled();
    // this.datevalidation();


    if (this.data.inputparams) {


      this.downloadbtn = true;
      this.savebtn = false;


      console.log("inputparamrun")


      if (this.data.inputparams.projectid && this.data.inputparams.compoundcode == undefined && this.data.inputparams.smile == undefined) {
        console.log("projectid")

        const arr = this.data.inputparams.projectid.split(',');

        for (const element of arr) {

          this.arrayx.push(parseInt(element))
        }
        // this.projectselector = this.arrayx
        // this.selectedstartdate = this.inputparam.startdate
        // this.selectedenddate = this.inputparam.enddate
        // this.selectedstartdate = this.inputparam.startdate
        this._solubilityservice.getfilterReportWithProjectId(this.arrayx, this.data.inputparams.startdate, this.data.inputparams.enddate)
          .pipe(first())
          .subscribe((res: any) => {
            if (!res.error) {
              this.loading = false;
              this.downloadname = "project & Compound report";

              this.getsmilelist = res?.data;
              this.dataSource = new MatTableDataSource(this.getsmilelist)
              // console.log("ghstghsrthr" + this.getsmilelist)

              if (this.dataSource.data.length == 0) {
                this.downloadbtn = false;
                this.savebtn = false;

              }


              let array = [];
              for (let item of res?.data) {
                let d = new Date(item?.createdtime);
                // console.log("srfdrgrdggdsg" + JSON.stringify(item));
                item.formattedappointmentDate = moment(d).format('MMMM D, YYYY');
                if (item.logsvalue < -4.5) {
                  item.low = true;
                } else if (item.logsvalue >= -3.7 && item.logsvalue <= -4.5) {
                  item.medium = true;
                } else {
                  item.high = true;
                }
                array.push(item);
              }

              setTimeout(() => {
                this.dataSource.paginator = this.filteredreportpaginator;
                this.filteredreportpaginator.firstPage()
              });



            }
          },
            err => {
            });
      }
      if (this.data.inputparams.startdate && this.data.inputparams.enddate && this.data.inputparams.smile == undefined &&  this.data.inputparams.projectid == undefined && this.data.inputparams.jobname == undefined) {
        // this.selectedstartdate = this.inputparam.startdate
        // this.selectedenddate = this.inputparam.enddate
        // if( this.data.inputparams.smile == undefined){
        //   console.log("startdate&enddate-----smile")

        // }
        console.log("startdate&enddate")

        this._solubilityservice.getfilterReportWithoutProjectIdCompoundid(this.data.inputparams.startdate, this.data.inputparams.enddate)
          .pipe(first())
          .subscribe((res: any) => {
            if (!res.error) {
              this.getsmilelist = res?.data;
              this.downloadname = "project & Compound report";

              console.log('hdjfvdhbf' + this.downloadname)
              this.dataSource = new MatTableDataSource(this.getsmilelist)
              // console.log("ghstghsrthr" + this.getsmilelist)
              this.loading = false;
              if (this.dataSource.data.length == 0) {
                this.downloadbtn = false;
                this.savebtn = false;

              }
              let array = [];
              for (let item of res?.data) {
                let d = new Date(item?.createdtime);
                // console.log("srfdrgrdggdsg" + JSON.stringify(item));
                item.formattedappointmentDate = moment(d).format('MMMM D, YYYY');
                if (item.logsvalue < -4.5) {
                  item.low = true;
                } else if (item.logsvalue >= -3.7 && item.logsvalue <= -4.5) {
                  item.medium = true;
                } else {
                  item.high = true;
                }
                array.push(item);
              }
              setTimeout(() => {
                this.dataSource.paginator = this.filteredreportpaginator;
                this.filteredreportpaginator.firstPage()
              });
              // this.myForm.reset();
              // formDirective.resetForm();
            }
          },
            err => {
            });
      }
      if (this.data.inputparams.compoundcode) {
        console.log("compoundcode")

        const parr = this.data.inputparams.projectid.split(',');

        for (const element of parr) {

          this.arrayx.push(parseInt(element))
        }
        // this.projectselector = this.arrayx

        var selectedpid = this.arrayx

        // this._solubilityservice.getFilteredcompound(selectedpid)
        //   .pipe(first())
        //   .subscribe((res: any) => {
        //     if (!res.error) {
        //       this.projectcompound = res?.data;
        //       console.log(this.projectcompound);
        //     } else {

        //     }

        //   },
        //     err => {
        //     });


        this.selectedCompound = []
        var array = this.data.inputparams.compoundcode.split(",");
        console.log(array)

        // this.selectedCompound = array

        // this.selectedstartdate = this.inputparam.startdate
        // this.selectedenddate = this.inputparam.enddate


        this._solubilityservice.getfilterReport(this.arrayx, array, this.data.inputparams.startdate, this.data.inputparams.enddate)
          .pipe(first())
          .subscribe((res: any) => {
            if (!res.error) {
              this.getsmilelist = res?.data;
              this.downloadname = "project & Compound report";

              this.dataSource = new MatTableDataSource(this.getsmilelist)
              console.log("ghstghsrthr" + this.getsmilelist)
              this.loading = false;

              if (this.dataSource.data.length == 0) {
                this.downloadbtn = false;
                this.savebtn = false;

              }

              let array = [];
              for (let item of res?.data) {
                let d = new Date(item?.createdtime);
                // console.log("srfdrgrdggdsg" + JSON.stringify(item));
                item.formattedappointmentDate = moment(d).format('MMMM D, YYYY');
                if (item.logsvalue < -4.5) {
                  item.low = true;
                } else if (item.logsvalue >= -3.7 && item.logsvalue <= -4.5) {
                  item.medium = true;
                } else {
                  item.high = true;
                }
                array.push(item);
              }
              setTimeout(() => {
                this.dataSource.paginator = this.filteredreportpaginator;
                this.filteredreportpaginator.firstPage()

              });
              // this.myForm.reset();
              // formDirective.resetForm();
            }
          },
            err => {
            });
      }
      if (this.data.inputparams.jobname) {
        console.log("jobname")


        // this.selectedjobname = this.inputparam.jobname
        // this.selectedenddate = this.inputparam.enddate
        // this.selectedstartdate = this.inputparam.startdate
        this._solubilityservice.getfilterByJobname(this.data.inputparams.jobname, this.data.inputparams.startdate, this.data.inputparams.enddate)
          .pipe(first())
          .subscribe((res: any) => {
            if (!res.error) {
              this.loading = false;
              this.downloadname = "Jobname report";

              this.getsmilelist = res?.data;
              this.dataSource = new MatTableDataSource(this.getsmilelist)
              // console.log("ghstghsrthr" + this.getsmilelist)
              if (this.dataSource.data.length == 0) {
                this.downloadbtn = false;
                this.savebtn = false

              }
              let array = [];
              for (let item of res?.data) {
                let d = new Date(item?.createdtime);
                // console.log("srfdrgrdggdsg" + JSON.stringify(item));
                item.formattedappointmentDate = moment(d).format('MMMM D, YYYY');
                if (item.logsvalue < -4.5) {
                  item.low = true;
                } else if (item.logsvalue >= -3.7 && item.logsvalue <= -4.5) {
                  item.medium = true;
                } else {
                  item.high = true;
                }
                array.push(item);
              }

              setTimeout(() => {
                this.dataSource.paginator = this.filteredreportpaginator;
                this.filteredreportpaginator.firstPage()

              });


 

            }
          },
            err => {
            });
      }

      if (this.data.inputparams.smile && this.data.inputparams.projectid == undefined) {
        console.log("smileonly")
        console.log("projectid------------"+this.data.inputparams.projectid)

        const formobject = {
          smile: this.data.inputparams.smile,
          startdate: this.data.inputparams.startdate,
          enddate: this.data.inputparams.enddate,
          structure_typeid: this.data.inputparams.structuretype
        }
        this.sendobject = formobject

        this._solubilityservice.getfilterByStructure(this.sendobject)
          .pipe(first())
          .subscribe((res: any) => {
            if (!res.error) {
              this.getsmilelist = res?.data;
              this.dataSource = new MatTableDataSource(this.getsmilelist)
              if (this.dataSource.data.length == 0) {
                this.downloadbtn = false;
                this.savebtn = false;

              }
              this.loading = false;
              let array = [];
              for (let item of res?.data) {
                let d = new Date(item?.createdtime);

                item.formattedappointmentDate = moment(d).format('MMMM D, YYYY');
                if (item.logsvalue < -4.5) {
                  item.low = true;
                } else if (item.logsvalue >= -3.7 && item.logsvalue <= -4.5) {
                  item.medium = true;
                } else {
                  item.high = true;
                }
                array.push(item);
              }
              setTimeout(() => {
                this.dataSource.paginator = this.filteredreportpaginator;
                this.filteredreportpaginator.firstPage()

              });
              // this.myForm.reset();
              // formDirective.resetForm();
            }
          },
            err => {
            });
      }
      if (this.data.inputparams.smile && this.data.inputparams.projectid) {
        console.log("smile&pro")
        console.log(this.data.inputparams.projectid)
        this.downloadname = "structure report";
        const formobject = {
          smile: this.data.inputparams.smile,
          startdate: this.data.inputparams.startdate,
          enddate: this.data.inputparams.enddate,
          projectid: this.data.inputparams.projectid,
          structure_typeid: this.data.inputparams.structuretype
        }
        this.sendobject = formobject
        this._solubilityservice.getfilterByStructurewithproject(this.sendobject)
          .pipe(first())
          .subscribe((res: any) => {
            if (!res.error) {
              this.getsmilelist = res?.data;
              this.dataSource = new MatTableDataSource(this.getsmilelist)
              if (this.dataSource.data.length == 0) {
                this.downloadbtn = false;
                this.savebtn = false;

              }
              this.loading = false;
              let array = [];
              for (let item of res?.data) {
                let d = new Date(item?.createdtime);

                item.formattedappointmentDate = moment(d).format('MMMM D, YYYY');
                if (item.logsvalue < -4.5) {
                  item.low = true;
                } else if (item.logsvalue >= -3.7 && item.logsvalue <= -4.5) {
                  item.medium = true;
                } else {
                  item.high = true;
                }
                array.push(item);
              }
              setTimeout(() => {
                this.dataSource.paginator = this.filteredreportpaginator;
                this.filteredreportpaginator.firstPage()

              });
              // this.myForm.reset();
              // formDirective.resetForm();
            }
          },
            err => {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err?.error, options);
            });
      }
     

    }


  }


  // get Filtered compound dropdown  
  selectedproject(event) {

    this.Selectedcompoundid = []
    // this.projectcompound = []
    this.myForm.controls.compound.reset();

    var CompoundList = event.value;
    this.projectid = CompoundList
    console.log('product', CompoundList);
    this._solubilityservice.getFilteredcompound(CompoundList)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.error) {
          this.projectcompound = res?.data;
          console.log(this.projectcompound);
        } else {

        }

      },
        err => {
        });
  }






  downloadReport() {


    if (this.data.inputparams) {
      if (this.data.inputparams.startdate && this.data.inputparams.enddate && this.data.inputparams.smile == undefined && this.data.inputparams.projectid == undefined && this.data.inputparams.jobname == undefined ) {

        const formobject = {
          startdate: this.data.inputparams.startdate,
          enddate: this.data.inputparams.enddate,
        }
        let inputobject = formobject
        this._solubilityservice.downloadWithoutProjectIdCompoundid(inputobject)
          .pipe(first()).subscribe((res: any) => {
            if (!res.error) {
              this.loading = false;
              console.log(res)
              const data: Blob = new Blob([res], {
                type: 'text/csv'
              });
              saveAs(data, this.downloadname + ".csv");
            } else {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
            }

          },
            err => {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err?.error, options);
            });
      }


      if (this.data.inputparams.projectid && this.data.inputparams.compoundcode == undefined && this.data.inputparams.smile == undefined) {
        const formobject = {
          projectid: this.data.inputparams.projectid,
          startdate: this.data.inputparams.startdate,
          enddate: this.data.inputparams.enddate,
        }
        let inputobject = formobject
        this._solubilityservice.downloadWithProjectId(inputobject)
          .pipe(first()).subscribe((res: any) => {
            if (!res.error) {
              this.loading = false;
              console.log(res)
              const data: Blob = new Blob([res], {
                type: 'text/csv'
              });
              saveAs(data, this.downloadname + ".csv");
            } else {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
            }

          },
            err => {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err?.error, options);
            });
      }

      if (this.data.inputparams.compoundcode) {
        const formobject = {
          projectid: this.data.inputparams.projectid,
          compoundcode: this.data.inputparams.compoundcode,
          startdate: this.data.inputparams.startdate,
          enddate: this.data.inputparams.enddate,
        }
        let inputobject = formobject

        this._solubilityservice.downloadProjandCompoundReport(inputobject)
          .pipe(first()).subscribe((res: any) => {
            if (!res.error) {
              this.loading = false;
              console.log(res)
              const data: Blob = new Blob([res], {
                type: 'text/csv'
              });
              saveAs(data, this.downloadname + ".csv");
            } else {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
            }

          },
            err => {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err?.error, options);
            });
      }

      if (this.data.inputparams.jobname) {

        const formobject = {
          jobname: this.data.inputparams.jobname,
          startdate: this.data.inputparams.startdate,
          enddate: this.data.inputparams.enddate,
        }
        let inputobject = formobject

        this._solubilityservice.downloadProjectNameReport(inputobject)
          .pipe(first()).subscribe((res: any) => {
            if (!res.error) {
              this.loading = false;
              console.log(res)
              const data: Blob = new Blob([res], {
                type: 'text/csv'
              });
              saveAs(data, this.downloadname + ".csv");
            } else {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
            }
          },
            err => {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err?.error, options);
            });
      }

      if (this.data.inputparams.smile && this.data.inputparams.projectid == undefined) {
        this.downloadname = "structure report";
        const formobject = {
          smile: this.data.inputparams.smile,
          startdate: this.data.inputparams.startdate,
          enddate: this.data.inputparams.enddate,
          structure_typeid: this.data.inputparams.structuretype
        }
        this.sendobject = formobject
        this._solubilityservice.downloadWithstructure(this.sendobject)
          .pipe(first()).subscribe((res: any) => {
            if (!res.error) {
              this.loading = false;
              console.log(res)
              const data: Blob = new Blob([res], {
                type: 'text/csv'
              });
              saveAs(data, this.downloadname + ".csv");
            } else {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
            }
          },
            err => {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err?.error, options);
            });

      }
      if (this.data.inputparams.smile && this.data.inputparams.projectid) {
        this.downloadname = "structure report";
        const formobject = {
          smile: this.data.inputparams.smile,
          startdate: this.data.inputparams.startdate,
          enddate: this.data.inputparams.enddate,
          projectid: this.data.inputparams.projectid,
          structure_typeid: this.data.inputparams.structuretype
        }
        this.sendobject = formobject
        this._solubilityservice.downloadWithstructureprosmile(this.sendobject)
          .pipe(first()).subscribe((res: any) => {
            if (!res.error) {
              this.loading = false;
              console.log(res)
              const data: Blob = new Blob([res], {
                type: 'text/csv'
              });
              saveAs(data, this.downloadname + ".csv");
            } else {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
            }
          },
            err => {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err?.error, options);
            });
      }
      // if (this.data.inputparams.smile == undefined) {

      //   const formobject = {
      //     smile: this.data.inputparams.smile,
      //     startdate: this.data.inputparams.startdate,
      //     enddate: this.data.inputparams.enddate,
      //     typeid: this.data.typeid
      //   }
      //   this.sendobject = formobject
      //   this._solubilityservice.downloadWithoutstructure(this.sendobject)
      //     .pipe(first()).subscribe((res: any) => {
      //       if (!res.error) {
      //         this.loading = false;
      //         console.log(res)
      //         const data: Blob = new Blob([res], {
      //           type: 'text/csv'
      //         });
      //         saveAs(data, this.downloadname + ".csv");
      //       } else {
      //         this.loading = false;
      //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      //         this.toastrService.warning('', res.errorMessage, options);
      //       }
      //     },
      //       err => {
      //         this.loading = false;
      //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      //         this.toastrService.warning('', err?.error, options);
      //       });

      // }
    }


  }


  // openDialog() {
  //   console.log(this.myForm.value)
  //   console.log(this.myForm.value.startdate)

  //   // let formobject = {}
  //   // this.ssdate = moment(this.myForm.value.startdate).format('YYYY-MM-DD');
  //   // this.eedate = moment(this.myForm.value.enddate).format('YYYY-MM-DD');


  //   // formobject = {
  //   //   projectid: this.myForm.value.project,
  //   //   compoundcode: this.myForm.value.compound,
  //   //   startdate: this.ssdate,
  //   //   enddate: this.eedate,
  //   //   typeid: this.filtertypeid
  //   // }



  //   // console.log(formobject)


  //   const dialogRef = this.dialog.open(MyfavouritePopupComponent, {
  //     width: '28%',
  //     data: this.sendobject
  //   });
  // }
  img:any;
  imgclk(element){
    console.log(element)
    this.img = element
  }
  
}
