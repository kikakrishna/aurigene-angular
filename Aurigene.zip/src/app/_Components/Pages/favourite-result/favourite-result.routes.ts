import { RouterModule } from "@angular/router";
import { FavouriteResultComponent } from "./favourite-result.component";
// import {FilteredreportComponent } from "./filteredreport.component";
export const favouriteresulttRoutes: RouterModule [] = [
    {
        path: '',
        component: FavouriteResultComponent
    }
]