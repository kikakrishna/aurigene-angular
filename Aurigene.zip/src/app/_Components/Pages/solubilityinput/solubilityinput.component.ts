import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { SolubilityService } from 'src/app/_Services/solubility.service';
import { MatRadioChange } from '@angular/material/radio';
import { FormControl, FormGroup, NgForm, FormBuilder, Validators } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { SelectionModel } from '@angular/cdk/collections';
import { ToastService } from 'ng-uikit-pro-standard';
import { ActivatedRoute, Router } from '@angular/router';
import { first } from 'rxjs/operators';

import { FormGroupDirective } from '@angular/forms'; @Component({
  selector: 'app-solubilityinput',
  templateUrl: './Solubilityinput.component.html',
  styleUrls: ['./Solubilityinput.component.css']
})
export class SolubilityinputComponent implements OnInit {
  pastescreen: boolean = true;
  loading: boolean;
  btnCreate: any;
  job_jobid: any;
  fileInput: any;
  uploadscreen: boolean = false;
  jobid: any;
  smiles: any;
  projectname: any;
  projectcode: any;
  projectcompound: any;
  projectId: any;
  projectCode: any;
  selectedCompound: any;
  storefile: any;
  algorithm:any;
  title = 'angular-material-file-upload-app';
  @ViewChild('UploadFileInput') uploadFileInput: ElementRef;
  myfilename = 'Browse your file from your computer';
  createsolubility: FormGroup;
  constructor(private _formBuilder: FormBuilder,
    public toastrService: ToastService,
    private _solubilityservice: SolubilityService,
    private router: Router) { }

  ngOnInit(): void {
    this.Getalgorithms()

    this._solubilityservice.getproject()
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res?.responseMessage)
        this.projectcode = res?.data.ProjectList;
      },
      err => {
      });


    this.createsolubility = this._formBuilder.group({
      // ^[a-zA-Z0-9_]*$ 
      project: ['', [Validators.required]],
      Solubilityrun: ['', [Validators.required]],
      smiles: ['', [Validators.required, Validators.pattern]]
      // smiles: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9 ]*$')]]
    });
  }


  selectedproject(event) {
    this.projectId = event.value;
    var CompoundList = event.value;
    console.log('product', CompoundList);

    if(event.value != undefined){
       this.projectcode.map((data)=>{
           if(data.projectId == this.projectId){
              this.projectCode = data.projectCode;
           }
       })
    }

    
    this._solubilityservice.getcompound(CompoundList)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.error) {
          this.projectcompound = res?.data.CompoundList;
          var tempview = []
          this.projectcompound.map((item, i) => {
            tempview.push({
              componentID: item,
              isChecked: false,
              componentIndex: i
            })
          })
          this.projectcompound = tempview
          if (tempview.length == 0) {
            this.projectcompound = tempview;
          }
          console.log('cpmponddetails---' + this.projectcompound);
        } else {
          this.projectcompound = tempview;
        }
        this.selectedCompound = [];
      },
        err => {
        });
  }

  reset() {
    this.createsolubility.reset();
  }

  fileChangeEvent(fileInput: any) {
    if (fileInput.target.files && fileInput.target.files[0]) {
      this.myfilename = '';
      Array.from(fileInput.target.files).forEach((file: File) => {
        console.log(file);
        this.storefile = file
        console.log(this.storefile)
        this.myfilename += file.name;
      }); const reader = new FileReader();
      reader.onload = (e: any) => {
        const image = new Image();
        image.src = e.target.result;
        image.onload = rs => {          // Return Base64 Data URL
          const imgBase64Path = e.target.result;
        };
      };
      reader.readAsDataURL(fileInput.target.files[0]);      // Reset File Input to Selct Same file again
      this.uploadFileInput.nativeElement.value = "";
    }


  }

  Copy
  pasteclick() {
    this.pastescreen = true;
    this.uploadscreen = false;
  }
  uploadclick() {
    this.pastescreen = false;
    this.uploadscreen = true;
  }
  addsolubility(formData: any, formDirective: FormGroupDirective, ele) {
    this.loading = true;
    if (this.createsolubility.value.smiles.trim() == '' || this.createsolubility.value.project == '' || this.createsolubility.value.Solubilityrun == '') {
      const options = { opacity: 1, timeOut: 8000, tapToDismiss: true };
      this.loading = false;
      this.toastrService.warning('', "Enter all the Mandatory Fields", options);
      return;
    }
    // if (this.createsolubility.value.smiles.trim() == '') {
    //   const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    //   this.loading = false;
    //   this.toastrService.warning('', "Enter smiles", options);
    // }
    let formobject = {};
    const smiles = this.createsolubility.value.smiles;
    const smilesArray = smiles.split(' ');
    console.log(smilesArray);

    formobject = {
      "projectCode": this.projectCode,
      "projectId": this.projectId,
      "smileslist": smilesArray,
      "algorithm_id" : this.createsolubility.value.Solubilityrun       
    }

    this._solubilityservice.createsolubilitydata(formobject)
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        if (!res.error) {
          console.log(res?.data[0]?.job_jobid);
          this.jobid = res?.data[0]?.job_jobid
          this.loading = false;
          // formDirective.resetForm();
          this.createsolubility.reset();
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.success('', res.responseMessage, options);
          // setTimeout(()=>{this.router.navigate(['/solubilityinput'])},2000);
          this.router.navigate([`/solubilityrun/${res.data[0]?.job_jobid}`]);
        }

        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }

      },
      err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      });
  }

  updatepost(formData: any, formDirective: FormGroupDirective) {
    this.loading = true;

     if(this.createsolubility.value.project == '' || this.createsolubility.value.Solubilityrun == '') {
      const options = { opacity: 1, timeOut: 8000, tapToDismiss: true };
      this.loading = false;
      this.toastrService.warning('', "Enter all the Mandatory Fields", options);
      return;
    }
    
    if (this.myfilename == 'Browse your file from your computer') {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.loading = false;
      this.toastrService.warning('', "Upload CSV file", options);
      return
    }
    else {

      const formdatafileupload: FormData = new FormData();
      formdatafileupload.append('projectCode', this.projectCode);
      formdatafileupload.append('projectId', this.projectId);
      formdatafileupload.append('file', this.storefile);
      formdatafileupload.append('algorithm_id', this.createsolubility.value.Solubilityrun);

      this._solubilityservice.Imageupload(formdatafileupload)
        .pipe(first())
        .subscribe((res: any) => {
          console.log(res)
          if (!res.error) {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.success('', res.responseMessage, options);
            this.router.navigate([`/solubilityrun/${res.data[0]?.job_jobid}`]);
          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            console.log(err)
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          })

      console.log("efefefefefe" + formdatafileupload)



    }
  }
  
  
  Getalgorithms(){
    this._solubilityservice.GetAlgorithm()
    .pipe(first())
    .subscribe((res: any) => {
      console.log(res?.responseMessage)
      this.algorithm = res?.responseMessage;
    },
      err => {
      });
  }

}