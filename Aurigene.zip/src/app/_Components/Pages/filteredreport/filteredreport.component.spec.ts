import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FilteredreportComponent } from './filteredreport.component';

describe('FilteredreportComponent', () => {
  let component: FilteredreportComponent;
  let fixture: ComponentFixture<FilteredreportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FilteredreportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FilteredreportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
