import { RouterModule } from "@angular/router";
import {FilteredreportComponent } from "./filteredreport.component";
export const FilteredreportRoutes: RouterModule [] = [
    {
        path: '',
        component: FilteredreportComponent
    }
]