import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { catchError, map } from 'rxjs/operators';
import { throwError } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class SolubilityService {

  constructor(private http: HttpClient, private router: Router) {

  }

  // GetUserDetails\
  getuserdetails() {
    return this.http.get(`${environment.apiUrl}/Getuserprofile`).pipe(map((data: any) => {
      if (data) {
        return data;
      }
    })
    )
  }

  // GetJoblist
  getjob() {
    return this.http.get(`${environment.apiUrl}/GetJoblist`)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  // Get Project dropdown  
  getproject() {
    return this.http.get(`${environment.apiUrl}/GetProjectAPIs`)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  // Get compound dropdown  
  getcompound(CompoundList) {
    return this.http.get(`${environment.apiUrl}/GetCompoundAPIs?projectId=` + CompoundList)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }


  //Get structure
  getstructure(projectId, compoundID) {
    // console.log("filterid----->"+filterid)
    return this.http.get(`${environment.apiUrl}/GetSmileAPIs?projectId=` + projectId + `&compoundCode=` + compoundID)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError(err => {
          return throwError(err);
        }),
      );
  }

  // solubility Create
  createsolubilitydata(createdata,) {
    // if(job_jobid == undefined){
    return this.http.post(`${environment.apiUrl}/Createjob`, createdata).pipe(
      map((data: any) => {
        if (data) {
          return data;
        }
      }),
      catchError((err) => {
        return throwError(err);
      })
    );
  }


  // submitlocus job 
  locusjob(createdata,) {
    // if(job_jobid == undefined){
    return this.http.post(`${environment.apiUrl}/submitlocusjob`, createdata).pipe(
      map((data: any) => {
        if (data) {
          return data;
        }
      }),
      catchError((err) => {
        return throwError(err);
      })
    );
  }


  //joblist filter
  joblistfilter(filterstring) {
    return this.http
      .get(
        `${environment.apiUrl}/searchjobname?search=` + filterstring).pipe(
          map((data: any) => {
            if (data) {
              return data;
            }
          }),
          catchError((err) => {
            return throwError(err);
          })
        );
  }
  Imageupload(payload) {
    return this.http
      .post(
        `${environment.apiUrl}/createjobviafileupload`, payload
      )

      .pipe(
        map((data: any) => {
          if (data) {
            return data;
          }
        }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }


  tablelist(id, locus) {
    return this.http
      .get(
        `${environment.apiUrl}/Getjobsmilesmap?jobid=` + id + `&isLocusjob=` + locus,

      )

      .pipe(
        map((data: any) => {
          if (data) {
            return data;
          }
        }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  downloadSolublity(jobId, locusJob) {
    return this.http.get(`${environment.apiUrl}/getpdf?jobid=` + jobId + `&isLocusjob=`+locusJob, { responseType: 'text' })
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  // DownloadJobReport?jobname=P-193_1&startdate=2022-11-01&enddate=2022-12-05
  downloadProjandCompoundReport(param) {
    return this.http.get(`${environment.apiUrl}/DownloadprojectReportPDF?projectid=` + param.projectid + `&compoundcode=` + param.compoundcode + `&startdate=` + param.startdate + `&enddate=` + param.enddate, { responseType: 'text' })
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  downloadWithoutProjectIdCompoundid(param) {
    return this.http.get(`${environment.apiUrl}/DownloadprojectReportPDF?` + `&startdate=` + param.startdate + `&enddate=` + param.enddate, { responseType: 'text' })
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  downloadWithProjectId(param) {
    return this.http.get(`${environment.apiUrl}/DownloadprojectReportPDF?projectid=` + param.projectid + `&startdate=` + param.startdate + `&enddate=` + param.enddate, { responseType: 'text' })
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }


  soluabilitydrawing(formobjects) {
    return this.http.post(`${environment.apiUrl}/submitdrawingjob`, formobjects)
      .pipe(map((data) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }


  // Download Projectname

  // DownloadJobReport?jobname=P-193_1&startdate=2022-11-01&enddate=2022-12-05
  downloadProjectNameReport(param) {
    return this.http.get(`${environment.apiUrl}/DownloadJobReport?jobname=` + param.jobname + `&startdate=` + param.startdate + `&enddate=` + param.enddate, { responseType: 'text' })
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  downloadWithoutProgjectName(param) {
    return this.http.get(`${environment.apiUrl}/DownloadJobReport?` + `&startdate=` + param.startdate + `&enddate=` + param.enddate, { responseType: 'text' })
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

// downloadstructure
downloadWithoutstructure(param) {
  return this.http.get(`${environment.apiUrl}/downloadstructurereport?` + `&startdate=` + param.startdate + `&enddate=` + param.enddate + `&structure_typeid=` + param.structure_typeid, { responseType: 'text' })
    .pipe(map((data: any) => {
      if (data) {
        return data;
      }
    }),
      catchError((err) => {
        return throwError(err);
      })
    );
}

downloadWithstructure(param) {
  return this.http.get(`${environment.apiUrl}/downloadstructurereport?smile=` + param.smile + `&startdate=` + param.startdate + `&enddate=` + param.enddate + `&structure_typeid=` + param.structure_typeid, { responseType: 'text' })
  .pipe(map((data: any) => {
    if (data) {
      return data;
    }
  }),
    catchError((err) => {
      return throwError(err);
    })
  );
}

downloadWithstructureprosmile(param) {
  return this.http.get(`${environment.apiUrl}/downloadstructurereport?smile=` + param.smile + `&projectid=` + param.projectid + `&startdate=` + param.startdate + `&enddate=` + param.enddate + `&structure_typeid=` + param.structure_typeid, { responseType: 'text' })
  .pipe(map((data: any) => {
    if (data) {
      return data;
    }
  }),
    catchError((err) => {
      return throwError(err);
    })
  );
}


  GetAlgorithm() {
    return this.http.get(`${environment.apiUrl}/getalgorithm`)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  // Get Project dropdown  
  getFilteredproject() {
    return this.http.get(`${environment.apiUrl}/getprojectdropdown`)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  // Get compound dropdown  
  getFilteredcompound(CompoundList) {
    return this.http.get(`${environment.apiUrl}/getcompounddropdown?projectid=` + CompoundList)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }


  getsearchbydropdown
  // get filtered report
  getfilterReport(proid, ccod, sdate, edate) {
    return this.http.get(`${environment.apiUrl}/getprojectreport?projectid=` + proid + `&compoundcode=` + ccod + `&startdate=` + sdate + `&enddate=` + edate)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }


  getfilterReportWithProjectId(proid, sdate, edate) {
    return this.http.get(`${environment.apiUrl}/getprojectreport?projectid=` + proid + `&startdate=` + sdate + `&enddate=` + edate)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  getfilterReportWithoutProjectIdCompoundid(sdate, edate) {
    return this.http.get(`${environment.apiUrl}/getprojectreport?` + `&startdate=` + sdate + `&enddate=` + edate)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  getfilterReport2(proid, sdate, edate) {
    return this.http.get(`${environment.apiUrl}/getprojectreport?projectid=` + proid + `&startdate=` + sdate + `&enddate=` + edate)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  // get filtered By Job Name
  getfilterByJobname(jobid, sdate, edate) {
    return this.http.get(`${environment.apiUrl}/getjobreport?jobname=` + jobid + `&startdate=` + sdate + `&enddate=` + edate)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  getfilterWithoutJobName(sdate, edate) {
    return this.http.get(`${environment.apiUrl}/getjobreport?` + `&startdate=` + sdate + `&enddate=` + edate)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }


  // get filtered By Structure
  getfilterByStructure(param) {
    return this.http.get(`${environment.apiUrl}/getstructurereport?smile=` + param.smile + `&startdate=` + param.startdate + `&enddate=` + param.enddate + `&structure_typeid=`+ param.structure_typeid)

      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  getfilterWithoutStructure(param) {
    return this.http.get(`${environment.apiUrl}/getstructurereport?` + `&startdate=` + param.startdate + `&enddate=` + param.enddate)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }


  getfilterWithoutStructuredate(sdate,edate) {
    return this.http.get(`${environment.apiUrl}/getstructurereport?` + `&startdate=` + sdate + `&enddate=` + edate)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  getfilterByStructurewithproject(param) {
    return this.http.get(`${environment.apiUrl}/getstructurereport?smile=` + param.smile + `&startdate=` + param.startdate + `&enddate=` + param.enddate + `&structure_typeid=` + param.structure_typeid + `&projectid=` + param.projectid)

      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }
  // Get Search By dropdown  
  getSearch() {
    return this.http.get(`${environment.apiUrl}/getsearchbydropdown`)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }



   // Get Search By getsearchtype radiobtn structure  
   getStructuretype() {
    return this.http.get(`${environment.apiUrl}/getsearchtype `)
      .pipe(map((data: any) => {
        if (data) {
          return data;
        }
      }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }


  //Get favouitelist 
  favouitelist() {
    return this.http.get(`${environment.apiUrl}/GetFavoriteReportlist`,)
      .pipe(
        map((data: any) => {
          if (data) {
            return data;
          }
        }),
        catchError((err) => {
          return throwError(err);
        })
      );
  }

  // save my fav
  saveapi(formdata) {
    return this.http.post(`${environment.apiUrl}/savefavoritereport `, formdata).pipe(
      map((data: any) => {
        if (data) {
          return data;
        }
      }),
      catchError((err) => {
        return throwError(err);
      })
    );
  }

  savereportapi(formdata) {
    return this.http.post(`${environment.apiUrl}/savefavoritereport `, formdata).pipe(
      map((data: any) => {
        if (data) {
          return data;
        }
      }),
      catchError((err) => {
        return throwError(err);
      })
    );
  }
  // const formobject = {
  //   projectid: this.projectid,
  //   compoundcode: this.Selectedcompoundid,
  //   startdate: this.dysdate,
  //   enddate: this.dyedate,
  //   typeid: this.filtertypeid
  // }
  // this.sendobject = formobject
// chartpage-get chart
  getchartprojectcomp(param) {
    return this.http.get(`${environment.apiUrl}/getchartreport?projectid=` + param.projectid + `&compoundcode=` + param.compoundcode +`&startdate=` + param.startdate + `&enddate=` + param.enddate)
    .pipe(map((data: any) => {
      if (data) {
        return data;
      }
    }),
      catchError((err) => {
        return throwError(err);
      })
    );
  }

  getchartproject(param) {
    return this.http.get(`${environment.apiUrl}/getchartreport?projectid=` + param.projectid + `&startdate=` + param.startdate + `&enddate=` + param.enddate)
    .pipe(map((data: any) => {
      if (data) {
        return data;
      }
    }),
      catchError((err) => {
        return throwError(err);
      })
    );
  }

  getchartprojectwithdate(sdate, edate) {
    return this.http.get(`${environment.apiUrl}/getchartreport?startdate=` + sdate + `&enddate=` + edate)
    .pipe(map((data: any) => {
      if (data) {
        return data;
      }
    }),
      catchError((err) => {
        return throwError(err);
      })
    );
  }


  // check(param) {
  //   return this.http.get(`${environment.apiUrl}/downloadstructurereport?smile=` + param.smile + `&project=` + param.projectid + `&startdate=` + param.startdate + `&enddate=` + param.enddate + `&typeid=` + param.typeid, { responseType: 'text' })
  //   .pipe(map((data: any) => {
  //     if (data) {
  //       return data;
  //     }
  //   }),
  //     catchError((err) => {
  //       return throwError(err);
  //     })
  //   );
  // }

  validateSmile(smile){
    return this.http.get(`${environment.apiUrl}/validatesmile?smile=`+smile)
    .pipe(map((data: any) => {
      if (data) {
        return data;
      }
    }),
      catchError((err) => {
        return throwError(err);
      })
    );
    }

// checksmileboolean-drawingtool table add - slubility drawilng
getsmileboolean(data) {
  return this.http.get(`${environment.apiUrl}/validatesmile?smile=` + data )
  .pipe(map((data: any) => {
    if (data) {
      return data;
    }
  }),
    catchError((err) => {
      return throwError(err);
    })
  );
}
}