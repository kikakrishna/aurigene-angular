import { Component, OnInit, Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable, of, pipe, throwError } from 'rxjs';
import { map, switchMap, debounceTime, catchError } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { Password } from '../_models/password';



@Injectable({ providedIn: 'root' })

export class AnalyticsService {

    constructor(
        private http: HttpClient
    ) { }


    // Latest Patient List
    // patientAnalytics() {
    //     return this.http.get(`${environment.apiUrl}latestpatients`).pipe(map((lPatient: any) => {
    //         return lPatient
    //     }), catchError(err => {
    //         return throwError(err);
    //     }))
    // }

    // patientAnalyticsFilter(dates) {
    //     let sDate = this.DateChange(dates.startdate.toLocaleString())
    //     let eDate = this.DateChange(dates.enddate.toLocaleString())
    //     // debugger
    //     return this.http.get(`${environment.apiUrl}patientloginanalytics?startdate=${sDate}&enddate=${eDate}`).pipe(map((FilteredData: any) => {
    //         return FilteredData
    //     }), catchError(err => {
    //         return throwError(err);
    //     }))
    // }


    // testlist() {
    //     return this.http.get(`${environment.apiUrl}/userassessment`)
    //         .pipe(map((data: any) => {
    //             if (data) {
    //                 return data;
    //             }
    //         }),
    //             catchError(err => {
    //                 return throwError(err);
    //             }),
    //         );
    // }


    // listquestions(qId) {
    //     return this.http.get(`${environment.apiUrl}/getquestions?usertopicmap_id=` + qId)
    //         .pipe(map((data: any) => {
    //             if (data) {
    //                 return data;
    //             }
    //         }),
    //             catchError(err => {
    //                 return throwError(err);
    //             }),
    //         );
    // }

    // testsubmit(data) {

    //     return this.http.post(`${environment.apiUrl}/submitscore`, data)
    //         .pipe(
    //             map((data: any) => {
    //                 if (data) {
    //                     return data;
    //                 }
    //             }),
    //             catchError(err => {
    //                 return throwError(err);
    //             })
    //         );
    // }


    // changePassword(pwd: Password) {

    //     const old_password = pwd.oldpassword;
    //     const new_password = pwd.newpassword;
    //     const stat = {
    //         "oldpassword":old_password,
    //         "newpassword":new_password
    //     }
    //     return this.http.put(`${environment.apiUrl}/changepassword `, stat)
    //         .pipe(
    //             map((data: any) => {
    //                 if (data) {
    //                     return data;
    //                 }
    //             }),
    //             catchError(err => {
    //                 return throwError(err);
    //             }),
    //         );
    // }


    // reportget(rId) {
    //     return this.http.get(`${environment.apiUrl}/userreport?usertopicid=` + rId)
    //         .pipe(map((data: any) => {
    //             if (data) {
    //                 return data;
    //             }
    //         }),
    //             catchError(err => {
    //                 return throwError(err);
    //             }),
    //         );
    // }

    
    // profiledetails() {
    //     return this.http.get(`${environment.apiUrl}/userprofile`)
    //         .pipe(map((data: any) => {
    //             if (data) {
    //                 return data;
    //             }
    //         }),
    //             catchError(err => {
    //                 return throwError(err);
    //             }),
    //         );
    // }


    // profileupdate(data) {

    //     const updatedata = {
    //         "firstname": data.fname,
    //         "lastname": data.lname,
    //         "age": data.age,
    //         "gender": data.gender,
    //         "qualification": data.qualification,
    //         "experience": data.workexperience
    //     }
    //     return this.http.put(`${environment.apiUrl}/updateuser `, updatedata)
    //         .pipe(
    //             map((data: any) => {
    //                 if (data) {
    //                     return data;
    //                 }
    //             }),
    //             catchError(err => {
    //                 return throwError(err);
    //             }),
    //         );
    // }


    // dashusercounts() {
    //     return this.http.get(`${environment.apiUrl}/getusercount`)
    //         .pipe(map((data: any) => {
    //             if (data) {
    //                 return data;
    //             }
    //         }),
    //             catchError(err => {
    //                 return throwError(err);
    //             }),
    //         );
    // }

    // dashpaycounts() {
    //     return this.http.get(`${environment.apiUrl}/gettransactioncount`)
    //         .pipe(map((data: any) => {
    //             if (data) {
    //                 return data;
    //             }
    //         }),
    //             catchError(err => {
    //                 return throwError(err);
    //             }),
    //         );
    // }

    // dashquestioncounts() {
    //     return this.http.get(`${environment.apiUrl}/getquestionarecount`)
    //         .pipe(map((data: any) => {
    //             if (data) {
    //                 return data;
    //             }
    //         }),
    //             catchError(err => {
    //                 return throwError(err);
    //             }),
    //         );
    // }

    // latestquestionaire() {
    //     return this.http.get(`${environment.apiUrl}/getlatestquestionare`)
    //         .pipe(map((data: any) => {
    //             if (data) {
    //                 return data;
    //             }
    //         }),
    //             catchError(err => {
    //                 return throwError(err);
    //             }),
    //         );
    // }

    // latesttransaction() {
    //     return this.http.get(`${environment.apiUrl}/getlatesttransaction`)
    //         .pipe(map((data: any) => {
    //             if (data) {
    //                 return data;
    //             }
    //         }),
    //             catchError(err => {
    //                 return throwError(err);
    //             }),
    //         );
    // }

    // listuser() {
    //     return this.http.get(`${environment.apiUrl}/userlist`)
    //         .pipe(map((data: any) => {
    //             if (data) {
    //                 return data;
    //             }
    //         }),
    //             catchError(err => {
    //                 return throwError(err);
    //             }),
    //         );
    // }

    // userviewquestionire(uid) {
    //     return this.http.get(`${environment.apiUrl}/userassessment?userguid=` + uid)
    //         .pipe(map((data: any) => {
    //             if (data) {
    //                 return data;
    //             }
    //         }),
    //             catchError(err => {
    //                 return throwError(err);
    //             }),
    //         );
    // }

    // userviewdetails(uid) {
    //     return this.http.get(`${environment.apiUrl}/userprofile?userguid=` + uid)
    //         .pipe(map((data: any) => {
    //             if (data) {
    //                 return data;
    //             }
    //         }),
    //             catchError(err => {
    //                 return throwError(err);
    //             }),
    //         );
    // }


    // changestateuser(uId, toglestate) {
    //     const statvalue = {
    //         "userguid":uId,
    //         "status":toglestate
    //      };
    //     return this.http
    //         .put(
    //             `${environment.apiUrl}/updatestatus`, statvalue)
    //         .pipe(
    //             map((data: any) => {
    //                 if (data) {
    //                     return data;
    //                 }
    //             }),
    //             catchError((err) => {
    //                 return throwError(err);
    //             })
    //         );
    // }


    // changeofferuser(uId, toglestate) {
    //     const statvalue = {
    //         "userguid":uId,
    //         "type":toglestate
    //      };
    //     return this.http
    //         .put(
    //             `${environment.apiUrl}/updatetype`, statvalue)
    //         .pipe(
    //             map((data: any) => {
    //                 if (data) {
    //                     return data;
    //                 }
    //             }),
    //             catchError((err) => {
    //                 return throwError(err);
    //             })
    //         );
    // }

    // reportadminget(rId, guid) {
    //     return this.http.get(`${environment.apiUrl}/userreport?usertopicid=` + rId + `&userguid=` + guid)
    //         .pipe(map((data: any) => {
    //             if (data) {
    //                 return data;
    //             }
    //         }),
    //             catchError(err => {
    //                 return throwError(err);
    //             }),
    //         );
    // }

    // paymentlist() {
    //     return this.http.get(`${environment.apiUrl}/gettransactionlist`)
    //         .pipe(map((data: any) => {
    //             if (data) {
    //                 return data;
    //             }
    //         }),
    //             catchError(err => {
    //                 return throwError(err);
    //             }),
    //         );
    // }


    // forgotmail(data) {

    //     let fordata = {
    //         "email":data.email
    //     }

    //     return this.http.post(`${environment.apiUrl}/forgetpassword`, fordata)
    //         .pipe(
    //             map((data: any) => {
    //                 if (data) {
    //                     return data;
    //                 }
    //             }),
    //             catchError(err => {
    //                 return throwError(err);
    //             })
    //         );
    // }


    // paymentlistuser() {
    //     return this.http.get(`${environment.apiUrl}/userTransaction`)
    //         .pipe(map((data: any) => {
    //             if (data) {
    //                 return data;
    //             }
    //         }),
    //             catchError(err => {
    //                 return throwError(err);
    //             }),
    //         );
    // }


    // scorechart() {
    //     return this.http.get(`${environment.apiUrl}/overallscorechart`)
    //         .pipe(map((data: any) => {
    //             if (data) {
    //                 return data;
    //             }
    //         }),
    //             catchError(err => {
    //                 return throwError(err);
    //             }),
    //         );
    // }

    // listquestionanswers(topid) {
    //     return this.http.get(`${environment.apiUrl}/getquestionandanswer?usertopicmap_id=` + topid)
    //         .pipe(map((data: any) => {
    //             if (data) {
    //                 return data;
    //             }
    //         }),
    //             catchError(err => {
    //                 return throwError(err);
    //             }),
    //         );
    // }


    // DateChange(date) {
    //     let Date1 = date.split(',')[0];
    //     let Date2 = Date1.split('/')[2] + '-' + Date1.split('/')[0] + '-' + Date1.split('/')[1];
    //     return Date2
    // }
}