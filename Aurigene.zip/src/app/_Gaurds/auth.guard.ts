import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthenticationService } from '../_Services/authentication.service';
declare var $:any;

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {

  constructor(
    private router: Router,
    private authenticationService: AuthenticationService
  ) {
    const currentUser = this.authenticationService.currentUserValue;
    // console.log(currentUser, "ram1")
    // console.log(currentUser, "ram2")
    // console.log(currentUser, "ram3")
    // alert("get");
  }


  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    const currentUser = this.authenticationService.currentUserValue;
    console.log(route.data)

    if(sessionStorage.getItem("Role") != "admin"){
      $('body').addClass('noselect');
    }
  
    if(sessionStorage.getItem("Role") == "admin"){
      $('body').removeClass('noselect');
    }


    if (currentUser) {
      if (currentUser && route?.data?.role == sessionStorage.getItem("Role")) {
        return true;
      } else {
        sessionStorage.clear();
        this.router.navigate(['/'], { queryParams: { returnUrl: state.url } });
        return false;
      }

      // logged in so return true
      // return true;

    }
    // not logged in so redirect to login page with the return url
    this.router.navigate(['/'], { queryParams: { returnUrl: state.url } });
    return false;
  }
}

