/**
 * This file contains authentication parameters. Contents of this file
 * is roughly the same across other MSAL.js libraries. These parameters
 * are used to initialize Angular and MSAL Angular configurations in
 * in app.module.ts file.
 */

import { LogLevel, Configuration, BrowserCacheLocation } from '@azure/msal-browser';

const isIE = window.navigator.userAgent.indexOf("MSIE ") > -1 || window.navigator.userAgent.indexOf("Trident/") > -1;

/**
 * Configuration object to be passed to MSAL instance on creation.
 * For a full list of MSAL.js configuration parameters, visit:
 * https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/lib/msal-browser/docs/configuration.md
 */
export const msalConfig: Configuration = {

    auth: {
        clientId: "059880bb-8f18-4544-bc44-13da00f0dbd4", // This is the ONLY mandatory field that you need to supply.
        authority: "https://login.microsoftonline.com/8789cd3a-74b6-41ae-8992-8be37e5f6bd1",// Defaults to "https://login.microsoftonline.com/common"
        // client
        // clientId: "68bc57e2-8db2-460a-949e-662decf6c001", // This is the ONLY mandatory field that you need to supply.
        // authority: "https://login.microsoftonline.com/581d7d77-8051-4f10-95ac-b1aeff53d129",// Defaults to "https://login.microsoftonline.com/common"
        redirectUri: '/', // Points to window.location.origin by default. You must register this URI on Azure portal/App Registration.
        postLogoutRedirectUri: '/', // Points to window.location.origin by default.
        clientCapabilities: ['CP1'] // This lets the resource server know that this client can handle claim challenges.
    },
    cache: {
        cacheLocation: BrowserCacheLocation.LocalStorage, // Configures cache location. "sessionStorage" is more secure, but "localStorage" gives you SSO between tabs.
        storeAuthStateInCookie: isIE, // Set this to "true" if you are having issues on IE11 or Edge. Remove this line to use Angular Universal
    },
    system: {
        /**
         * Below you can configure MSAL.js logs. For more information, visit:
         * https://docs.microsoft.com/azure/active-directory/develop/msal-logging-js
         */
        loggerOptions: {
            loggerCallback(logLevel: LogLevel, message: string) {
                // console.log(message);
            },
            logLevel: LogLevel.Verbose,
            piiLoggingEnabled: false
        }
    }
}

/**
 * Add here the endpoints and scopes when obtaining an access token for protected web APIs. For more information, see:
 * https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/lib/msal-browser/docs/resources-and-scopes.md
 */
export const protectedResources = {
    todoListApi: {
        //endpoint: "http://127.0.0.1:8002/api",
        // endpoint: 'http://164.52.216.127:6678/api',
        endpoint: "https://aurigene.latlontech.com/telehealthapi/api",
        // endpoint: 'https://aimlqa.aurigene.com/telehealthapi/api',
        // endpoint: 'https://aiml.aurigene.com/telehealthapi/api',
        // endpoint: 'https://aiml.aurigene.com/example/api',

        scopes: {
            read: ["api://e0faf002-14b0-4201-9182-a25df4730e4b/access_as_user"],
            write: ["api://e0faf002-14b0-4201-9182-a25df4730e4b/access_as_user"]
            // client
            // read: ["api://6a7a0e7f-6a9a-45fe-aa3b-59d806925638/access_as_user"], // Backend app1
            // write: ["api://6a7a0e7f-6a9a-45fe-aa3b-59d806925638/access_as_user"]  // Backend app1
            // read: ["api://24db8ba4-e61e-48d6-9ec6-bd3d48d7562e/access_as_user"],  // Backend app2
            // write: ["api://24db8ba4-e61e-48d6-9ec6-bd3d48d7562e/access_as_user"] // Backend app2 
        }
    }
}

/**
 * Scopes you add here will be prompted for user consent during sign-in.
 * By default, MSAL.js will add OIDC scopes (openid, profile, email) to any login request.
 * For more information about OIDC scopes, visit:
 * https://docs.microsoft.com/en-us/azure/active-directory/develop/v2-permissions-and-consent#openid-connect-scopes
 */
export const loginRequest = {
    scopes: []
};
