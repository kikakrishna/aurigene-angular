import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthenticationService } from '../_Services/authentication.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ToastService } from 'ng-uikit-pro-standard';
import { MsalService, MsalBroadcastService, MSAL_GUARD_CONFIG, MsalGuardConfiguration } from '@azure/msal-angular';

@Injectable()
export class JwtInterceptor implements HttpInterceptor {

  constructor(private route: ActivatedRoute, private toastrService: ToastService, private _snackBar: MatSnackBar, 
    private router: Router, private authenticationService: AuthenticationService, private authService: MsalService) {
  }

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    //// add authorization header with jwt token if available
    let currentUser = this.authenticationService.currentUserValue;
    if (currentUser) {
      request = request.clone({
        setHeaders: {
          'Authorization': sessionStorage.getItem("currentUser"),
          'Cache-Control': 'no-cache, no-store, must-revalidate, post-check=0, pre-check=0',
          'Pragma': 'no-cache',
          'Expires': '0'
        }
      });
    }

    return next.handle(request)
      .pipe(
        catchError((err: HttpErrorResponse) => {
          console.log(err)
          // if (err.status <= 400 && err.status >= 500) {
          if (err.status == 0) {
            this._snackBar.open("Unable to connect the server", "Close");  
          }        
          if (err.status == 401 || err.status == 403) {
            console.log(err)
            // sessionStorage.removeItem('currentUser');
            // sessionStorage.clear();
            
            // this.router.navigate(['/login']);
            localStorage.removeItem('Loggedin-user'); 
            localStorage.clear();
            // this.authService.logoutRedirect({
            //   postLogoutRedirectUri: 'https://localhost:4200'
            // });
            // this.authService.logout();
            this.router.navigate(['']);   
            // this.authService.logoutRedirect({
            //   postLogoutRedirectUri: 'https://localhost:4200'
            // });
            // return throwError(err);
          }
          // if (err.status == 403) {
          //   console.log(err)
          //   this.authenticationService.refreshToken().subscribe(res => {
          //     console.log(res)
          //     this.reloadCurrentRoute();
          //     return;
          //   }, err => {
          //     console.log(err)
          //     const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          //     this.toastrService.warning('', err?.error?.errorMessage, options);
          //     setTimeout(() => {
          //       this.toastrService.clear(), 2000
          //     }, 2000);
          //     // sessionStorage.removeItem('currentUser');
          //     // sessionStorage.clear();
          //     // this.router.navigate([''], { queryParams: { returnUrl: request.url } });
          //   })

          // }
          return throwError(err);
          
        })
      );
  }

  reloadCurrentRoute() {
    let currentUrl = this.router.url;
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
      this.router.navigate([currentUrl]);
      console.log(currentUrl);
    });
  }
}
